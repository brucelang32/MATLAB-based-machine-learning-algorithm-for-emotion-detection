%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% protosc_install
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% 
% SS 2020

clc
currloci = pwd;
disp(['You are currently in: ' pwd])
disp('0) Would you like to add Protosc to your Matlab Path ')
disp('or choose a new location first ')
inst = input('(0 add current path, 1 move Protosc first): ');
if inst
    cont = 1;
    loci = uigetdir(pwd,'Select Destination');
    while cont
        disp(' ')
        disp('You have chosen: ')
        disp(loci)
        ca = input('Press enter to confirm, 0 to choose again.');
        if ~isempty(ca)
            loci = uigetdir(pwd,'Select Destination');
        else
            cont = 0;
        end
        
    end
    if ~strcmpi(currloci,loci)
        if strcmpi(currloci(1),loci(1))
            [SUCCESS,MESSAGE,MESSAGEID] = movefile(currloci,loci,'f');
            if SUCCESS == 0
                disp('Failed. Best to just click and drag like a cave-person I guess, sorry about that.')
                loci = currloci;
            end
        else
            disp('Moving to different drive, will copy instead of move')
            [SUCCESS,MESSAGE,MESSAGEID] = copyfile(currloci,loci,'f');
            if SUCCESS == 0
                disp('Failed. Best to just click and drag like a cave-person I guess, sorry about that.')
                loci = currloci;
            end
        end
    end
else
    loci = currloci;
end
addpath([loci filesep],[loci filesep 'Codes'],[loci filesep 'Analyses'],[loci filesep 'SavedFiles'])
disp('Protosc Added to your Matlab path.');
disp('Note that all Protosc scripts and functions start with protocs')
disp('so no interference with other toolboxes is expected.')
disp(' ')
saveme = input('Would you like to save the path for further use? (0 for no, 1 for yes).');
if saveme
    savepath
    disp('Path Saved')
end
disp(' ')
disp('Enjoy!')
disp(' ')
protosc_help
