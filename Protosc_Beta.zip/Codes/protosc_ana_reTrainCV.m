function [p,CM] = protosc_ana_reTrainCV(TrainSet,TestSet,trainSetOut,model)
% p = protosc_ana_reTrainCV(TrainSet,TestSet,trainSetOut,model)
% 
% SS 2020

% TrainSet    = protosc_ana_Features2AllData(FourierFeaturesK);
% TestSet     = protosc_ana_Features2AllData(FourierFeaturesN);
% trainSetOut = 
% model       = 'FinalModel';
if ~exist('trainSetOut','var')
    trainSetOut.settings = protosc_Settings;
    fs = 0;
else
    fs = 1;
end
if ~exist('model','var')
%     if ~exist('trainSetOut','var')
%         
%     else
        model = 'FinalModel';
%     end
end
try
    MLmodel           = eval(['@' trainSetOut.settings.Main.Classifier]);
catch
    MLmodel           = eval(['@' char(trainSetOut.settings.Main.Classifier)]);
end
if strcmpi(trainSetOut.settings.Wrapper.FinalModelSelection,'Accuracy')
    CritFunction = @protosc_get_Accuracy;
else
    CritFunction = @protosc_get_F1Macro;
end
if fs
    t = trainSetOut.settings.Wrapper.FinalModelSelection;
    for ii = 1:length(trainSetOut.Results.(model).(t))
        cvm         = MLmodel(TrainSet(:,[1 trainSetOut.Results.(model).FeatureIndices{ii}]));
        ys          = TestSet(:,1)';
        yhats       = cvm.predictFcn(TestSet(:,trainSetOut.Results.(model).FeatureIndices{ii}+1))';
        p(ii)       = CritFunction(ys,yhats);
        CM(:,:,ii)  = confusionmat(ys,yhats);
    end
else
    for ii = 1:trainSetOut.settings.Main.nfolds
        cvm         = MLmodel(TrainSet);
        ys          = TestSet(:,1);
        yhats       = cvm.predictFcn(TestSet(:,2:end));
        p(ii)       = CritFunction(ys,yhats);
        CM(:,:,ii)  = confusionmat(ys,yhats);
    end
end
    
