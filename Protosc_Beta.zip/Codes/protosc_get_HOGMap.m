function hogim = protosc_get_HOGMap(HogFeatures,settings,plotoff)
% function hogim = protosc_show_HOGfeatures(HogFeatures,settings,plotoff)
% 
% SS 2020

if ~exist('plotoff','var') || isempty(plotoff)
    plotoff = 0;
end
w = whos('HogFeatures');
if ~strcmpi(w.class,'cell')
    useHogFeatures{1} = HogFeatures;
else
    useHogFeatures = HogFeatures;
end
if ~isfield(settings.Features,'HOG_BinCenters') || isempty(settings.Features.HOG_BinCenters)
    settings.Features.HOG_BinCenters = 0:180/settings.Features.HOG_nBins:180-((180/settings.Features.HOG_nBins)/2);
end
if ~isfield(settings.Features,'HOG_ImSize') || isempty(settings.Features.HOG_ImSize)
    settings.Features.HOG_ImSize = [200 200];
end
for wcat = 1:size(useHogFeatures,2)
    if size(useHogFeatures{1},1)>1
        fvals = mean(useHogFeatures{wcat});
    else
        fvals = useHogFeatures{wcat};
    end
    startx          = 1:settings.Features.HOG_cellsize(1):settings.Features.HOG_ImSize(1);
    starty          = 1:settings.Features.HOG_cellsize(2):settings.Features.HOG_ImSize(2);
    lineblock       = ones(settings.Features.HOG_cellsize)*0;
    lineblock(:,floor(settings.Features.HOG_cellsize(2)/2):ceil(settings.Features.HOG_cellsize(2)/2+1)) = 1;
    block           = nan(settings.Features.HOG_cellsize(1),settings.Features.HOG_cellsize(2),settings.Features.HOG_nBins);
    radius          = min(settings.Features.HOG_cellsize)/2-.5;
    [X, Y]          = meshgrid(-radius:radius,-radius:radius);
    radimap         = protosc_im_scale(sqrt(X.^2+Y.^2));
    include         = ones(1,length(fvals));
    bigim           = zeros(settings.Features.HOG_ImSize(1),settings.Features.HOG_ImSize(2),settings.Features.HOG_nBins);
    devby           = ones(settings.Features.HOG_ImSize(1),settings.Features.HOG_ImSize(2),settings.Features.HOG_nBins);
    for ii = 1:settings.Features.HOG_nBins
        block(:,:,ii) = (imrotate(lineblock,settings.Features.HOG_BinCenters(ii),'bicubic','crop')>0);
    end
    c           = 0;
    for y = startx
        for x = starty
            for ori = 1:settings.Features.HOG_nBins
                c = c+1;
                if include(c) == 1
%                     sizefilter = radimap<fvals(c);
                    bigim(x:x+(settings.Features.HOG_cellsize(1)-1),y:y+(settings.Features.HOG_cellsize(1)-1),ori)...
                        = block(:,:,ori)*fvals(c);%(((block(:,:,ori)-.5).*sizefilter)*fvals(c))+0.5;%
                    devby(x:x+(settings.Features.HOG_cellsize(1)-1),y:y+(settings.Features.HOG_cellsize(1)-1),ori)...
                        = devby(x:x+(settings.Features.HOG_cellsize(1)-1),y:y+(settings.Features.HOG_cellsize(1)-1),ori)...
                        +block(:,:,ori);
                else
                    bigim(x:x+(settings.Features.HOG_cellsize(1)-1),y:y+(settings.Features.HOG_cellsize(1)-1),ori)...
                    = block(:,:,ori)*0;%((block(:,:,ori)-.5)*0)+0.5;
                end
            end
            bigim(x:x+(settings.Features.HOG_cellsize(1)-1),y:y+(settings.Features.HOG_cellsize(1)-1),:) = ...
                bigim(x:x+(settings.Features.HOG_cellsize(1)-1),y:y+(settings.Features.HOG_cellsize(1)-1),:)...
                .*repmat(protosc_im_smoothedge_circle(size(lineblock,1)/2-.5,ceil(size(lineblock,1)/5)),1,1,settings.Features.HOG_nBins);
        end
    end
    hogim{wcat} = protosc_im_scale(sum(bigim,3));
    s           = hogim{wcat}>.95;
    x           = 1-hogim{wcat};
    x(x==1)     = 0;
    hogim{wcat} = protosc_im_scale(x.^10);
    hogim{wcat} = protosc_im_scale(hogim{wcat}*-1);
    hogim{wcat}(hogim{wcat}==1)     = 0;
    hogim{wcat}(s) = .95;
    if plotoff == 0
        if size(useHogFeatures,2)>3
            subplot(ceil(sqrt(size(useHogFeatures,2))),ceil(sqrt(size(useHogFeatures,2))),wcat),imshow(hogim{wcat}),title(['Average Category ' num2str(wcat)])
        else
            subplot(1,size(useHogFeatures,2),wcat),imshow(hogim{wcat}),title(['Average Category ' num2str(wcat)])
        end
    end
end
if size(useHogFeatures,2)==1
    hogim = hogim{1};
end




