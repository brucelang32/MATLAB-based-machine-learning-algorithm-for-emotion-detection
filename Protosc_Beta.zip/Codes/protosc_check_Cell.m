function varout = protosc_check_Cell(var)
% function varout = protosc_check_Cell(var)
% 
% 
% SS 2019

all     = whos;
in      = whos(all.name);
if strcmpi(in.class,'char')
    varout{1} = var;
else
    varout = var;
end