function StimFiles = protosc_get_StimFiles(imdir,ext,mustinclude,maynotinclude,And1_Or0)
% function StimFiles = protosc_get_StimFiles(imdir,ext,mustinclude,maynotinclude,And1_Or0)
% 
% protosc_get_StimFiles creates cells containing all info for loading files
%
% imdir:        cell containing directories, 1 per directory
% ext:          cell containing file extentions, 1 per directory
% mustinclude:  cell containing criteria to include, 1 per directory
% maynotinclude:cell containing criteria to exclude
% And1_Or0 = 1, all criteria must be met to select file
% And1_Or0 = 0, at least 1 of the criteria must be met to select file
%
% SS 2019

AllStimFiles = cell(1);
if ~exist('imdir','var') || isempty(imdir)
    disp(['Using all folders in ' [protosc_get_root filesep 'ImageDrop'] ])
    lfidir = [protosc_get_root filesep 'ImageDrop'];
    filesindir = dir(lfidir);
    c = 0;
    for ii = 3:size(filesindir,1)
        if filesindir(ii).isdir
            c = c+1;
            imdir{c} = [protosc_get_root filesep 'ImageDrop' filesep filesindir(ii).name];
        end
    end
    disp(['Found ' num2str(c) '  catagories.'])
end    
if ~exist('mustinclude','var')
    mustinclude = '';
end
if ~exist('maynotinclude','var')
    maynotinclude = '';
end
if ~exist('ext','var') || isempty(ext)
    ext = '*';
end
if ~exist('And1_Or0','var') || isempty(And1_Or0)
    And1_Or0 = 0;
end

imdirs          = protosc_check_Cell(imdir);
ext             = protosc_check_Cell(ext);
mustinclude     = protosc_check_Cell(mustinclude);
maynotinclude   = protosc_check_Cell(maynotinclude);

if size(imdirs,2) < size(ext,2) || size(imdirs,2) < size(mustinclude,2) || size(imdirs,2) < size(maynotinclude,2)
    for ii = 1:max([size(ext,2) size(mustinclude,2) size(maynotinclude,2)])
        useimdirs{ii} = imdirs{1};
    end
    clear imdirs; 
    imdirs = useimdirs;
end

for ii = 1:length(imdirs)
    if isempty(mustinclude)
        mustinclude{ii} = '';
        skip_1(ii) = 1;
    else
        skip_1(ii) = 0;
    end
    if isempty(maynotinclude)
        maynotinclude{ii} = '';
        skip_2(ii) = 1;
    else
        skip_2(ii) = 0;
    end
end



if size(ext,2)~=size(imdirs,2)
    warning(['[In ' mfilename '] Input length mismatch in "ext", replicating criteria from imdir 1 to all others'])
    for ii = 1: size(imdirs,2)
        useext{ii} = ext{1};
    end
else
    useext = ext;
end
if size(mustinclude,2)~=size(imdirs,2)
    warning(['[In ' mfilename '] Input length mismatch in "mustinclude", replicating criteria from imdir 1 to all others'])
    for ii = 1: size(imdirs,2)
        t_mustinclude{ii} = mustinclude{1};
    end
else
    t_mustinclude = mustinclude;
end
if size(maynotinclude,2)~=size(imdirs,2)
    warning(['[In ' mfilename '] Input length mismatch in "maynotinclude", replicating criteria from imdir 1 to all others'])
    for ii = 1: size(imdirs,2)
        t_maynotinclude{ii} = maynotinclude{1};
    end
else
    t_maynotinclude = maynotinclude;
end

for d = 1:size(imdirs,2)
    disp(['[In ' mfilename '] Reading files from directory ' num2str(d)])
    allfiles = dir([imdirs{d} filesep '*' useext{d}]);
    if isempty(allfiles)
        dir([imdirs{d}])
        warning(['[In ' mfilename '] Could not find any files that match with ' useext{d} ' in the following directory (content displayed above):' imdirs{d}])
    end
    usemustinclude = ['*' t_mustinclude{d} '*'];
    usemaynotinclude = ['*' t_maynotinclude{d} '*'];
    c = 0;
    for ii = 1:size(allfiles,1)
        where = strfind(usemustinclude,'*');
        keep = [];
        drop = [];
        if skip_1(d) == 0 && ~strcmp(usemustinclude,'**')
            for kk = 1:size(where,2)-1
                keep(kk) = ~isempty(strfind(allfiles(ii).name,usemustinclude(where(kk)+1:where(kk+1)-1)));
            end
        else
            keep = 1;
        end
        if skip_2(d) == 0 && ~strcmp(usemaynotinclude,'**')
            where = strfind(usemaynotinclude,'*');
            for kk = 1:size(where,2)-1
                drop(kk) = ~isempty(strfind(allfiles(ii).name,usemaynotinclude(where(kk)+1:where(kk+1)-1)));
            end
        else
            drop = 0;
        end
        if And1_Or0 == 1 %AND
            add = mean(keep) == 1 && mean(drop) == 0;
        else %OR
            add = sum(keep) >= 1 && sum(drop) == 0;
        end
        if add
            c = c+1;
            StimFiles{d}(c).name         = allfiles(ii).name;
            StimFiles{d}(c).fullname     = [imdirs{d} filesep allfiles(ii).name];
            StimFiles{d}(c).need2include = mustinclude;
            StimFiles{d}(c).need2exclude = maynotinclude;
        end
    end
    try
        if isempty(StimFiles{d})
            warning(['[In ' mfilename '] Cell ' num2str(d) ' of StimFiles is empty.Could not find any files that match the criteria.'])
        end
    catch
        warning(['[In ' mfilename '] Cell ' num2str(d) ' of StimFiles is empty. Could not find any files that match the criteria.'])
    end
end


