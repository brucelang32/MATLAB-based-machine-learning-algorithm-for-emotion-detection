function [IncludedParams,PosibleParams]= protosc_ana_Wrapper_evalFeatureOrder(out,AllData,PosibleParams,IncludedParams)
% function [IncludedParams,PosibleParams]= protosc_ana_Wrapper_evalFeatureOrder(out,AllData,PosibleParams,IncludedParams,MLmodel)
%
% this function is a sub-function of protosc_ana_FeatureSelection and
% is not made to function in isolation
% 
% SS 2019

try
    WMLModel           = eval(['@' out.settings.Wrapper.Classifier]);
catch
    WMLModel           = eval(['@' char(out.settings.Wrapper.Classifier)]);
end
try
    CritFunction           = eval(['@' out.settings.Wrapper.CritFunction]);
catch
    CritFunction           = eval(['@' char(out.settings.Wrapper.CritFunction)]);
end

sl              = length(IncludedParams);
without_perf    = nan(1,out.settings.Wrapper.consistency_its);
with_perf       = nan(1,out.settings.Wrapper.consistency_its);
maxsweeps       = 10;
sweep           = 0;
while sweep<maxsweeps
    xatatime            = ceil(length(IncludedParams)/(maxsweeps/2));
    keepgoing           = 1;
    allperfs            = ones(1,length(IncludedParams));
    excl                = zeros(1,length(IncludedParams));
    droporder           = length(IncludedParams):-1:1;
    %get ref performance
    try
        parfor i = 1:out.settings.Wrapper.consistency_its
            bol_ind         = protosc_get_BalencedSample(AllData,25);
            model           = WMLModel(AllData(bol_ind==1,[1 IncludedParams+1]));
            with_perf(i)    = CritFunction(AllData(bol_ind==0,1),model.predictFcn(AllData(bol_ind==0,IncludedParams+1)));
        end
    catch
        for i = 1:out.settings.Wrapper.consistency_its
            bol_ind         = protosc_get_BalencedSample(AllData,25);
            model           = WMLModel(AllData(bol_ind==1,[1 IncludedParams+1]));
            with_perf(i)    = CritFunction(AllData(bol_ind==0,1),model.predictFcn(AllData(bol_ind==0,IncludedParams+1)));
        end
    end
    while keepgoing
        sweep               = sweep+1;
        % leave out
        try
            dropped = droporder(xatatime*(sweep-1)+1 : xatatime*sweep);
        catch
            dropped = droporder(xatatime*(sweep-1)+1 : end);
        end
        if ~isempty(dropped)
            excl                = zeros(1,length(IncludedParams));
            excl(dropped)       = 1;
            usepreds            = IncludedParams(excl==1);
            %get test performance
            try
                parfor i = 1:out.settings.Wrapper.consistency_its
                    bol_ind         = protosc_get_BalencedSample(AllData,25);
                    model           = WMLModel(AllData(bol_ind==1,[1 usepreds+1]));
                    without_perf(i) = CritFunction(AllData(bol_ind==0,1),model.predictFcn(AllData(bol_ind==0,usepreds+1)));
                end
            catch
                for i = 1:out.settings.Wrapper.consistency_its
                    bol_ind         = protosc_get_BalencedSample(AllData,25);
                    model           = WMLModel(AllData(bol_ind==1,[1 usepreds+1]));
                    without_perf(i) = CritFunction(AllData(bol_ind==0,1),model.predictFcn(AllData(bol_ind==0,usepreds+1)));
                end
            end
            %rate them
            allperfs(dropped) = mean(with_perf) - mean(without_perf); %feature scores, higher better
            if mean(allperfs(dropped)) <= 0
                IncludedParams  = IncludedParams(excl==0);
                allperfs        = allperfs(excl==0);
                [~,inx]         = sort(allperfs,'descend');
                IncludedParams  = IncludedParams(inx);
                keepgoing       = 0;
            end
        else
            keepgoing = 0;
        end
    end
    [~,inx]         = sort(allperfs,'descend');
    IncludedParams  = IncludedParams(inx);
end
dropped         = sl - length(IncludedParams);
if out.settings.Display.showintremfeedback
    disp(['[In ' mfilename '] Dropped ' num2str(dropped) ' out of ' num2str(sl) ' features.'])
end


