function Acc = protosc_perf_Accuracy(y,yhat)
% function Acc = protosc_perf_Accuracy(y,yhat)
% 
% SS 2019

Acc = mean(y == yhat);




