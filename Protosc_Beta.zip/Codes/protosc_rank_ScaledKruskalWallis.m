function [ranked_ind,rankscores_originalorder] = protosc_rank_ScaledKruskalWallis(AllData,ranking_its,crit_samp_perc)
% function [ranked_ind,rankscores_originalorder] = protosc_rank_FullKruskalWallis(AllData,prior_its,crit_samp_perc)
%
% SS 2019


AllLabels = unique(AllData(:,1));
if ~exist('crit_samp_perc','var')
    settings = protosc_Settings;
    crit_samp_perc = settings.Main.samplingPercentage;
end
if ~exist('prior_its','var')
    settings = protosc_Settings;
    ranking_its = settings.Ranking.iterations;
end
if crit_samp_perc>1
    crit_samp_perc = crit_samp_perc/100;
end
ranked_ind  = [];
FF          = nan(ranking_its,size(AllData,2)-1);
use_ind     = protosc_get_BalencedSample(AllData,100);
usedata     = AllData(use_ind,:);
try
    parfor i = 2:size(usedata,2)
        M = [];
        for l = AllLabels'
            M = [M usedata(usedata(:,1)==l,i)];
        end
        [~, table] =  kruskalwallis(M,[],'off');
        FF(1,i-1) = table{2,5};
    end
catch
    for i = 2:size(usedata,2)
        M = [];
        for l = AllLabels'
            M = [M usedata(usedata(:,1)==l,i)];
        end
        [~, table] =  kruskalwallis(M,[],'off');
        FF(1,i-1) = table{2,5};
    end
end

FF                          = FF.*nanstd(AllData(:,2:end));
FF(isnan(FF))               = 0;
rankscores_originalorder    = FF;
if isempty(ranked_ind)
    if size(rankscores_originalorder,1) > 1
        [~,ranked_ind] = sort(nansum(rankscores_originalorder),'descend');
        rankscores_originalorder = nanmean(rankscores_originalorder);
    else
        [~,ranked_ind] = sort(rankscores_originalorder,'descend');
    end
end
rankscores_originalorder(isnan(rankscores_originalorder))=0;

