function [ind,ResultsMap,FeatureTotalScore] = protosc_ana_MainFeatures(out,model,crit)
% function [ind,ResultsMap,FeatureTotalScore] = protosc_ana_MainFeatures(out,model,crit)
% 
% example:
% AllData_set1                = protosc_ana_Features2AllData(AllFeatures_set1);
% AllData_set2                = protosc_ana_Features2AllData(AllFeatures_set2);
% out(1)                      = protosc_ana_FeatureSelection(AllData_set1,settings);
% out(2)                      = protosc_ana_FeatureSelection(AllData_set2,settings);
% 
% [ind1,ResultsMap1,FeatureTotalScore1] = protosc_ana_MainFeatures(out(1))
% [ind2,ResultsMap2,FeatureTotalScore2] = protosc_ana_MainFeatures(out(1))
% selection                             = FeatureTotalScore1~=0 && FeatureTotalScore2~=0;  
% [R_modelsimilarity,P_modelsimilarity] = corrcoef(FeatureTotalScore1(selection),FeatureTotalScore2(selection)) 
% 
% SS 2020

if ~exist('model','var') || isempty(model)
    model = 'FinalModel';
else
    protosc_check_modelname(out,model)
end
[ResultsMap,FeatureTotalScore]      = protosc_ana_FeatureMap(out,model);
perc_crit                           = prctile(ResultsMap(ResultsMap~=0),crit);
ResultsMap(ResultsMap<perc_crit)    = 0;
ind                                 = find(FeatureTotalScore>=prctile(FeatureTotalScore(FeatureTotalScore~=0),crit));