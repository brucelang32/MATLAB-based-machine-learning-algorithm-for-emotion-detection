function covariateTable = protosc_report_write_covariateTable(filelist,AllData,out,model,crit,filename,projectname)
% function covariateTable = protosc_report_write_covariateTable(filelist,out,model,crit);
%
%
% SS 2020
settings = protosc_Settings;
if ~exist('filelist','var') || isempty(filelist)
    filelist = transpose(1:size(AllData,1));
end
if ~exist('filelist','var') || isempty(filelist)
    filelist = transpose(1:size(AllData,1));
end
if ~exist('model','var') || isempty(model)
    model = 'FinalModel';
end
if ~exist('crit','var') || isempty(crit)
    crit = 50;
end
if ~exist('projectname','var') || isempty(projectname)
    if ~isempty(out.settings.Saving.ProjectName)
        loci = [settings.Saving.savedir out.settings.Saving.ProjectName];
    else
        loci = [settings.Saving.savedir];
    end
else
    loci = [settings.Saving.savedir projectname];
    if ~isfolder([settings.Saving.savedir projectname])
        mkdir(loci)
    end
end
if ~exist('filename','var') || isempty(filename)
    timestamp   = num2str(now);
    filename    = [loci 'Protosc_Covariate_Table_' date timestamp(end-3:end) '.XLSX'];
else
    filename    = [loci filename];
end

Features            = AllData(:,2:end);
covariateTable      = table(filelist);
MainfeatureIndices  = protosc_ana_MainFeatures(out,model,crit);
tol                 = 100;
if length(MainfeatureIndices)>tol
    covars = tol;
    disp(['[In protosc_report_write_covariateTable] Main Features Reduced to ' num2str(tol)])
else
    covars = length(MainfeatureIndices);
end
for ii = 1:covars
    covariateTable = addvars(covariateTable,Features(:,MainfeatureIndices(ii)),'NewVariableNames', ['Feature ' num2str(MainfeatureIndices(ii))]);
end

try
    writetable(covariateTable,filename,'FileType','spreadsheet')
    disp(['[In protosc_report_write_covariateTable] Table Generated and saved as: ' filename])
catch err
    disp('[In protosc_report_write_covariateTable] Writing table to file failed.')
    disp(err.identifier)
    disp(err.message)
end
    

