function protosc_figure_HOGAxes
% function protosc_figure_HOGAxes
% 
% SS 2020

HA          = (mean(imread([protosc_get_root filesep 'Codes' filesep 'protosc_im_HOGAxes2.bmp'])/255,3));
loci        = protosc_im_CenterRect([1 1 220 220],[1 1 size(HA)]);
HOGAxes     = HA(loci(1):loci(3)-3,loci(2):loci(4),1);
image(repmat(HOGAxes,1,1,3)),colormap('gray'),box off, axis square, axis off;
