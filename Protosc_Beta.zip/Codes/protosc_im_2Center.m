function bigim = protosc_im_2Center(smallim,bigim)
% function bigim = protosc_im_2Center(smallim,bigim)
% 

bigim(floor(size(bigim,1)/2 - size(smallim,1)/2)+1 : floor(size(bigim,1)/2 - size(smallim,1)/2)+size(smallim,1),...
    floor(size(bigim,2)/2 - size(smallim,2)/2)+1 : floor(size(bigim,2)/2 - size(smallim,2)/2)+size(smallim,2)) = smallim;
