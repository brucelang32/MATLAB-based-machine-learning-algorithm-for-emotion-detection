function protosc_figure_CombinedAxes
% function protosc_figure_CombinedAxes 
% 
% SS 2020

HA          = round(mean(imread([protosc_get_root filesep 'Codes' filesep 'protosc_im_HOGAxes2.bmp'])/255,3));
loci        = protosc_im_CenterRect([1 1 220 220],[1 1 size(HA)]);
HOGAxes     = HA(loci(1):loci(3)-3,loci(2):loci(4),1);
HAxes       = protosc_im_scale(imresize(HOGAxes(:,:,1),[100 100],'bicubic'));
HAxes(HAxes>.5) = 1;

FA          = round(mean(imread([protosc_get_root filesep 'Codes' filesep 'protosc_im_SFAxes.bmp']),3)/255);
loci        = protosc_im_CenterRect([1 1 300 300],[1 1 size(FA)]);
SFAxes      = FA(loci(1):loci(3),loci(2):loci(4),1);

CAxes       = [SFAxes HAxes];

imagesc(CAxes),colormap('gray'),box off, axis square, axis off;