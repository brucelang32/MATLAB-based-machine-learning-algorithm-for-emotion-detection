function Acc = protosc_get_Accuracy(y,yhat)
% function Acc = protosc_get_Accuracy(y,yhat)
% 
% SS 2019

Acc = mean(y == yhat);




