function [ResultsMap,FeatureTotalScore] = protosc_ana_FeatureMap(out,model,ploton)
% [ResultsMap,FeatureTotalScore] = protosc_ana_FeatureMap(out,model)
% 
% AllData                           = protosc_ana_Features2AllData(AllFeatures);
% out                               = protosc_ana_FeatureSelection(AllData,settings);
% [ResultsMap,FeatureTotalScore]    = protosc_ana_FeatureMap(out,'FinalModel')
% 
% SS 2020



if ~exist('model','var') || isempty(model)
    model = 'FinalModel';
else
    protosc_check_modelname(out,model)
end
if ~exist('ploton','var') || isempty(ploton)
    ploton = 0;
end

ReferenceMap    = out.datainfo.FeatureReferenceMap;
rotatemap       = out.datainfo.rotatemap;
ResultsMap      = zeros(size(ReferenceMap));
b               = zeros(1,out.datainfo.nfeatures);

% w = whos('out');
% if w.class
if ~ischar(model)
    if min(size(model))==1
        for ii = find(model)
            ResultsMap(ReferenceMap==ii) = model(ii);
        end
        FeatureTotalScore = model;
    else
        error('model needs to be a string or a vector');
    end
else
    if strcmpi(model,'Full') || strcmpi(model,'FullModel')
        for jj = 1:size(out.Results.FeatureRankCumSum,2)
            for ii = 1:out.datainfo.nfeatures
                b(ii) = b(ii)+out.Results.RankingScores{jj}(ii);
                ResultsMap(ReferenceMap==ii) = ResultsMap(ReferenceMap==ii)+out.Results.RankingScores{jj}(ii);
            end
        end
    else
        for ii = 1:size(out.Results.FeatureRankCumSum,2)
            b(out.Results.(model).FeatureIndices{ii}) = b(out.Results.(model).FeatureIndices{ii})+out.Results.(model).F1(ii);
        end
        for ii = find(b)
            ResultsMap(ReferenceMap==ii) = b(ii);
        end
    end
    FeatureTotalScore = b;
    if length(size(ResultsMap))==3
        ResultsMap = mean(ResultsMap,3);
    end
end

if rotatemap
    ResultsMap = rot90(ResultsMap);
end

if ploton
    imagesc(ResultsMap)
    axis square
    axis off
    colormap(protosc_figure_colormap)
    colorbar
    title('Feature Reference Map')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize);
end

