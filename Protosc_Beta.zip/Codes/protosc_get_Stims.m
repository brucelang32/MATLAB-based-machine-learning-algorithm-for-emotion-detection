function Stims = protosc_get_Stims(StimFiles,labelnames,wantsize,makegrey,getfaces,addperc)
% function Stims = protosc_get_Stims(StimFiles,labelnames,wantsize,makegrey,getfaces,addperc)
%
% protosc_get_Stims load image-files into cells containing structs, one for
% each class
%
% StimFiles: get with protosc_get_StimFiles
% labelnames: cell containing label namens, index in cell reflects class
% wantsize: size in pixels to scale images to
% makegrey: bolean (0/1) for greyscale
% getfaces: bolean (0/1) for extracting face region only
% addperc: percentages by which to increase face region
%
% SS 2019

Stims = cell(1);
StimFiles = protosc_check_Stims(StimFiles);
if ~exist('StimFiles','var') || isempty(StimFiles)
    error(['[In ' mfilename '] No filenames in StimFiles.'])
end
if exist('labelnames','var')
    labelnames = protosc_check_Cell(labelnames);
end
% wantsize
if ~exist('wantsize','var') || isempty(wantsize)
    wantsize = [100 100];
end
% makegrey
if ~exist('makegrey','var') || isempty(makegrey)
    makegrey = 1;
end
% getfaces
if ~exist('getfaces','var') || isempty(getfaces)
    getfaces = 0;
end
% addperc
if ~exist('addperc','var') || isempty(addperc)
    addperc = 20;
end


for ii = 1:size(StimFiles,2)
    c = 0;
    if ~exist('labelnames','var')
        labelnames{ii} = num2str(ii);
    elseif length(labelnames)<ii
        labelnames{ii} = num2str(ii);
    end
    disp(['[In ' mfilename '] Prepping images with labelname: ' labelnames{ii}])
    for jj = 1:length(StimFiles{ii})
        try
            tempim = double(imread([StimFiles{ii}(jj).fullname]))/255;
        catch
            try
                tempim = double(imread([StimFiles{ii}(jj).name]))/255;
            catch
                tempim = [];
            end
        end
        if getfaces
            try
                tempim = protosc_im_getFace(tempim,addperc);
            catch
                tempim = [];
            end
        end
        try
            if makegrey
                tempim = imresize(mean(tempim,3),wantsize);
            else
                for kk = 1:3
                    tempim2(:,:,kk) = imresize(tempim(:,:,kk),wantsize);
                    tempim = tempim2;
                end
            end
            c = c+1;
            Stims{ii}(c).im                = tempim;
            Stims{ii}(c).label             = ii;
            try
                Stims{ii}(c).labelname         = labelnames{ii};
            end
            Stims{ii}(c).ID                = jj;
            try
                Stims{ii}(c).name              = [StimFiles{ii}(jj).name];
            end
            try
                Stims{ii}(c).fullname          = [StimFiles{ii}(jj).fullname];
            end
            try
                Stims{ii}(c).need2include      = StimFiles{ii}(jj).need2include;
            end
            try
                Stims{ii}(c).need2exclude      = StimFiles{ii}(jj).need2exclude;
            end
            try
                Stims{ii}(c).size              = size(tempim);
            end
            try
                Stims{ii}(c).grey              = makegrey;
            end
            try
                Stims{ii}(c).face              = getfaces;
            end
            if getfaces
                Stims{ii}(c).face_addperc      = addperc;
            end
        catch
            warning(['[In ' mfilename '] ' StimFiles{ii}(jj).fullname ' failed and was not included'])
        end
    end
end


