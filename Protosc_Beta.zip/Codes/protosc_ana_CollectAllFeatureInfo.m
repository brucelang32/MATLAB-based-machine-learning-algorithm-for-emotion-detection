function out = protosc_ana_CollectAllFeatureInfo(Input1,Input2,crit,downsample_curve_ressfactor)
% function out = protosc_ana_CollectAllFeatureInfo(Input1,Input2,crit)
%
%
% SS 2020


% out = out_set3;
% Features = HogFeatures3;
% Data = out;
% info = settings;
% vec = (rand(1,10));
% Input1 = out_set3;%HogFeatures3%FourierFeatures3;%HogFeatures3;

if ~exist('Input1','var') || isempty(Input1)
    error('At least 1 input required')
end
if ~exist('crit','var') || isempty(crit)
    crit = 0;
end
if ~exist('downsample_curve_ressfactor','var') || isempty(downsample_curve_ressfactor)
    downsample_curve_ressfactor = 1;
end
if ~exist('Input2','var') || isempty(Input2)
    w = whos('Input1');
    if strcmpi(w.class,'cell')
        Input2 = protosc_Settings;
    else
        Input2 = 'FinalModel';
    end
end

w = whos('Input2');
if strcmpi(w.class,'struct') % must be settings
    settings    = Input2;
    model       = 'FinalModel';
elseif strcmpi(w.class,'char') % model be a model
    model       = Input2;
    settings    = Input1(1).settings;
    reacquiresettings = 1;
elseif strcmpi(w.class,'double')
    crit        = Input2;
    model       = 'FinalModel';
    settings    = protosc_Settings;
end



%check existing info
w = whos('Input1');
if strcmpi(w.class,'cell') % must be feature matrix
    for ii = 1:size(Input1,2)
        nfeatures(ii) = size(Input1{1},2);
        if size(Input1{ii},1)>1
            Features{ii} = mean(Input1{ii});
        else
            Features{ii} = Input1{ii};
        end
    end
elseif strcmpi(w.class,'double') % must be vector of weigths
    nfeatures = size(Input1,2);
    for ii = 1:size(Input1,1)
        Features{1} = mean(Input1);
    end
elseif strcmpi(w.class,'struct') % must be FSoutput
    for jj = 1:size(Input1,2)
        protosc_check_modelname(Input1(jj),model)
        nfeatures(jj) = Input1(jj).datainfo.nfeatures;
        if strcmpi(model,'FullModel')
            Features{jj} = [];
            tempvar = [];
            for ii = 1:size(Input1(jj).Results.(model).Accuracy,2)
                Features{jj}(ii,:) = ones(1,nfeatures(jj))*Input1(jj).Results.(model).Accuracy(ii);
                tempvar(ii,:) = Input1(jj).Results.RankingScores{ii};
            end
        else
            Features{jj} = [];
            for ii = 1:size(Input1(jj).Results.(model).Accuracy,2)
                %                 Features{jj}(Input1(jj).Results.(model).FeatureIndices{ii}) = ...
                %                     Features{jj}(Input1(jj).Results.(model).FeatureIndices{ii})+...
                %                     Input1(jj).Results.(model).Accuracy(...
                %                     mod(1-1,Input1(jj).settings.Main.nfolds)+1);
                Features{jj}(ii,:) = nan(1,nfeatures(jj));
                Features{jj}(ii,Input1(jj).Results.(model).FeatureIndices{ii}) = Input1(jj).Results.(model).Accuracy(ii);
            end
        end
        %features, sum
        Features_Sumscore{jj}       = nansum(Features{jj});
        %features, ranked
        if ~strcmpi(model,'FullModel')
            Features_Rankscore{jj}  = protosc_im_scale(Features_Sumscore{jj});
        else
            Features_Rankscore{jj}  = protosc_im_scale(mean(tempvar));
        end
        
        % average associated performance
        Features{jj}                                            = nanmean(Features{jj});
        Features{jj}(isnan(Features{jj}))                       = 0;
    end
end


perc_crit                                   = 0;
for ii = 1:size(Features,2)
    out(ii).FourierResultsMap                   = [];
    out(ii).FourierFrebuild                     = [];
    out(ii).FourierSFrange                      = [];
    out(ii).FourierSFcurve                      = [];
    out(ii).FourierOrirange                     = [];
    out(ii).FourierOricurve                     = [];
    out(ii).HOGResultsMap                       = [];
    out(ii).HOGRebuildMap                       = [];
    out(ii).HOGXdist                            = [];
    out(ii).HOGYdist                            = [];
    out(ii).HOGorirange                         = [];
    out(ii).HOGOricurve                         = [];
    out(ii).SFHOG_SF_avRank                     = [];
    out(ii).SFHOG_HOG_perc                      = [];
    out(ii).SFHOG_ratio                         = [];
    
    if reacquiresettings
        settings    = Input1(ii).settings;
    end
    %general
    [FeatureReferenceMap,dataType,settings]     = protosc_get_datatype(nfeatures(ii),settings);
    out(ii).dataType                            = dataType;
    out(ii).settings                            = settings;
    ResultsMap                                  = zeros(size(FeatureReferenceMap));
    for jj = 1:nfeatures(ii)
        ResultsMap(FeatureReferenceMap==jj) = Features_Rankscore{ii}(jj);
    end
    if crit>0
        perc_crit = prctile(Features_Rankscore{ii}(Features_Rankscore{ii}~=0),crit);
        ResultsMap(ResultsMap<perc_crit) = 0;
    end
    
    %fourier specific
    if strcmpi(dataType,'Fourier features ')
        FourierMap                  = rot90(ResultsMap);
        [SFcurve,sfrange]           = protosc_get_SFCruve(FourierMap,settings.Features.Fourier_nSF*downsample_curve_ressfactor,1);
        [Oricurve,orirange]         = protosc_get_ORICruve(FourierMap,settings.Features.Fourier_nOri*downsample_curve_ressfactor,1);
        ResultsMapSmooth            = conv2(ResultsMap,protosc_im_GaussPatch(size(ResultsMap,1)/20,size(ResultsMap,1)/40,1,0),'same');
        Frebuild                    = protosc_im_rebuildfft(fftshift(ResultsMapSmooth)./(fftshift(protosc_im_radimap(200)+.0001)),rand(200)*pi*2-pi);
        out(ii).FourierResultsMap   = FourierMap;
        out(ii).FourierSFrange      = sfrange;
        out(ii).FourierSFcurve      = SFcurve*100;
        out(ii).FourierOrirange     = orirange;
        out(ii).FourierOricurve     = Oricurve*100;
        out(ii).FourierFrebuild     = Frebuild;
        %hog specific
    elseif strcmpi(dataType,'HOG features ')
        HOGMap                      = ResultsMap;
        xes                         = sum(sum(ResultsMap,3),1);
        xes                         = xes/sum(xes)*100;
        yes                         = sum(sum(ResultsMap,3),2)';
        yes                         = yes/sum(yes)*100;
        orirange                    = (180/(settings.Features.HOG_nBins*2)): (180/settings.Features.HOG_nBins) :180;
        Oricurve                    = squeeze(sum(sum(ResultsMap,1),2))';
        Oricurve                    = Oricurve/sum(Oricurve)*100;
        temp                        = Features{ii};
        temp(temp<perc_crit)        = 0;
        TransMap                    = protosc_get_HOGtranslation(temp,settings);
        out(ii).HOGResultsMap       = nansum(ResultsMap,3);
        out(ii).HOGRebuildMap       = TransMap;
        out(ii).HOGXdist            = xes;
        out(ii).HOGYdist            = yes;
        out(ii).HOGorirange         = orirange;
        out(ii).HOGOricurve         = fliplr(Oricurve);
        %sfhog specific
    elseif strcmpi(dataType,'Fourier & HOG - dependent')
        %Fourier Section
        fend                                 = settings.Features.Fourier_nOri*settings.Features.Fourier_nSF;
        [FeatureReferenceMap,~,settings]     = protosc_get_datatype(fend,settings);
        ResultsMap                           = zeros(size(FeatureReferenceMap));
        for jj = 1:fend
            ResultsMap(FeatureReferenceMap==jj) = Features_Rankscore{ii}(jj);
        end
        if crit>0
            perc_crit = prctile(Features_Rankscore{ii}(Features_Rankscore{ii}~=0),crit);
            ResultsMap(ResultsMap<perc_crit) = 0;
        end
        FourierMap                  = rot90(ResultsMap);
        [SFcurve,sfrange]           = protosc_get_SFCruve(FourierMap,settings.Features.Fourier_nSF*downsample_curve_ressfactor,0);
        SFcurve                     = (SFcurve/sum(SFcurve))*(mean(Features{ii}(1:fend)) / (mean(Features{ii}(1:fend))+mean(Features{ii}(fend+1:end))))*100;
        [Oricurve,orirange]         = protosc_get_ORICruve(FourierMap,settings.Features.Fourier_nOri*downsample_curve_ressfactor,0);
        Oricurve                    = (Oricurve/sum(Oricurve))*(mean(Features{ii}(1:fend)) / (mean(Features{ii}(1:fend))+mean(Features{ii}(fend+1:end))))*100;
        ResultsMapSmooth            = conv2(ResultsMap,protosc_im_GaussPatch(size(ResultsMap,1)/20,size(ResultsMap,1)/40,1,0),'same');
        Frebuild                    = protosc_im_rebuildfft(fftshift(ResultsMapSmooth)./(fftshift(protosc_im_radimap(200)+.0001)),rand(200)*pi*2-pi);
        out(ii).FourierResultsMap   = FourierMap;
        out(ii).FourierSFrange      = sfrange;
        out(ii).FourierSFcurve      = SFcurve;
        out(ii).FourierOrirange     = orirange;
        out(ii).FourierOricurve     = Oricurve;
        out(ii).FourierFrebuild     = Frebuild;
        
        %HOG Section
        [FeatureReferenceMap,~,settings]            = protosc_get_datatype(length(fend+1:length(Features{ii})),settings);
        ResultsMap                                  = zeros(size(FeatureReferenceMap));
        FeatureReferenceMap                         = FeatureReferenceMap+fend;
        for jj = fend+1:length(Features{ii})
            ResultsMap(FeatureReferenceMap==jj) = Features_Rankscore{ii}(jj);
        end
        if crit>0
            perc_crit = prctile(Features_Rankscore{ii}(Features_Rankscore{ii}~=0),crit);
            ResultsMap(ResultsMap<perc_crit) = 0;
        end
        HOGMap                      = ResultsMap;
        xes                         = sum(sum(ResultsMap,3),1);
        xes                         = (xes/sum(xes))*(sum(Features{ii}(fend+1:length(Features{ii}))) / (sum(Features{ii})))*100;
        yes                         = sum(sum(ResultsMap,3),2)';
        yes                         = (yes/sum(yes))*(sum(Features{ii}(fend+1:length(Features{ii}))) / (sum(Features{ii})))*100;
        orirange                    = (180/(settings.Features.HOG_nBins*2)): (180/settings.Features.HOG_nBins) :180;
        Oricurve                    = squeeze(sum(sum(ResultsMap,1),2))';
        Oricurve                    = (Oricurve/sum(Oricurve))*(sum(Features{ii}(fend+1:length(Features{ii}))) / (sum(Features{ii})))*100;
        temp                        = Features{ii}(fend+1:length(Features{ii}));
        temp(temp<perc_crit)        = 0;
        TransMap                    = protosc_get_HOGtranslation(temp,settings);
        out(ii).HOGResultsMap       = nansum(ResultsMap,3);
        out(ii).HOGRebuildMap       = TransMap;
        out(ii).HOGXdist            = xes;
        out(ii).HOGYdist            = yes;
        out(ii).HOGorirange         = orirange;
        out(ii).HOGOricurve         = fliplr(Oricurve);
        out(ii).SFHOG_SF_avRank     = mean(Features_Rankscore{ii}(1:fend));
        out(ii).SFHOG_HOG_perc      = mean(Features_Rankscore{ii}(fend+1:length(Features_Rankscore{ii})));
        out(ii).SFHOG_ratio         = mean(Features_Rankscore{ii}(1:fend))/mean(Features_Rankscore{ii}(fend+1:length(Features_Rankscore{ii})));
    else
        error('Incompatible data Type')
    end
end





