function exclude = protosc_get_HOGExclusion(excludeMat,settings)
% exclude = protosc_get_HOGExclusion(CellSize,nBins,excludeMat)
%
% SS 2019

if ~exist('settings','var') || isempty(settings)
    settings = protosc_Settings;
end
CellSize            = settings.Features.HOG_cellsize;
NumBins             = settings.Features.HOG_nBins;
imsize              = size(excludeMat);
c                   = 1;
c2                  = 1;
ReferenceMap        = nan(floor(imsize(1)/CellSize(1)),floor(imsize(2)/CellSize(2)),NumBins);
nHOGs               = length(ReferenceMap(:));
for start = 1:NumBins:nHOGs
    ReferenceMap(c,c2,:)           = start:start+(NumBins-1);%featurecolumnnumber;
    c = c+1;
    if c > floor(imsize(1)/CellSize(1))
        c2 = c2+1;
        c = 1;
    end
end
for ii = 1:NumBins
    bigColumnMap(:,:,ii) = imresize(ReferenceMap(:,:,ii),CellSize(1),'nearest');
end
exclude_t = [];
for ii = 1:NumBins
    t = bigColumnMap(:,:,ii);
    exclude_t = [exclude_t unique(t(excludeMat==1))'];
end
exclude = unique(exclude_t);
