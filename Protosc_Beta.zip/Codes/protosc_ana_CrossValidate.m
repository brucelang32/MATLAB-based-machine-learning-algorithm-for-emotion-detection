function [p,CM] = protosc_ana_CrossValidate(TrainSet,TestSet,trainSetOut,model)
% [performance_per_fold,CM] = protosc_ana_CrossValidate(TrainSet,TestSet,trainSetOut,model)
% 
% example:
% AllData_set1                = protosc_ana_Features2AllData(AllFeatures_set1);
% AllData_set2                = protosc_ana_Features2AllData(AllFeatures_set2);
% trainSetOut                 = protosc_ana_FeatureSelection(AllData_set1,settings);
% [performance_per_fold,CM]   = protosc_ana_CrossValidate(AllData_set1,AllData_set2,trainSetOut,'FinalModel');
% protosc_figure_CM(CM)
% 
% SS 2020


if ~exist('trainSetOut','var')
    trainSetOut.settings = protosc_Settings;
    fs = 0;
else
    fs = 1;
end
if ~exist('model','var') || isempty(model)
    model = 'FinalModel';
else
    protosc_check_modelname(trainSetOut,model)
end
try
    MLmodel           = eval(['@' trainSetOut.settings.Main.Classifier]);
catch
    MLmodel           = eval(['@' char(trainSetOut.settings.Main.Classifier)]);
end
if strcmpi(trainSetOut.settings.Wrapper.FinalModelSelection,'Accuracy')
    CritFunction = @protosc_perf_Accuracy;
else
    CritFunction = @protosc_perf_F1Macro;
end
if fs
    t = trainSetOut.settings.Wrapper.FinalModelSelection;
    for ii = 1:length(trainSetOut.Results.(model).(t))
        cvm         = MLmodel(TrainSet(:,[1 trainSetOut.Results.(model).FeatureIndices{ii}]));
        ys          = TestSet(:,1)';
        yhats       = cvm.predictFcn(TestSet(:,trainSetOut.Results.(model).FeatureIndices{ii}+1))';
        p(ii)       = CritFunction(ys,yhats);
        CM(:,:,ii)  = confusionmat(ys,yhats);
    end
else
    for ii = 1:trainSetOut.Main.nfolds
        cvm         = MLmodel(TrainSet(:,[1 trainSetOut.Results.(model).FeatureIndices{ii}]));
        ys          = TestSet(:,1)';
        yhats       = cvm.predictFcn(TestSet(:,trainSetOut.Results.(model).FeatureIndices{ii}+1))';
        p(ii)       = CritFunction(ys,yhats);
        CM(:,:,ii)  = confusionmat(ys,yhats);
    end
end
    
