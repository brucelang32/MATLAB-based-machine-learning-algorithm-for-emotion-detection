function [sorted,originalindex,score]= protosc_sortscore(in,type)
% function [sorted,originalindex,score]= protosc_sortscore(in,type)
%
% SS 2019

if exist('in','var') && ~isempty(in)
    if ~exist('type','var') || isempty(type)
        type = 'down';
    end
    if strcmpi(type,'up')
        type = 'ascend';
    elseif strcmpi(type,'down')
        type = 'descend';
    end
    [sorted,originalindex] = sort(in,type);
    scores = fliplr(1:length(in))/length(in);
    c = 0;
    for ii = originalindex
        c = c+1;
        score(ii) = scores(c);
    end
else
    warning('missing inputs')
    sorted = [];
    originalindex = [];
    score = [];
end
