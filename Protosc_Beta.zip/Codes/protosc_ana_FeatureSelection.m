function out = protosc_ana_FeatureSelection(AllData,settings)
% out = protosc_ana_FeatureSelection(AllData,settings)
%
% example:
% StimFiles       = protosc_get_StimFiles(imdir);
% Stims           = protosc_get_Stims(StimFiles);
% FourierFeatures = protosc_get_Fourier_Mag(Stims,settings);
% AllData         = protosc_ana_Features2AllData(FourierFeatures);
% out             = protosc_ana_FeatureSelection(AllData,settings);
% 
% SS 2019

if ~exist('settings','var') || isempty(settings)
    settings        = protosc_Settings;
    out.settings    = settings;
else
    out.settings    = settings;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Get info
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
out.codeinfo.mfile      = mfilename;
out.codeinfo.codefolder = [protosc_get_root filesep 'Codes'];
out.codeinfo.ran_from   = pwd;
out.codeinfo.version    = protosc_get_versioninfo;
out.codeinfo.date       = date;

out.datainfo.size       = size(AllData);
out.datainfo.nfeatures  = size(AllData,2)-1;
out.datainfo.nclasses   = length(unique(AllData(:,1)));
out.datainfo.classes    = unique(AllData(:,1))';
c = 0;
for ii = out.datainfo.classes
    c = c+1;
    out.datainfo.classbalances(c) = sum(AllData(:,1)==ii);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Prep Settings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isempty(settings.Features.FeatureReferenceMap)
    % figure out if this is a Fourier or HOG based analysis
    if isfield(settings.Features,'HOG_ImSize')
        if ~isempty(settings.Features.HOG_ImSize)
            expect_n_hog = (settings.Features.HOG_ImSize(2)/settings.Features.HOG_cellsize(1))*...
                (settings.Features.HOG_ImSize(1)/settings.Features.HOG_cellsize(2))*...
                settings.Features.HOG_nBins;
        else
            settings.Features.HOG_ImSize = [200 200];
            expect_n_hog = (settings.Features.HOG_ImSize(2)/settings.Features.HOG_cellsize(1))*...
                (settings.Features.HOG_ImSize(1)/settings.Features.HOG_cellsize(2))*...
                settings.Features.HOG_nBins;
        end
    else
        expect_n_hog = 0;
    end
    if ~isempty(settings.Features.Fourier_nOri)
        expect_n_fourier = settings.Features.Fourier_nOri*settings.Features.Fourier_nSF;
    else
        expect_n_fourier = -1;
    end
    if  expect_n_hog == expect_n_fourier
        out.datainfo.dataType                   = 'Ambiguous, could be HOG, could be Fourier, find our solution in: out.datainfo.FeatureReferenceMap';
        out.datainfo.FeatureReferenceMap        = reshape(1:out.datainfo.nfeatures,ceil(sqrt(out.datainfo.nfeatures)),ceil(sqrt(out.datainfo.nfeatures)));
    else
        if expect_n_hog == out.datainfo.nfeatures
            out.datainfo.dataType                   = 'HOG features ';
            out.datainfo.FeatureReferenceMap        = protosc_get_HOG_refmap(rand(settings.Features.HOG_ImSize),settings);
            out.datainfo.rotatemap                  = 0;
        elseif expect_n_fourier == out.datainfo.nfeatures && isfield(settings.Features,'Fourier_ImSize')
            out.datainfo.dataType                   = 'Fourier features ';
            out.datainfo.FeatureReferenceMap        = protosc_get_Fourier_RefGrid(rand(200),settings);
            out.datainfo.rotatemap                  = 1;
            %         elseif (expect_n_fourier+expect_n_hog) == out.datainfo.nfeatures
            %             out.datainfo.dataType                   = 'combined Fourier & HOG features ';
            %             out.datainfo.FeatureReferenceMap        = [rot90(protosc_get_Fourier_RefGrid(rand(settings.Features.Fourier_ImSize),settings)) protosc_get_HOG_refmap(rand(settings.Features.Fourier_ImSize),settings)];
            %             out.datainfo.rotatemap                  = 0;
        else
            out.datainfo.dataType                   = 'Incompatible reference map, find our solution in: out.datainfo.FeatureReferenceMap';
            dim                                     = ceil(sqrt(out.datainfo.nfeatures));
            out.datainfo.FeatureReferenceMap        = reshape(1:dim^2,dim,dim);
            out.datainfo.rotatemap                  = 0;
        end
    end
else
    out.datainfo.dataType                   = 'Unknown, but map known';
    out.datainfo.FeatureReferenceMap        = settings.Features.FeatureReferenceMap;
    out.datainfo.rotatemap                  = 0;
end
try
    MLmodel           = eval(['@' out.settings.Main.Classifier]);
catch
    MLmodel           = eval(['@' char(out.settings.Main.Classifier)]);
end
try
    RankFunc          = eval(['@' out.settings.Ranking.func]);
catch
    RankFunc          = eval(['@' char(out.settings.Ranking.func)]);
end

try
    out.settings.Display.identifier = num2str(out.settings.Display.identifier);
end
if ~isempty(out.settings.Main.foldingindices)
    if length(unique(out.settings.Main.foldingindices))~=out.settings.Main.nfolds
        out.settings.Main.nfolds = length(unique(out.settings.Main.foldingindices));
        disp(['[ In ' mfilename '] adjusted nfolds to match the folding indices supplied.'])
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check AllData
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% out.settings.Features.force_exclude = [out.settings.Features.force_exclude find(isnan(sum(AllData(:,2:end))))];
AllData(isnan(AllData))             = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Errors / Warnings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if out.settings.Main.nfolds<2
    error(['[In ' mfilename ' ID:' out.settings.Display.identifier '] nfolds needs to be bigger than 1'])
end
if out.settings.Wrapper.startmodelsize >= out.datainfo.nfeatures
    error(['[In ' mfilename ' ID:' out.settings.Display.identifier '] no selection possible (startmodelsize ' num2str(out.settings.Wrapper.startmodelsize) ' >= nfeatures ' num2str(out.datainfo.nfeatures) ')'])
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Split Data Set
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isempty(out.settings.Main.foldingindices)
    out.settings.Main.foldingindices  = protosc_get_foldingindices(AllData,out.settings.Main.nfolds);
else
    out.settings.Main.foldingindices  = out.settings.Main.foldingindices;
end

for ifold = 1:out.settings.Main.nfolds
    if out.settings.Display.showintremfeedback
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] Starting fold ' num2str(ifold) ' out of ' num2str(out.settings.Main.nfolds)])
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% Split Data [Holdout and Train+Validation]
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    HoldOutData         = AllData(out.settings.Main.foldingindices==ifold,:);%get_BalencedSample(AllData(out.foldingindices==ifold,:),100);
    TrainValData        = AllData(out.settings.Main.foldingindices~=ifold,:); %Train+Validation
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% Get Rank Order & Scores, Progression & check inclusion
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if out.settings.Display.showintremfeedback
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] Creating a univariate ranking for feature selection'])
    end
    [ind,currentrankscores]                 = RankFunc(TrainValData);
    out.Results.RankingScores{ifold}        = currentrankscores;
    out.Results.FeatureRanks{ifold}         = ind;
    out.Results.InclusionBolean{ifold}      = ones(1,size(out.Results.RankingScores{ifold},2));
    [MaxFeatures,Progression]               = protosc_get_MaxFeatures(currentrankscores,out.settings.Main.MaxFeaturesCrit);
    out.Results.FeatureRankCumSum{ifold}    = Progression;
    out.Results.MaxModelParams(ifold)       = MaxFeatures(1);
    
    if ~isempty(out.settings.Features.force_exclude_crit)
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] Excluding low information features from selection'])
        dropf           = ind(Progression>=out.settings.Features.force_exclude_crit);
        out.Results.InclusionBolean{ifold}(dropf)  = 0;
    end
    if ~isempty(out.settings.Features.force_exclude)
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] Excluding features from selection'])
        out.Results.InclusionBolean{ifold}(out.settings.Features.force_exclude) = 0;
    end

    out.Results.RankingScores{ifold}(out.Results.InclusionBolean{ifold}==0) = 0;
    [~,ind] = sort(out.Results.RankingScores{ifold},'descend');
    ind = ind(1:sum(out.Results.InclusionBolean{ifold}==1));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% Set Search Space Size
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if isempty(out.settings.Wrapper.SearchSpaceSize)
        out.Results.SearchSpaceSizes(ifold) = out.Results.MaxModelParams(ifold)*out.settings.Wrapper.SearchSpaceSizeScalar;
        if out.Results.SearchSpaceSizes(ifold) > length(currentrankscores)
            out.Results.SearchSpaceSizes(ifold) = length(currentrankscores);
        end
    else
        out.Results.SearchSpaceSizes(ifold) = out.settings.Wrapper.SearchSpaceSize;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% Wrapper: Feature Selection
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    IncludedParams                  = [];
    if strcmpi(out.settings.Wrapper.Method,'Wrapper_MLP')
        out.settings.Wrapper.maxincperit = ceil(out.settings.Wrapper.maxincperitf*MaxFeatures);
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] Starting Wrapper Approach with search space size ' num2str(out.Results.SearchSpaceSizes(ifold))])
        protosc_ana_Wrapper_MLP
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% trim if needed
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if length(IncludedParams)>out.Results.MaxModelParams(ifold)
        IncludedParams = IncludedParams(1:out.Results.MaxModelParams(ifold));
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Retrain for Cross Validation & Performances
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Balence Training Data
    TrainValData_balence_ind                                            = protosc_get_BalencedSample(TrainValData,100);
    TrainValData_balence                                                = TrainValData(TrainValData_balence_ind,:);
    
    HoldOutData_balence_ind                                             = protosc_get_BalencedSample(HoldOutData,100);
    HoldOutData                                                         = HoldOutData(HoldOutData_balence_ind,:);
    
    out.Results.reallabels{ifold}                   = HoldOutData(:,1);
    if out.settings.Display.showintremfeedback
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] Feature Selection fold ' num2str(ifold) ' finished: '])
    end
    
    % Retrain and test on HoldOut Set for CV performance: Full
    basemodel                                                           = MLmodel(TrainValData_balence);
    out.Results.FullModel.predictedlabels{ifold}                        = basemodel.predictFcn(HoldOutData(:,2:end));
    out.Results.FullModel.F1(ifold)                                     = protosc_perf_F1Macro(HoldOutData(:,1),out.Results.FullModel.predictedlabels{ifold});
    out.Results.FullModel.Accuracy(ifold)                               = mean(HoldOutData(:,1)==out.Results.FullModel.predictedlabels{ifold});
    if out.settings.Display.showintremfeedback
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] Full Model Accuracy / F1: ' num2str(out.Results.FullModel.Accuracy(end)*100) '/' num2str(out.Results.FullModel.F1(ifold))])
    end
    
    % Retrain and test on HoldOut Set for CV performance: Filter
    out.Results.Filter.FeatureIndices{ifold}                            = ind(1:out.Results.MaxModelParams(ifold));
    filtermodel                                                         = MLmodel(TrainValData_balence(:,[1 out.Results.Filter.FeatureIndices{ifold}+1]));
    out.Results.Filter.predictedlabels{ifold}                           = filtermodel.predictFcn(HoldOutData(:,out.Results.Filter.FeatureIndices{ifold}+1));
    out.Results.Filter.F1(ifold)                                        = protosc_perf_F1Macro(HoldOutData(:,1),out.Results.Filter.predictedlabels{ifold});
    out.Results.Filter.Accuracy(ifold)                                  = mean(HoldOutData(:,1)==out.Results.Filter.predictedlabels{ifold});
    
    if out.settings.Display.showintremfeedback
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] Filter Accuracy / F1: ' num2str(out.Results.Filter.Accuracy(end)*100) '/' num2str(out.Results.Filter.F1(ifold))])
    end
    
    % Retrain and test on HoldOut Set for CV performance: Wrapper
    out.Results.Wrapper.FeatureIndices{ifold}                           = IncludedParams;
    wrappermodel                                                        = MLmodel(TrainValData_balence(:,[1 out.Results.Wrapper.FeatureIndices{ifold}+1]));
    out.Results.Wrapper.predictedlabels{ifold}                          = wrappermodel.predictFcn(HoldOutData(:,out.Results.Wrapper.FeatureIndices{ifold}+1));
    out.Results.Wrapper.F1(ifold)                                       = protosc_perf_F1Macro(HoldOutData(:,1),out.Results.Wrapper.predictedlabels{ifold});
    out.Results.Wrapper.Accuracy(ifold)                                 = mean(HoldOutData(:,1)==out.Results.Wrapper.predictedlabels{ifold});
    if out.settings.Display.showintremfeedback
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] Wrapper Accuracy / F1: ' num2str(out.Results.Wrapper.Accuracy(end)*100) '/' num2str(out.Results.Wrapper.F1(ifold))])
    end
    
    % Retrain and test on HoldOut Set for CV performance: Random
    randomfeatures                                                      = protosc_Shuffle(find(out.Results.InclusionBolean{ifold}));
    out.Results.RandomModel.FeatureIndices{ifold}                       = randomfeatures(1:out.Results.MaxModelParams(ifold));
    randomfeaturesmodel                                                 = MLmodel(TrainValData_balence(:,[1 out.Results.RandomModel.FeatureIndices{ifold}+1]));
    out.Results.RandomModel.predictedlabels{ifold}                      = randomfeaturesmodel.predictFcn(HoldOutData(:,out.Results.RandomModel.FeatureIndices{ifold}+1));
    out.Results.RandomModel.F1(ifold)                                   = protosc_perf_F1Macro(HoldOutData(:,1),out.Results.RandomModel.predictedlabels{ifold});
    out.Results.RandomModel.Accuracy(ifold)                             = mean(HoldOutData(:,1)==out.Results.RandomModel.predictedlabels{ifold});
    if out.settings.Display.showintremfeedback
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] RandomModel Accuracy / F1: ' num2str(out.Results.RandomModel.Accuracy(end)*100) '/' num2str(out.Results.RandomModel.F1(ifold))])
    end
    
    % Retrain and test on HoldOut Set for CV performance: Pseudo Random
    % (not included in filter or wrapper params)
    tind = out.Results.InclusionBolean{ifold};
    tind(out.Results.Wrapper.FeatureIndices{ifold}) = 0;
    tind(out.Results.Filter.FeatureIndices{ifold}) = 0;
%     pos_randomfeatures_ex                                               = protosc_check_PosibleParams(ind,out.Results.Wrapper.FeatureIndices{ifold});
%     pos_randomfeatures_ex                                               = protosc_check_PosibleParams(pos_randomfeatures_ex,out.Results.Filter.FeatureIndices{ifold});
    randomfeatures_ex                                                   = protosc_Shuffle(find(tind));
    out.Results.PseudoRandomModel.FeatureIndices{ifold}                 = randomfeatures_ex(1:out.Results.MaxModelParams(ifold));
    randomfeaturesexmodel                                               = MLmodel(TrainValData_balence(:,[1 out.Results.PseudoRandomModel.FeatureIndices{ifold}+1]));
    out.Results.PseudoRandomModel.predictedlabels{ifold}                = randomfeaturesexmodel.predictFcn(HoldOutData(:,out.Results.PseudoRandomModel.FeatureIndices{ifold}));
    out.Results.PseudoRandomModel.F1(ifold)                             = protosc_perf_F1Macro(HoldOutData(:,1),out.Results.PseudoRandomModel.predictedlabels{ifold});
    out.Results.PseudoRandomModel.Accuracy(ifold)                       = mean(HoldOutData(:,1)==out.Results.PseudoRandomModel.predictedlabels{ifold});
    if out.settings.Display.showintremfeedback
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] PseudoRandomModel Accuracy / F1: ' num2str(out.Results.PseudoRandomModel.Accuracy(end)*100) '/' num2str(out.Results.PseudoRandomModel.F1(ifold))])
        disp(' ')
    end
    
    % Select final model
    findbestmodel                                                       = [out.Results.Filter.(out.settings.Wrapper.FinalModelSelection)(ifold) ...
        out.Results.Wrapper.(out.settings.Wrapper.FinalModelSelection)(ifold) out.Results.RandomModel.(out.settings.Wrapper.FinalModelSelection)(ifold) ...
        out.Results.PseudoRandomModel.(out.settings.Wrapper.FinalModelSelection)(ifold)];
    selbestmodel                                                        = find(findbestmodel==max(findbestmodel),1,'first');
    modelnames                                                          = {'Filter' 'Wrapper' 'RandomModel' 'PseudoRandomModel'};
    if ifold == 1
        out.Results.FinalModel.ModelContent                             = [0 0 0 0];
    end
    out.Results.FinalModel.ModelContent(selbestmodel)                   = out.Results.FinalModel.ModelContent(selbestmodel)+1;
    out.Results.FinalModel.FeatureIndices{ifold}                        = out.Results.(modelnames{selbestmodel}).FeatureIndices{ifold};
    out.Results.FinalModel.predictedlabels{ifold}                       = out.Results.(modelnames{selbestmodel}).predictedlabels{ifold};
    out.Results.FinalModel.F1(ifold)                                    = out.Results.(modelnames{selbestmodel}).F1(ifold);
    out.Results.FinalModel.Accuracy(ifold)                              = out.Results.(modelnames{selbestmodel}).Accuracy(ifold);
    
    % Build and run control models
    if out.settings.Display.showintremfeedback
        disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] Generating control models.'])
    end
        
    ControlTrain                                                        = nan(size(TrainValData_balence));
    ControlTrain(:,1)                                                   = TrainValData_balence(:,1);
    ControlTrain(:,2:end)                                               = protosc_Shuffle(TrainValData_balence(:,2:end));
    Controltest                                                         = nan(size(HoldOutData));
    Controltest(:,1)                                                    = HoldOutData(:,1);
    Controltest(:,2:end)                                                = protosc_Shuffle(HoldOutData(:,2:end));
    ControlFull                                                         = MLmodel(ControlTrain);
    out.Results.ControlFull.predictedlabels{ifold}                      = ControlFull.predictFcn(Controltest(:,2:end));
    out.Results.ControlFull.F1(ifold)                                   = protosc_perf_F1Macro(Controltest(:,1),out.Results.ControlFull.predictedlabels{ifold});
    out.Results.ControlFull.Accuracy(ifold)                             = mean(Controltest(:,1)==out.Results.ControlFull.predictedlabels{ifold});
    
    for wmodel = 1:length(modelnames)
        useinds                                                             = out.Results.(modelnames{wmodel}).FeatureIndices{ifold};
        ControlName                                                         = ['Control' modelnames{wmodel}];
        ControlTrain                                                        = nan(size(TrainValData_balence));
        ControlTrain(:,1)                                                   = TrainValData_balence(:,1);
        ControlTrain(:,useinds+1)                                           = protosc_Shuffle(TrainValData_balence(:,useinds+1));
        Controltest                                                         = nan(size(HoldOutData));
        Controltest(:,1)                                                    = HoldOutData(:,1);
        Controltest(:,useinds+1)                                            = protosc_Shuffle(HoldOutData(:,useinds+1));
        ControlModel                                                        = MLmodel(ControlTrain(:,[1 useinds+1]));
        out.Results.(ControlName).predictedlabels{ifold}                    = ControlModel.predictFcn(Controltest(:,useinds+1));
        out.Results.(ControlName).F1(ifold)                                 = protosc_perf_F1Macro(Controltest(:,1),out.Results.ControlFull.predictedlabels{ifold});
        out.Results.(ControlName).Accuracy(ifold)                           = mean(Controltest(:,1)==out.Results.ControlFull.predictedlabels{ifold});
    end
    
    % Select final control model
    findbestcontrolmodel                                                = [out.Results.ControlFilter.(out.settings.Wrapper.FinalModelSelection)(ifold) ...
        out.Results.ControlWrapper.(out.settings.Wrapper.FinalModelSelection)(ifold) out.Results.ControlRandomModel.(out.settings.Wrapper.FinalModelSelection)(ifold) ...
        out.Results.ControlPseudoRandomModel.(out.settings.Wrapper.FinalModelSelection)(ifold)];
    selbestconrolmodel                                                  = find(findbestcontrolmodel==max(findbestcontrolmodel),1,'first');
    controlmodelnames                                                   = {'ControlFilter' 'ControlWrapper' 'ControlRandomModel' 'ControlPseudoRandomModel'};
    if ifold == 1
        out.Results.ControlFinalModel.ModelContent                      = [0 0 0 0];
    end
    out.Results.ControlFinalModel.ModelContent(selbestmodel)            = out.Results.FinalModel.ModelContent(selbestmodel)+1;
    out.Results.ControlFinalModel.predictedlabels{ifold}                = out.Results.(controlmodelnames{selbestconrolmodel}).predictedlabels{ifold};
    out.Results.ControlFinalModel.F1(ifold)                             = out.Results.(controlmodelnames{selbestconrolmodel}).F1(ifold);
    out.Results.ControlFinalModel.Accuracy(ifold)                       = out.Results.(controlmodelnames{selbestconrolmodel}).Accuracy(ifold);
    
    % Visualize Results
    if out.settings.Display.showintremfeedback
        if ifold == 1
            cf = figure('color',[1 1 1],'Position',[100 100 1000 500]);
        end
        if ifold ~= out.settings.Main.nfolds
            out.settings.Saving.autosaveFIG=0;
        else
            out.settings.Saving.autosaveFIG=settings.Saving.autosaveFIG;
        end
        protosc_figure_results_allfolds(out,cf);
        pause(.1)
    end
end
if out.settings.Display.showfinalfeedback
    disp(' ')
    disp(['[In ' mfilename ' ID:' out.settings.Display.identifier '] ***Finished***'])
    disp(' ')
    disp(' ')
end
if settings.Saving.autosaveANA
    timestamp   = num2str(now);
    filename    = ['Protosc_FeatureSelectionAnalysis_' date timestamp(end-3:end)];
    save([protosc_get_root filesep 'SavedFiles' filesep filename],'out')
    disp(['feature Selection Analysis Output Saved in: ' protosc_get_root filesep 'SavedFiles' filesep filename '.mat'])
end




