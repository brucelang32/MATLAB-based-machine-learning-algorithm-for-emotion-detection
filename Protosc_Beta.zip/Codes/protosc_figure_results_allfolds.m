function protosc_figure_results_allfolds(out,ax,filename,projectname,varargin)
% function protosc_figure_results_allfolds(out,ax,filename,projectname,varargin)
%
% SS 2020

for wf = 1:size(out,2)
    settings = protosc_Settings;
    if exist('varargin','var') || ~isempty(varargin)
        ins = varargin;
        settings = protosc_update_settings(settings,ins);
    end
    usecolormap     = protosc_figure_colormap;
    set(gcf,'Position',[100 100 1200 500],'color',settings.Figures.Color,'name',settings.Display.identifier)
    if ~exist('ax','var') || isempty(ax)
        ax = gcf;
    else
        figure(ax)
    end
    if ~exist('filename','var') || isempty(filename)
        filename    = [mfilename '_figure_' date num2str(now)];
        if wf>1
            filename = [filename num2str(wf)];
        end
        savenow     = 0;
    else
        savenow     = 1;
    end
    if ~exist('projectname','var') || isempty(projectname)
        if ~isempty(out(wf).settings.Saving.ProjectName)
            loci = [settings.Saving.savedir out(wf).settings.Saving.ProjectName];
        else
            loci = [settings.Saving.savedir];
        end
    else
        loci = [settings.Saving.savedir projectname];
        if ~isfolder(loci)
            mkdir(loci)
        end
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Subplot 1
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ydata_r = [];
    ydata_c = [];
    xdata = [];
    for ii = 1:size(out(wf).Results.FeatureRankCumSum,2)
        ydata_r(ii,:)   = protosc_im_scale(out(wf).Results.RankingScores{ii});
        ydata_c(ii,:)   = out(wf).Results.FeatureRankCumSum{ii};
        xdata(ii,:)     = 1:length(out(wf).Results.RankingScores{ii});
    end
    if isempty(out(wf).datainfo.FeatureReferenceMap)
        sp1 = subplot(2,4,1);protosc_figure_Plot(xdata,ydata_r,out(wf).settings,'xlabel','Feature Number','ylabel','Score','FigureName','A) Rank Scores')
    else
        ResultsMap = protosc_ana_FeatureMap(out(wf),'FullModel',0);sp1 = subplot(2,4,1);imagesc(protosc_im_scale(ResultsMap)),axis off, axis square,title('A) Rank Scores','FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    end
    % title, square, position,sp1.out(wf)erPosition = [.2/5 .5+.2/3  .2 .2];
    protosc_figure_colorbar
    set(gca,'linewidth',out(wf).settings.Figures.linewidth,'FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Subplot 2
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if strcmpi(out(wf).datainfo.dataType,'Fourier features ')
        sp2 = subplot(2,4,2);protosc_figure_FourierAxes;title('B) Feature Coordinates','FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    elseif strcmpi(out(wf).datainfo.dataType,'HOG features ')
        sp2 = subplot(2,4,2);protosc_figure_HOGAxes;title('B) Feature Coordinates','FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    elseif strcmpi(out(wf).datainfo.dataType,'combined Fourier & HOG features ')
        sp2 = subplot(2,4,2);protosc_figure_CombinedAxes;title('B) Feature Coordinates','FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    end
    set(gca,'Colormap',colormap('gray'),'linewidth',out(wf).settings.Figures.linewidth,'FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Subplot 3
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    sp3 = subplot(2,4,3);protosc_figure_Plot(xdata,ydata_c,'xlabel','Features Included','ylabel','Fraction total','Title','C) Cum Rank Score Sum'), axis square
    set(gca,'linewidth',out(wf).settings.Figures.linewidth,'FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Subplot 4
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    CM = protosc_ana_CM(out(wf),'FullModel',1);
    if size(CM,1)>4
        CMT = 0;
    else
        CMT = 1;
    end
    sp4 = subplot(2,4,4);protosc_figure_CM(CM,'CMText',CMT),title('D) Conf. Mat.: Full','FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    set(gca,'linewidth',out(wf).settings.Figures.linewidth,'FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    colormap(usecolormap)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Subplot 5
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if strcmpi(out(wf).settings.Figures.FSPreport,'F1')
        intermperf      = [out(wf).Results.FullModel.F1' out(wf).Results.FinalModel.F1' zeros(size(out(wf).Results.FullModel.F1')) out(wf).Results.Filter.F1' out(wf).Results.Wrapper.F1' out(wf).Results.RandomModel.F1' out(wf).Results.PseudoRandomModel.F1'];
        ytext           = 'Average F1';
        chanceline      = 0;
    elseif strcmpi(out(wf).settings.Figures.FSPreport,'Accuracy')
        intermperf      = [out(wf).Results.FullModel.Accuracy' out(wf).Results.FinalModel.Accuracy' zeros(size(out(wf).Results.FullModel.Accuracy')) out(wf).Results.Filter.Accuracy' out(wf).Results.Wrapper.Accuracy' out(wf).Results.RandomModel.Accuracy' out(wf).Results.PseudoRandomModel.Accuracy'];
        ytext           = 'Average Accuracy';
        chanceline      = 1/out(wf).datainfo.nclasses;
    end
    sp5 = subplot(2,4,5); plot(0,0)
    hold off, subplot(2,4,5),protosc_figure_Bar(intermperf,'newfigure',0,'xticklabels',{'fu' 'fi' ' ' 'fl' 'w' 'r' 'pr'},'Title','G) Performance per Model','xlabel','model','ylabel',ytext,'chanceline',chanceline)
    sp5 = subplot(2,4,5); hold on, plot([3 3],[0 1],'k')
    set(gca,'linewidth',out(wf).settings.Figures.linewidth,'FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Subplot 6
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    sp6 = subplot(2,4,6); plot(0,0)
    pienames = {'Filt' 'Wrap' 'Rnd' 'pRnd'};
    cont = out(wf).Results.FinalModel.ModelContent==0;
    for ii = 1:length(cont)
        if cont(ii) == 1
            pienames{ii} = ' ';
        end
    end
    hold off, sp6 = subplot(2,4,6);
    pc      = 0;
    w       = out(wf).Results.FinalModel.ModelContent/sum(out(wf).Results.FinalModel.ModelContent);
    explode = [1 1 1 1];
    h       = pie(w(w~=0),explode(w~=0),pienames(w~=0));
    cmap    = protosc_figure_colormap;
    for ii = 1:2:8
        try
            pc = pc+1;
            h(ii).FaceColor = [.5 .5 .5];% cmap(round(w(pc)*255+1),:);
            h(ii).EdgeColor = [0 0 0];%cmap(round(w(pc)*255+1),:)/4;
            %     h(ii).FaceAlpha = (w(pc)*1/max(w));
            h(ii).EdgeAlpha = 1;%(w(pc)*1/max(w));
            if w(pc)>0
                h(ii).LineWidth= 1;%w(pc)*5;
            else
                h(ii).LineStyle = 'none';
            end
        end
    end
    for ii = 2:2:8
        try
            h(ii).FontName = settings.Figures.Font;
            h(ii).FontSize = settings.Figures.FontSize;
        end
    end
    title('F) Final Model Content','FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    set(gca,'linewidth',out(wf).settings.Figures.linewidth,'FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Subplot 7
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if isempty(out(wf).datainfo.FeatureReferenceMap)
        sp7 = subplot(2,4,7);protosc_figure_Plot(xdata,ydata_r,'xlabel','Feature Number','ylabel','Score','FigureName','E) Selected Features')
        %     sp1.out(wf)erPosition [x y w h]
    else
        ResultsMap = protosc_ana_FeatureMap(out(wf),'FinalModel',0);sp7 = subplot(2,4,7);imagesc(protosc_im_scale(ResultsMap)),axis off, axis square,title('E) Selected Features','FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    end
    colormap(usecolormap)
    protosc_figure_colorbar
    set(gca,'linewidth',out(wf).settings.Figures.linewidth,'FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Subplot 8
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    CM = protosc_ana_CM(out(wf),'FinalModel',1);
    sp8 = subplot(2,4,8);protosc_figure_CM(CM,'CMText',CMT),title('H) Conf. Mat.: Final','FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    set(gca,'linewidth',out(wf).settings.Figures.linewidth,'FontName',out(wf).settings.Figures.Font,'FontSize',out(wf).settings.Figures.FontSize)
    colormap(usecolormap)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Align
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    h               = .35;
    w               = .15;
    yoffset1        = .6;
    yoffset2        = .1;
    sp1.Position    = [0.050    yoffset1      w    h];
    sp2.Position    = [0.30     yoffset1      w    h];
    sp3.Position    = [.55      yoffset1      w    h];
    sp4.Position    = [0.8      yoffset1      w    h];
    sp7.Position    = [0.050    yoffset2      w    h];
    sp6.Position    = [0.30     yoffset2      w    h];
    sp5.Position    = [0.55     yoffset2      w    h];
    sp8.Position    = [0.8      yoffset2      w    h];
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Save
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if out(wf).settings.Saving.autosaveFIG || savenow==1
        saveas(ax,[loci filesep filename],settings.Saving.autosaveFIGX)
        disp(['Figure saved as: ' loci filesep filename])
    end
    
end











