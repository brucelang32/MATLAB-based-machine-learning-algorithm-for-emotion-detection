function protosc_show_results_allfolds(out,ax,filename,projectname)
% function protosc_show_results_allfolds(out,ax,filename,projectname)
%
% SS 2020

settings        = protosc_Settings;
usecolormap     = protosc_figure_colormap;
set(gcf,'Position',[100 100 1000 500],'color',settings.Figures.Color,'name',out.settings.Display.identifier)
if ~exist('ax','var') || isempty(ax)
    ax = gcf;
else
    figure(ax)
end
if ~exist('filename','var') || isempty(filename)
    filename    = [mfilename '_figure_' date num2str(now)];
    savenow     = 0;
else
    savenow     = 1;
end
if ~exist('projectname','var') || isempty(projectname)
    if ~isempty(out.settings.Saving.ProjectName)
        loci = [settings.Saving.savedir out.settings.Saving.ProjectName];
    else
        loci = [settings.Saving.savedir];
    end
else
    loci = [settings.Saving.savedir projectname];
    if ~isfolder(loci)
        mkdir(loci)
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Subplot 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for ii = 1:size(out.Results.FeatureRankCumSum,2)
    ydata_r(ii,:)   = protosc_im_scale(out.Results.RankingScores{ii});
    ydata_c(ii,:)   = out.Results.FeatureRankCumSum{ii};
    xdata(ii,:)     = 1:length(out.Results.RankingScores{ii});
end
if isempty(out.datainfo.FeatureReferenceMap)
    subplot(2,3,1),protosc_show_cleanPlot(xdata,ydata_r,out.settings,'xlabel','Feature Number','ylabel','Score','FigureName','A) Rank Score per Feature')
else
    ResultsMap = protosc_ana_FeatureMap(out,'FullModel',0);subplot(2,3,1),imagesc(protosc_im_scale(ResultsMap)),axis off, axis square,title('A) Rank Score per Feature')
end
set(gca,'linewidth',out.settings.Figures.linewidth,'FontName',out.settings.Figures.Font,'FontSize',out.settings.Figures.FontSize)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Subplot 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmpi(out.datainfo.dataType,'Fourier features ')
    subplot(2,3,2),protosc_show_FourierAxes;title('B) Feature Coordinates')
elseif strcmpi(out.datainfo.dataType,'HOG features ')
    subplot(2,3,2),protosc_show_HOGAxes;title('B) Feature Coordinates')
elseif strcmpi(out.datainfo.dataType,'combined Fourier & HOG features ')
    subplot(2,3,2),protosc_show_CombinedAxes;title('B) Feature Coordinates')
end
set(gca,'Colormap',colormap('gray'),'linewidth',out.settings.Figures.linewidth,'FontName',out.settings.Figures.Font,'FontSize',out.settings.Figures.FontSize)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Subplot 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,3,3),protosc_show_cleanPlot(xdata,ydata_c,'xlabel','Features Included','ylabel','Fraction total','FigureName','C) Cum Rank Score Sum'), axis square
set(gca,'linewidth',out.settings.Figures.linewidth,'FontName',out.settings.Figures.Font,'FontSize',out.settings.Figures.FontSize)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Subplot 4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmpi(out.settings.Figures.FSPreport,'F1')
    intermperf      = [out.Results.FullModel.F1' out.Results.FinalModel.F1' zeros(size(out.Results.FullModel.F1')) out.Results.Filter.F1' out.Results.Wrapper.F1' out.Results.RandomModel.F1' out.Results.PseudoRandomModel.F1'];
    ytext           = 'Average F1';
    chanceline      = 0;
elseif strcmpi(out.settings.Figures.FSPreport,'Accuracy')
    intermperf      = [out.Results.FullModel.Accuracy' out.Results.FinalModel.Accuracy' zeros(size(out.Results.FullModel.Accuracy')) out.Results.Filter.Accuracy' out.Results.Wrapper.Accuracy' out.Results.RandomModel.Accuracy' out.Results.PseudoRandomModel.Accuracy'];
    ytext           = 'Average Accuracy';
    chanceline      = 1/out.datainfo.nclasses;
end
subplot(2,3,4), plot(0,0)
hold off, subplot(2,3,4),protosc_show_cleanBar(intermperf,'newfigure',0,'xticklabels',{'fu' 'fi' ' ' 'fl' 'w' 'r' 'pr'},'FigureName','D) Performance per Model','xlabel','model','ylabel',ytext,'chanceline',chanceline)
subplot(2,3,4), hold on, plot([3 3],[0 1],'k')
set(gca,'linewidth',out.settings.Figures.linewidth,'FontName',out.settings.Figures.Font,'FontSize',out.settings.Figures.FontSize)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Subplot 5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,3,5), plot(0,0)
pienames = {'Filt' 'Wrap' 'Rnd' 'pRnd'};
cont = out.Results.FinalModel.ModelContent==0;
for ii = 1:length(cont)
    if cont(ii) == 1
        pienames{ii} = ' ';
    end
end
hold off, subplot(2,3,5),pie(out.Results.FinalModel.ModelContent,[1 1 1 1],pienames)
title('E) Final Model Content')
set(gca,'linewidth',out.settings.Figures.linewidth,'FontName',out.settings.Figures.Font,'FontSize',out.settings.Figures.FontSize)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Subplot 6
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isempty(out.datainfo.FeatureReferenceMap)
    subplot(2,3,6),protosc_show_cleanPlot(xdata,ydata_r,'xlabel','Feature Number','ylabel','Score','FigureName','F) Selected Features')
else
    ResultsMap = protosc_ana_FeatureMap(out,'FinalModel',0);subplot(2,3,6),imagesc(protosc_im_scale(ResultsMap)),axis off, axis square,title('F) Selected Features')
end
set(gca,'linewidth',out.settings.Figures.linewidth,'FontName',out.settings.Figures.Font,'FontSize',out.settings.Figures.FontSize)
colormap(usecolormap)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Save
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if out.settings.Saving.autosaveFIG || savenow==1
    saveas(ax,[loci filesep filename],settings.Saving.autosaveFIGX)
    disp(['Figure saved as: ' loci filesep filename])
end


