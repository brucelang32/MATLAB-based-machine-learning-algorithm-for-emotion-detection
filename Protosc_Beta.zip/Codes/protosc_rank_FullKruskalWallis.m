function [ranked_ind,rankscores_originalorder] = protosc_rank_FullKruskalWallis(AllData,ranking_its,crit_samp_perc)
% function [ranked_ind,rankscores_originalorder] = protosc_rank_FullKruskalWallis(AllData,prior_its,crit_samp_perc)
%
% SS 2019


AllLabels = unique(AllData(:,1));
if ~exist('crit_samp_perc','var')
    settings = protosc_Settings;
    crit_samp_perc = settings.Main.samplingPercentage;
end
if ~exist('prior_its','var')
    settings = protosc_Settings;
    ranking_its = settings.Ranking.iterations;
end
if crit_samp_perc<1
    crit_samp_perc = crit_samp_perc*100;
end
ranked_ind  = [];
FF          = nan(ranking_its,size(AllData,2)-1);
use_ind     = protosc_get_BalencedSample(AllData,100);
usedata     = AllData(use_ind,:);
try
    parfor i = 2:size(usedata,2)
        M = [];
        for l = AllLabels'
            M = [M usedata(usedata(:,1)==l,i)];
        end
        [~, table] =  kruskalwallis(M,[],'off');
        FF(1,i-1) = table{2,5};
    end
catch
    for i = 2:size(usedata,2)
        M = [];
        for l = AllLabels'
            M = [M usedata(usedata(:,1)==l,i)];
        end
        [~, table] =  kruskalwallis(M,[],'off');
        FF(1,i-1) = table{2,5};
    end
end




FF(isnan(FF))               = 0;
rankscores_originalorder    = FF;
if isempty(ranked_ind)
    if size(rankscores_originalorder,1) > 1
        [~,ranked_ind] = sort(nansum(rankscores_originalorder),'descend');
        rankscores_originalorder = nanmean(rankscores_originalorder);
    else
        [~,ranked_ind] = sort(rankscores_originalorder,'descend');
    end
end
rankscores_originalorder(isnan(rankscores_originalorder))=0;




% % 
% % 
% % alllabels = unique(AllData(:,1));
% % if ~exist('crit_samp_perc','var')
% %     settings = protosc_Settings;
% %     crit_samp_perc = settings.Main.samplingPercentage;
% % end
% % if ~exist('prior_its','var')
% %     settings = protosc_Settings;
% %     ranking_its = settings.Ranking.iterations;
% % end
% % if crit_samp_perc<1
% %     crit_samp_perc = crit_samp_perc*100;
% % end
% % 
% % for kk = 1:ranking_its
% %     
% %     datasplit = [];
% %     ind = protosc_get_BalencedSample(AllData,crit_samp_perc);
% %     
% %     for ii = 1:length(alllabels)
% %         datasplit(:,:,ii) = AllData(AllData(ind,1)==alllabels(ii),2:end);
% %     end
% %     
% %     for ii = 1:length(alllabels)
% %         m(ii,:) = median(datasplit(:,:,ii));
% %         l(ii,:) = prctile(datasplit(:,:,ii),5);
% %         h(ii,:) = prctile(datasplit(:,:,ii),95);
% %     end
% %     
% %     c = 0;
% %     for ii = 1:length(alllabels)
% %         for jj = ii+1:length(alllabels)
% %             c = c+1;
% %             mc(c,:) = abs(1-(m(ii,:)./m(jj,:)));
% %             lc(c,:) = abs(1-(l(ii,:)./l(jj,:)));
% %             hc(c,:) = abs(1-(h(ii,:)./h(jj,:)));
% %         end
% %     end
% %     mc(isnan(mc)) = 0;
% %     lc(isnan(lc)) = 0;
% %     hc(isnan(hc)) = 0;
% %     if size(mc,1) == 1
% %             [~,~,mc(1,:)]= protosc_sortscore(mc(1,:));
% %             [~,~,hc(1,:)]= protosc_sortscore(hc(1,:));
% %             [~,~,lc(1,:)]= protosc_sortscore(lc(1,:));
% %         t(kk,:) = protosc_im_scale(mc.^2)+protosc_im_scale(hc.^2)+protosc_im_scale(lc.^2);
% %     else
% %         for ll = 1:size(mc,1)
% %             [~,~,mc(ll,:)]= protosc_sortscore(mc(ll,:));
% %             [~,~,hc(ll,:)]= protosc_sortscore(hc(ll,:));
% %             [~,~,lc(ll,:)]= protosc_sortscore(lc(ll,:));
% %         end
% %         t(kk,:) = protosc_im_scale(mean(mc.^2))+protosc_im_scale(mean(hc.^2))+protosc_im_scale(mean(lc.^2));
% %     end
% % end
% % if ranking_its>1
% %     rankscores_originalorder = mean(t);
% % else
% %     rankscores_originalorder = t;
% % end
% % [~,ranked_ind] = sort(rankscores_originalorder,'descend');
% % 
% % 




