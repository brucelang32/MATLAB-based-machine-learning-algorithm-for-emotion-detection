function [sps,keepgoing] = protosc_check_SearchSpace(PosibleParams,out)
% function [sps,keepgoing] = protosc_check_SearchSpace(PosibleParams,out)
% 
% SS 2019

sps = out.Results.SearchSpaceSizes(end);
if ~isempty(PosibleParams)
    keepgoing = 1;
    if length(PosibleParams) < sps
        sps = length(PosibleParams);
    end
    if sps == 0
        keepgoing = 0;
        if out.settings.Display.showintremfeedback
            disp(['[In ' mfilename '] No more features to test.'])
        end
    end
else
    keepgoing   = 0;
    sps         = 0;
    warning(['[In ' mfilename '] No inputs to ' mfilename])
end