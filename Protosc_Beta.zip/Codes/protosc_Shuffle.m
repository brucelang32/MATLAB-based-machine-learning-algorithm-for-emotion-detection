function out = protosc_Shuffle(in,n)
% function out = protosc_Shuffle(in)
% 
% SS 2019

rng('shuffle')
if length(size(in))>1 || (sum(size(in)==1)>0 && length(size(in))==2)
    shape = size(in);
    inmod = in(:);
    numbers = rand(1,length(inmod));
    [~,I] = sort(numbers);
    out = inmod(I);
    out = reshape(out,shape);
    if exist('n','var') && ~isempty(n)
        out = out(1:n);
    end
else
    numbers = rand(1,length(in));
    [~,I] = sort(numbers);
    out = in(I);
    if exist('n','var') && ~isempty(n)
        out = out(1:n);
    end
end


