function [MaxFeatures,Progression] = protosc_get_MaxFeatures(RankScores,criterium,AllData)
% function [MaxFeatures,Progression] = protosc_get_MaxFeatures(RankScores,criterium)
%
% SS 2019

if ~exist('criterium','var') || isempty(criterium)
    settings = protosc_Settings;
    criterium = settings.Main.MaxFeaturesCrit;
end
if size(RankScores,1) > 1
    [RS,inds] = sort(nansum(RankScores),'descend');
else
    [RS,inds] = sort(RankScores,'descend');
end
if ischar(criterium)
    if ~exist('AllData','var') || isempty(AllData)
        error('Need AllData')
    end
    use_ind     = protosc_get_BalencedSample(AllData,100);
    TrainSet    = AllData(use_ind==1,:);
    TestSet     = AllData(use_ind==0,:);
    steps       = 10;
    perstep     = length(inds)/steps;
    i           = 0;
    drops       = 0;
    maxdrops    = 2;
    while drops < maxdrops
        i = i + 1;
        preds       = inds(1:(length(inds)/steps)*i);
        cvm         = protosc_classy_linSVM(TrainSet(:,[1 preds+1]));
        p(i)        = mean(cvm.predictFcn(TestSet(:,preds+1))==TestSet(:,1));
        if i>1
            if p(i)<p(i-1)
                drops = drops+1;
            else
                drops = 0;
            end
        end
        if i == steps
            drops = 999;
        end
    end
    MaxFeatures = find(p==max(p),1,'first')*perstep;
    Progression = p;
else
    crs    = nan(1,length(RS));
    crs(1) = RS(1);
    for ii = 1:length(RS)
        crs(ii) = nansum(RS(1:ii));
    end
    Progression = protosc_im_scale(crs);
    MaxFeatures = find(Progression>=criterium,1,'first');
end

