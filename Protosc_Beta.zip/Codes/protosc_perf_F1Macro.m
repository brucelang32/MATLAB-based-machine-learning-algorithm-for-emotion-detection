function [F1Macro,F1Macro_t] = protosc_perf_F1Macro(y,yhat)
% function [F1Macro,Precision,Recall] = protosc_perf_F1Macro(y,yhat)
% 
% SS 2019

CM                  = confusionmat(y,yhat);
CM                  = CM./repmat(sum(CM,2),1,size(CM,2));
nLabels             = size(CM,1);
TruePos             = zeros(nLabels,1);
FalsePos            = zeros(nLabels,1);
FalseNeg            = zeros(nLabels,1);
Precision_t         = zeros(nLabels,1);
Recall_t            = zeros(nLabels,1);
F1Macro_t           = zeros(nLabels,1);
for ii = 1:nLabels
    TruePos(ii)     = CM(ii,ii);
    FalsePos(ii)    = nansum(CM(:, ii))-CM(ii,ii);
    FalseNeg(ii)    = nansum(CM(ii,:))-CM(ii,ii);
    Precision_t(ii) = TruePos(ii)/(TruePos(ii)+FalsePos(ii));
    Recall_t(ii)    = TruePos(ii)/(TruePos(ii)+FalseNeg(ii));
    F1Macro_t(ii)   = 2*(Precision_t(ii)*Recall_t(ii)/(Precision_t(ii)+Recall_t(ii)));
end

Precision           = nanmean(Precision_t);
Recall              = nanmean(Recall_t);
F1Macro             = nanmean(F1Macro_t);









