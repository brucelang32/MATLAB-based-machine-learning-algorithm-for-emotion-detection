function t = protosc_Setting_Table(settings)

% adjust Settings
lvl1 = fields(settings);
lvl2 = {};
wlvl1 = [];
for ii = 1:size(lvl1,1)
    temp = fields(settings.(lvl1{ii}));
    inds = size(lvl2,2)+1:size(lvl2,2)+size(temp,1);
    c = 0;
    for iii = inds
        c = c+1;
        wlvl1{size(wlvl1,2)+1} = lvl1{ii};
        lvl2{iii} = temp{c};
    end
end
c = 0;
for ii = 1:size(lvl1,1)
    temp = fields(settings.(lvl1{ii}));
    for iii = 1:size(temp,1)
        c = c+1;
        if iii == 1
            SettingsTable{c,1} = lvl1{ii};
        else
            SettingsTable{c,1} = '  ';
        end
        SettingsTable{c,2} = temp{iii};
        if isempty(settings.(lvl1{ii}).(temp{iii}))
            SettingsTable{c,3} = '  ';
        else
            SettingsTable{c,3} = settings.(lvl1{ii}).(temp{iii});
        end
    end
end
t = table(SettingsTable(:,1),SettingsTable(:,2),SettingsTable(:,3),'VariableNames',{'Type' 'Name' 'Setting'});
