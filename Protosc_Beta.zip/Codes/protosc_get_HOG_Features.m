function [AllHogFeatures,settings,FileList] = protosc_get_HOG_Features(Stims,settings)
% function [AllHogFeatures,settings,FileList] = protosc_get_HOG_Features(Stims,settings)
%
% SS 2019


if ~exist('settings','var') || isempty(settings)
    settings = protosc_Settings;
    disp(['[In ' mfilename '] Default Cell Size: ' num2str(settings.Features.HOG_cellsize)])
    disp(['[In ' mfilename '] Default n Orientations: ' num2str(settings.Features.HOG_nBins)])
end
Stims       = protosc_check_Stims(Stims);
in          = whos('Stims');
[~,vis]     = extractHOGFeatures(Stims{1}(1).im,'CellSize',settings.Features.HOG_cellsize,'BlockSize',[1 1],'NumBins',settings.Features.HOG_nBins);

FileList_count = 0;
if strcmpi(in.class,'cell')
    settings.Features.HOG_ImSize        = size(Stims{1}(1).im);
    for l = 1:length(Stims)
        disp(['[In ' mfilename '] Extracting Features label ' num2str(l) ' out of ' num2str(length(Stims))])
        for ii = 1:length(Stims{l})
            FileList_count = FileList_count+1;
            try
                FileList{FileList_count,1} = Stims{l}(ii).fullname;
            catch
                FileList{FileList_count,1} = 'Unknow file origin';
            end
            try
                if l==1 && ii == 1
                    [hog1,vis]                  = extractHOGFeatures(Stims{l}(ii).im,'CellSize',settings.Features.HOG_cellsize,'BlockSize',[1 1],'NumBins',settings.Features.HOG_nBins);
                    AllHogFeatures{l}(ii,:)     = hog1;
                else
                    [AllHogFeatures{l}(ii,:),vis]     = extractHOGFeatures(Stims{l}(ii).im,'CellSize',settings.Features.HOG_cellsize,'BlockSize',[1 1],'NumBins',settings.Features.HOG_nBins);
                end
            catch
                disp('Problems with extractHOGFeatures.m, possibly toolbox missing')
                AllHogFeatures = [];
            end
        end
    end
elseif strcmpi(in.class,'struct')
    settings.Features.HOG_ImSize        = size(Stims{1}(1).im);
    l = 1;
    disp(['[In ' mfilename '] Extracting Features label ' num2str(l) ' out of ' num2str(l)])
    for ii = 1:size(Stims,2)
        FileList_count = FileList_count+1;
        try
            FileList{FileList_count,1} = Stims{l}(ii).fullname;
        catch
            FileList{FileList_count,1} = 'Unknown file origin';
        end
        try
            if l==1 && ii == 1
                [hog1,vis]                  = extractHOGFeatures(Stims(ii).im,'CellSize',settings.Features.HOG_cellsize,'BlockSize',[1 1],'NumBins',settings.Features.HOG_nBins);
                AllHogFeatures{l}(ii,:)     = hog1;
            else
                [AllHogFeatures{l}(ii,:),vis]    = extractHOGFeatures(Stims(ii).im,'CellSize',settings.Features.HOG_cellsize,'BlockSize',[1 1],'NumBins',settings.Features.HOG_nBins);
            end
        catch
            disp('Problems with extractHOGFeatures.m, possibly toolbox missing')
            AllHogFeatures = [];
        end
    end
else
    t = Stims;
    clear Stims
    Stims{1}(1).im                      = t;
    settings.Features.HOG_ImSize        = size(Stims{1}(1).im);
    l = 1;
    ii = 1;
    FileList_count = FileList_count+1;
    try
        FileList{FileList_count} = Stims{l}(ii).fullname;
    catch
        FileList{FileList_count} = 'Unknow file origin';
    end
    try
        [AllHogFeatures{l}(ii,:),vis]     = extractHOGFeatures(Stims{1}(1).im,'CellSize',settings.Features.HOG_cellsize,'BlockSize',[1 1],'NumBins',settings.Features.HOG_nBins);
    catch
        disp('Problems with extractHOGFeatures.m, possibly toolbox missing')
        AllHogFeatures = [];
    end
end
settings.Features.HOG_ReferenceMap  = protosc_get_HOG_refmap(Stims{1}(1).im,settings);
settings.Features.HOG_BinCenters    = vis.BinCenters;

if settings.Features.HOG_Rel==1
    for ii = 1:size(AllHogFeatures,2)
%         for jj = 1:size(AllHogFeatures{ii},1)
%             for kk = 1:size(AllHogFeatures{ii},2)/settings.Features.HOG_nBins
%                 AllHogFeatures{ii}((1:settings.Features.HOG_nBins)+(kk-1)*settings.Features.HOG_nBins) = ...
%                     AllHogFeatures{ii}((1:settings.Features.HOG_nBins)+(kk-1)*settings.Features.HOG_nBins)/...
%                     median(AllHogFeatures{ii}((1:settings.Features.HOG_nBins)+(kk-1)*settings.Features.HOG_nBins));
%             end
%         end
        AllHogFeatures{ii} = AllHogFeatures{ii}/nanmedian(AllHogFeatures{ii}(:));
    end
end



