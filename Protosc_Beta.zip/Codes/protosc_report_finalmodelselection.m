function report = protosc_report_finalmodelselection(out)
% function report = protosc_report_finalmodelselection(out)
% 
% SS 2020

methodcontent   = out.Results.FinalModel.ModelContent/(sum(out.Results.FinalModel.ModelContent))*100;
models{1}       = 'filter models';
models{2}       = 'wrapper models';
models{3}       = 'random models';
models{4}       = 'pseudo random models';
bol             = methodcontent~=0;
fbol            = find(bol);
wmodels         = '';

if find(methodcontent == max(methodcontent),1,'first')==1 && methodcontent(1)>methodcontent(2)
    expl = 'This results reveals that univariate feature selection tended to result in the best cross-validated performance.';
elseif find(methodcontent == max(methodcontent),1,'first')==2 && methodcontent(2)>methodcontent(1)
    expl = 'This results reveals that multivariate feature selection tended to result in the best cross-validated performance.';
elseif find(methodcontent == max(methodcontent),1,'first')==1 && methodcontent(1)==methodcontent(2)
    expl = 'This results reveals that univariate and multivariate feature selection performed equally well when selecting features for cross-validation.';
end

if (methodcontent(1)+methodcontent(2))<=(methodcontent(3)+methodcontent(4))
    expl = 'This results reveals that univariate and multivariate feature selection did not outperform random or pseudorandom feature selection during cross-validation. ';
    if find(methodcontent == max(methodcontent),1,'first')==4
        expl = [expl 'In fact, pseudorandom selection worked best, suggesting the initial univariate ranking was misleading for subsequent feature selection.' ];
    elseif find(methodcontent == max(methodcontent),1,'first')==3
        expl = [expl 'Since the random model was most often selected, this suggests many of the features are relevant for decoding and that not all the most relevant features were identified by the univariate intial ranking.' ];
    end
end

if sum(bol) == 1
    wmodels = [num2str(methodcontent(bol)) '% ' models{bol}];
elseif sum(bol)==2
    wmodels = [num2str(methodcontent(fbol(1))) '% ' models{fbol(1)} ' and ' num2str(methodcontent(fbol(2))) '% ' models{fbol(2)}];
elseif sum(bol)==3
    wmodels = [num2str(methodcontent(fbol(1))) '% ' models{fbol(1)} ', '  num2str(methodcontent(fbol(2))) '% ' models{fbol(2)} ' and ' num2str(methodcontent(fbol(3))) '% ' models{fbol(3)}];
elseif sum(bol)==4
    wmodels = [num2str(methodcontent(fbol(1))) '% ' models{fbol(1)} ', ' num2str(methodcontent(fbol(2))) '% ' models{fbol(2)} ', ' num2str(methodcontent(fbol(3))) '% ' models{fbol(3)} ' and ' num2str(methodcontent(fbol(4))) '% ' models{fbol(4)}];
end

report       = ['The Final Model used ' wmodels '. ' expl];


