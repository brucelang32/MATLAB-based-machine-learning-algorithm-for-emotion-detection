function [ranked_ind,rankscore] = protosc_rank_bivar(AllData,tryme,out)
% function [ranked_ind,rankscore] = protosc_rank_bivar(AllData,tryme,out)
% 
% SS 2020

% tryme = out.Results.FeatureRanks{end}(1:out.Results.SearchSpaceSizes(end))

c = 0;
x = nan(length(unique(AllData(:,1))),size(AllData,2)-1);
y = nan(length(unique(AllData(:,1))),size(AllData,2)-1);
for ii = unique(AllData(:,1))'
    c = c+1;
    x(c,:) = median(AllData(AllData(:,1)==ii,2:end));
    y(c,:) = std(AllData(AllData(:,1)==ii,2:end));
end
adm     = nan(sum(c-1:-1:0),size(AllData,2)-1);
assd    = nan(sum(c-1:-1:0),size(AllData,2)-1);
c = 0;
for ii = 1:length(unique(AllData(:,1))')
    for jj = ii+1:length(unique(AllData(:,1))')
        c = c+1;
        adm(c,:)     = x(ii,:)-x(jj,:);
        assd(c,:)    = y(ii,:)+y(jj,:);
    end
end

if size(adm,1)>1
    xy2             = sum(abs(adm./assd));
else
    xy2             = abs(adm./assd);
end
xy3             = zeros(size(xy2,2),size(xy2,2));
v = ones(1,size(xy2,2));
v(tryme) = 0;
v = find(v);
for ii = tryme
    try
        parfor jj = v
            xy3(ii,jj) = sum(xy2(:,ii).*xy2(:,jj));
        end
    catch
        for jj = v
            xy3(ii,jj) = sum(xy2(:,ii).*xy2(:,jj));
        end
    end
end

rankscore = protosc_im_scale(max(xy3));
rankscore(isnan(rankscore)) = 0;
[~,ranked_ind,~]        = protosc_get_sortscore(rankscore,'down');


