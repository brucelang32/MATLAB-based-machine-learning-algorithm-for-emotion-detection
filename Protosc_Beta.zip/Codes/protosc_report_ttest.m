function out = protosc_report_ttest(X,Y,names,TAIL,crit,metric)
% function out = protosc_report_ttest(X,Y,names,TAIL,crit)
%
% SS 2019

if isempty(X)
    out = '';
else
    if ~exist('metric','var') || isempty(metric)
        metric = ' ';
    else
        if ~strcmpi(metric(1),' ')
            metric = [' ' metric];
        end
        if ~strcmpi(metric(end),' ')
            metric = [metric ' '];
        end
    end
    if ~exist('crit','var') || isempty(crit)
        crit = 0.05;
    end
    if ~exist('names','var') || isempty(names)
        names = {'X' 'Y'};
    end
    if ~exist('TAIL','var') || isempty(TAIL)
        TAIL = 'both';
    end
    if ~exist('Y','var') || isempty(Y)
        Y = 0';
    end
    [~,P,~,STATS] = ttest(X,Y,'tail',TAIL);
    if length(Y)==1
        testname = 'one-sample t-test';
    else
        testname = 'paired-sample t-test';
    end
    if strcmpi(TAIL,'right')
        testname = ['right-sided ' testname];
    elseif strcmpi(TAIL,'left')
        testname = ['left-sided ' testname];
    elseif strcmpi(TAIL,'both')
        testname = ['two-sided ' testname];
    end
    sim = 'against ';
    if P>=crit
        %     sim = ' = ';
        sim2 = ' = ';
        direction = 'does not differ from ';
    else
        sim2 = ' < ';
        if STATS.tstat < 0
            direction = 'is significantly lower than ';
        else
            direction = 'is significantly higher than ';
        end
    end
    
    if P < crit
        reportp = 0.001;
    elseif P < 0.01
        reportp = 0.01;
    elseif P < 0.05
        reportp = 0.05;
    else
        reportp = P;
    end
    
    statement = ['Results show that ' names{1} metric direction names{2} ' ('];
    if length(Y) == 1
        out = [statement names{1} ' (M = ' num2str(mean(X)) ', SEM = ' num2str(std(X)/sqrt(length(X))) ') ' sim names{2} ', ' testname ', t(' num2str(STATS.df) ') = ' num2str(STATS.tstat) ', p' sim2 num2str(reportp) ').'];
    else
        out = [statement names{1} ' (M = ' num2str(mean(X)) ', SEM = ' num2str(std(X)/sqrt(length(X))) ') ' sim names{2} ' (M = ' num2str(mean(Y)) ', SEM = ' num2str(std(Y)/sqrt(length(Y))) '), '  testname ', t(' num2str(STATS.df) ') = ' num2str(STATS.tstat) ', p' sim2 num2str(reportp) ').'];
    end
end





