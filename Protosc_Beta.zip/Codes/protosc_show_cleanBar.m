function protosc_show_cleanBar(data,varargin)
% function protosc_show_cleanBar(data,'propertyname',property input) or show_cleanBar(data,'Param',[Param input])
%
% Possible Params:
% FaceColor,EdgeColor,MarkerEdgeColor,MarkerFaceColor,LineColor,FontSize,Font,linewidth,FigureName,Xlabel,Ylabel,Marker,YMAX
%
% SS 2019


settings = protosc_Settings;
if exist('varargin','var') || ~isempty(varargin)
    ins = varargin;
    settings = protosc_update_settings(settings,ins);
end
set(gcf,'color',settings.Figures.Color)
FaceColor       = settings.Figures.FaceColor;
EdgeColor       = settings.Figures.EdgeColor;
MarkerEdgeColor = settings.Figures.MarkerEdgeColor;
MarkerFaceColor = settings.Figures.MarkerFaceColor;
LineColor       = settings.Figures.LineColor;
FontSize        = settings.Figures.FontSize;
Font            = settings.Figures.Font;
linewidth       = settings.Figures.linewidth;
FigureName      = settings.Figures.FigureName;
Xlabel          = settings.Figures.Xlabel;
Ylabel          = settings.Figures.Ylabel;
Marker          = settings.Figures.Marker;
saveme          = settings.Saving.autosaveFIG;
filename        = [settings.Saving.savedir filesep mfilename '_figure_' date num2str(now)];
chanceline      = settings.Figures.chanceline;
newfigure       = settings.Figures.newfigure;
showboxinput    = settings.Figures.showbox;
xticklabels     = settings.Figures.xticklabels;
YMAX            = settings.Figures.YMAX;
YMIN            = settings.Figures.YMIN;

if isempty(YMAX)
    YMAX        = max(nanmean(data)+nanstd(data)/sqrt(size(data,1)))+(max(nanmean(data)+nanstd(data)/sqrt(size(data,1)))*.1);
end
if isempty(YMIN)
    YMIN        = min(nanmean(data)-nanstd(data)/sqrt(size(data,1)))+(min(nanmean(data)-nanstd(data)/sqrt(size(data,1)))*.1);
end
if YMIN>0
    YMIN = 0;
end
if size(data,1) == 1
    calc = -1;
else
    calc = 1;
end
if size(data,2)>size(xticklabels,2)
    xticklabels_t = xticklabels;
    for ii = size(xticklabels,2)+1:size(data,2)
        xticklabels_t{ii}     = ' ' ;
    end
    xticklabels = xticklabels_t;
end
if newfigure==1
    figure('color',[1 1 1]);
end
if calc == 1
    bar(nanmean(data),'FaceColor',FaceColor,'EdgeColor',EdgeColor,'linewidth',linewidth); hold on
    errorbar(1:size(data,2),nanmean(data),nanstd(data)/sqrt(size(data,1)),'Marker',Marker,'LineStyle','none','MarkerFaceColor',MarkerFaceColor,...
        'MarkerEdgeColor',MarkerEdgeColor,'Color', LineColor,'LineWidth',linewidth)
    title(settings.Figures.Title,'FontName',Font,'FontSize',FontSize)
    xlabel(Xlabel,'FontName',Font,'FontSize',FontSize)
    ylabel(Ylabel,'FontName',Font,'FontSize',FontSize)
elseif calc == 0
    bar(data(1,:),'FaceColor',FaceColor,'EdgeColor',EdgeColor,'linewidth',linewidth); hold on
    errorbar(1:size(data,2),data(1,:),data(2,:),'Marker',Marker,'LineStyle','none','MarkerFaceColor',MarkerFaceColor,...
        'MarkerEdgeColor',MarkerEdgeColor,'Color', LineColor,'LineWidth',linewidth)
    title(settings.Figures.Title,'FontName',Font,'FontSize',FontSize)
    xlabel(Xlabel,'FontName',Font,'FontSize',FontSize)
    ylabel(Ylabel,'FontName',Font,'FontSize',FontSize)
elseif calc == -1
    bar(data(1,:),'FaceColor',FaceColor,'EdgeColor',EdgeColor,'linewidth',linewidth); hold on
    title(settings.Figures.Title,'FontName',Font,'FontSize',FontSize)
    xlabel(Xlabel,'FontName',Font,'FontSize',FontSize)
    ylabel(Ylabel,'FontName',Font,'FontSize',FontSize)
    
end
if chanceline
    lineY = chanceline;
    if length(lineY)==1
        lineY = [lineY lineY];
    end
    hold on
    plot([0 size(data,2)+1],lineY,'--k')
end
set(gca,'linewidth',linewidth,'Xtick',1:size(data,2),'Xticklabels',xticklabels,'FontName',Font,'FontSize',FontSize)
axis([0 size(data,2)+1 YMIN YMAX]),box(showboxinput)
axis square


