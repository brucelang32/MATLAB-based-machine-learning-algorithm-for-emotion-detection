function varargout = protosc_figure_Stims(varargin)


rows        = length(varargin);
posclmns    = [];
exampleim   = [];
AVs         = {};
skip        = zeros(1,length(varargin));
for ii = 1:length(varargin)
    posclmns(ii) = size(varargin{ii},2);
    t = varargin{ii};
    w = whos('t');
    if ~strcmpi(w.class,'cell')
        if strcmpi(w.class,'double') && length(t) == 1
            exampleim = t;
            skip(ii) = 1;
        else
            error(['Data type input' num2str(ii) ' is not supported'])
        end
    end
end
settings    = protosc_Settings;
figure('color',[1 1 1])
if rows>max(posclmns)
    set(gcf,'Position',[100 100 500 1000])
elseif rows<max(posclmns)
    set(gcf,'Position',[100 100 1200 500])
else
    set(gcf,'Position',[100 100 750 500])
end
for ii = 1:length(varargin)
    if skip(ii)==0
        for jj = 1:size(varargin{ii},2)
            dataType = [];
            FeatureReferenceMap = [];
            ResultsMap = [];
            if isfield(varargin{ii}{jj},'im')
                if isempty(exampleim)
                    exampleim = ceil(rand*size(varargin{ii}{jj},2));
                end
                AVs{ii,jj} = varargin{ii}{jj}(exampleim).im;
                subplot(rows,max(posclmns),mod(jj-1,max(posclmns))+1+(max(posclmns)*(ii-1))),
                imshow(AVs{ii,jj}),axis square,title(['Example Image, Category ' num2str(jj)],'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
            else
                nfeatures                               = size(varargin{ii}{jj},2);
                [FeatureReferenceMap,dataType,settings] = protosc_get_datatype(nfeatures,settings);
                ResultsMap                              = zeros(size(FeatureReferenceMap));
                Features                                = mean(varargin{ii}{jj});
                if strcmpi(dataType,'Fourier features ')
                    for kk = 1:nfeatures
                        ResultsMap(FeatureReferenceMap==kk) = Features(kk);
                    end
                    AVs{ii,jj}                  = log(rot90(ResultsMap));
                    subplot(rows,max(posclmns),mod(jj-1,max(posclmns))+1+(max(posclmns)*(ii-1))),
                    imagesc(AVs{ii,jj}),axis off, box off,
                    axis square,title(['Average Fourier, Category ' num2str(jj)],'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize),colormap('gray')
                elseif strcmpi(dataType,'HOG features ')
                    AVs{ii,jj} = protosc_show_HOGfeatures(Features,settings,1);
                    subplot(rows,max(posclmns),mod(jj-1,max(posclmns))+1+(max(posclmns)*(ii-1))),
                    imagesc(AVs{ii,jj}),axis off, box off,
                    axis square,title(['Average HOG, Category ' num2str(jj)],'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize),colormap('gray')
                end
                
            end
        end
    end
end
if exist('varargout','var') 
    varargout{1} = AVs;
end



