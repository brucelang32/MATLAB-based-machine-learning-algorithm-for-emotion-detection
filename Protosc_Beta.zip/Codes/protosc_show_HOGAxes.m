function h = protosc_show_HOGAxes
% function h = protosc_show_HOGAxes
% 
% SS 2020

HA          = round(mean(imread([protosc_get_root filesep 'Codes' filesep 'protosc_im_HOGAxes2.bmp'])/255,3));
loci        = protosc_im_CenterRect([1 1 220 220],[1 1 size(HA)]);
HOGAxes     = HA(loci(1):loci(3)-3,loci(2):loci(4),1);
h           = protosc_im_scale(imresize(HOGAxes(:,:,1),[100 100],'bicubic'));
h(h>.5)     = 1;
imagesc(h),colormap('gray'),box off, axis square, axis off;
