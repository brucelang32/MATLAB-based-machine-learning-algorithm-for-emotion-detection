function settings = protosc_Settings(varargin)
% function settings = protosc_Settings() or 
% 
% settings = protosc_Settings('Setting Name',Input)
% 
% SS 2019

if length(varargin)/2~=round(length(varargin)/2)
    error('Number of inputs needs to be an even number, 1 setting for every property')
end

% Main Settings
settings.Main.nfolds                    = 8;    % k-cross validation
settings.Main.samplingPercentage        = 70;   % percentage of data used for training per interation
settings.Main.foldingindices            = [];
settings.Main.MaxFeaturesCrit           = .25;
settings.Main.Classifier                = 'protosc_classy_linSVM';
% Available Classifiers:
% 
% protosc_classy_BaggyTree      - Bagged Decision Tree
% protosc_classy_BoostedTree    - Boosted Decision Tree
% protosc_classy_kNN_10         - k Nearest Neighbors, k set at 10
% protosc_classy_linDis         - Linear Discriminant Analysis
% protosc_classy_linSVM         - Linear Support Vector Machine
% protosc_classy_poly2SVM       - 2nd polynominal Support Vector Machine
% protosc_classy_quadSVM        - Quadratic Support Vector Machine
% protosc_classy_Tree20         - Simple Decision Tree, 20 nodes

% Feature Settings
settings.Features.force_exclude_crit    = .95; %based on progression
settings.Features.force_exclude         = [];
settings.Features.FeatureReferenceMap   = [];
settings.Features.HOG_cellsize          = [10 10];
settings.Features.HOG_nBins             = 9;
settings.Features.HOG_ImSize            = [];
settings.Features.HOG_ReferenceMap      = [];
settings.Features.HOG_Rel               = 0; %absolute(0) or relative(1) HOG
settings.Features.Fourier_nOri          = 16;
settings.Features.Fourier_nSF           = 24;
settings.Features.Fourier_SFsteps       = 'lin';%'invlog';
settings.Features.Fourier_Rel           = 0; %absolute(0) or relative(1) Fourier
settings.Features.Fourier_ImSize        = [];
settings.Features.Fourier_ReferenceMap  = [];

% Univariate Ranking Settings
settings.Ranking.iterations             = 1; % iterations when bootstrapping, does not apply to all
settings.Ranking.func                   = 'protosc_rank_FullKruskalWallis';

% Wrapper Settings
settings.Wrapper.Method                 = 'Wrapper_MLP';
settings.Wrapper.CritFunction           = 'protosc_perf_AccuracyF1'; 
% Available Crition Functions:
% 
% protosc_perf_Accuracy      - Mean fraction correct
% protosc_perf_AccuracyF1    - Mean fraction correct and F1Macro
% protosc_perf_F1Macro       - Mean F1 score
% protosc_perf_F1Min         - Min F1 score
% protosc_perf_Precision     - Mean Precision
% protosc_perf_Recall        - Mean Recall

settings.Wrapper.Classifier             = 'protosc_classy_linSVM';
settings.Wrapper.FinalModelSelection    = 'Accuracy';
settings.Wrapper.startmodelsize         = .25;
settings.Wrapper.chunksearch            = 1;
% settings.Wrapper.chunks                 = [10 7];
settings.Wrapper.SearchSpaceSize        = [];   % number of parameters tried per iteration
settings.Wrapper.SearchSpaceSizeScalar  = 2;    % x times the maxmodelparams
settings.Wrapper.maxincperit            = [];
settings.Wrapper.maxincperitf           = 1/4;
settings.Wrapper.consistency_its        = 4;    % n times you check each param in searchspace (increases consistency may also increase overfitting)
settings.Wrapper.failtolerance          = 5;    % n times add features is allowed to fail before it quits
settings.Wrapper.ReEval01               = 1;    % re evaluate model
settings.Wrapper.ReEvalf                = .5;

% Display options
settings.Display.identifier             = '~';
settings.Display.showintremfeedback     = 1;
settings.Display.showfinalfeedback      = 1;

% Figure Settings
settings.Figures.Color                  = [1 1 1];
settings.Figures.FaceColor              = [.5 .5 .5];
settings.Figures.EdgeColor              = [0 0 0];
settings.Figures.MarkerEdgeColor        = [0 0 0];
settings.Figures.MarkerFaceColor        = [0 0 0];
settings.Figures.LineColor              = [0 0 0];
settings.Figures.FontSize               = 12;
settings.Figures.Font                   = 'Times';
settings.Figures.linewidth              = 1;
settings.Figures.FigureName             = '';
settings.Figures.Title                  = '';
settings.Figures.Xlabel                 = '';
settings.Figures.Ylabel                 = '';
settings.Figures.Marker                 = 'none';
settings.Figures.chanceline             = 0;
settings.Figures.YMAX                   = [];
settings.Figures.YMIN                   = [];
settings.Figures.newfigure              = 0;
settings.Figures.xticklabels{1}         = '';
settings.Figures.showbox                = 'off';
settings.Figures.subplot                = 0;
settings.Figures.subplotcords           = [];
settings.Figures.FSPreport              = 'Accuracy'; %'F1'
settings.Figures.CMtext                 = 1;
settings.Figures.Colormap               = 1;
if  settings.Figures.Colormap ==4
    settings.Figures.CMtextColor            = [1 1 1];
else
    settings.Figures.CMtextColor            = [0 0 0];
end

% Saving Settings
settings.Saving.ProjectName             = '';
if ~isempty(settings.Saving.ProjectName) && ~strcmp(settings.Saving.ProjectName(end),'_')
    addund = '_';
else
    addund = '';
end
settings.Saving.savedir                 = [protosc_get_root 'SavedFiles' filesep settings.Saving.ProjectName addund];
settings.Saving.autosaveANA             = 0;
settings.Saving.autosaveFIG             = 0;
settings.Saving.autosaveFIGX            ='bmp';

% adjust Settings if needed
ins                                     = varargin;
settings                                = protosc_update_settings(settings,ins);

    
