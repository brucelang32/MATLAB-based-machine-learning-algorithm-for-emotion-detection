% protosc_ana_update_wrapper_ranking
% 
% this script is a sub-part of protosc_ana_FeatureSelection and
% is not made to function in isolation
% 
% SS 2020
if out.settings.Display.showintremfeedback
    disp(['[In ' mfilename '] Updating Ranking'])
end

chunks              = out.settings.Wrapper.chunks;
updatedrankscores   = (protosc_im_scale(currentrankscores).^.5)/out.datainfo.nclasses + (1/out.datainfo.nclasses);
perf                = zeros(length(chunks),size(currentrankscores,2));
for jj = 1:length(chunks)%out.settings.Wrapper.consistency_its
    [~,ranking] = sort(updatedrankscores,'descend');
%     ranking     = protosc_Shuffle(ranking);
    bol_ind     = protosc_get_BalencedSample(TrainValData,70);
    try
        parfor ii = 1:chunks(jj)
            usepreds = ranking(ii:chunks(jj):end);
            try
                model           = WMLModel(TrainValData(bol_ind==1,[1 usepreds+1]));
                temp{jj,ii}     = CritFunction(TrainValData(bol_ind==0,1),model.predictFcn(TrainValData(bol_ind==0,usepreds+1)));
                loci{jj,ii}     = usepreds;
            catch
                temp{jj,ii}     = nan;
                loci{jj,ii}     = nan;
            end
        end
    catch
        for ii = 1:chunks(jj)
            usepreds = ranking(ii:chunks(jj):end);
            try
                model           = WMLModel(TrainValData(bol_ind==1,[1 usepreds+1]));
                temp{jj,ii}     = CritFunction(TrainValData(bol_ind==0,1),model.predictFcn(TrainValData(bol_ind==0,usepreds+1)));
                loci{jj,ii}     = usepreds;
            catch
                temp{jj,ii}     = nan;
                loci{jj,ii}     = nan;
            end
        end
    end
    for ii = 1:chunks(jj)
        if ~isnan(loci{jj,ii})
            perf(jj,loci{jj,ii}) = temp{jj,ii};
%             perf(jj,loci{jj,ii}) =linspace(temp{jj,ii},.1,length(perf(jj,loci{jj,ii})));
%             g = linspace(1,.1,length(perf(jj,loci{jj,ii})));
        end
    end
    updatedrankscores = (updatedrankscores+perf(jj,:))/2;
end
% currentrankscores   = updatedrankscores;
