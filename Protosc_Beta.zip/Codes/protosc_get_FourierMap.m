function maps = protosc_get_FourierMap(FourierFeatures,settings,plotoff)
% function maps = protosc_show_Fourierfeatures(FourierFeatures,settings,plotoff)
% 
% SS 2020

if ~exist('plotoff','var') || isempty(plotoff)
    plotoff = 0;
end
w = whos('FourierFeatures');
if ~strcmpi(w.class,'cell')
    useFourierFeatures{1} = FourierFeatures;
else
    useFourierFeatures = FourierFeatures;
end

ReferenceMap    = settings.Features.Fourier_ReferenceMap;
if isempty(ReferenceMap)
    ReferenceMap    = protosc_get_Fourier_RefGrid(rand(200),settings);
end
for wcat = 1:size(useFourierFeatures,2)
    if size(useFourierFeatures{1},1)>1
        fvals = mean(useFourierFeatures{wcat});
    else
        fvals = useFourierFeatures{wcat};
    end
    ResultsMap      = zeros(size(ReferenceMap));
    for ii = 1:settings.Features.Fourier_nOri*settings.Features.Fourier_nSF
        ResultsMap(ReferenceMap==ii) = fvals(ii);
    end
    maps{wcat} = rot90(ResultsMap);
    if plotoff == 0
        if size(useFourierFeatures,2)>3
            subplot(ceil(sqrt(size(useFourierFeatures,2))),ceil(sqrt(size(useFourierFeatures,2))),wcat),imagesc(log(maps{wcat})),title(['Average Category ' num2str(wcat)]), axis off, axis square
        else
            subplot(1,size(useFourierFeatures,2),wcat),imagesc(log(maps{wcat})),title(['Average Category ' num2str(wcat)]), axis off, axis square
        end
    end
end
if size(useFourierFeatures,2)==1
    maps = maps{1};
end

    
