function [ranked_ind,rankscores_originalorder] = protosc_rank_NMD(AllData)
% function [ranked_ind,rankscores_originalorder] = protosc_rank_NMD(AllData)
% NMD: Norm (by sumSD) Median Distance
%
% SS 2020

c = 0;
x = nan(length(unique(AllData(:,1))),size(AllData,2)-1);
y = nan(length(unique(AllData(:,1))),size(AllData,2)-1);
for ii = unique(AllData(:,1))'
    c = c+1;
    x(c,:) = median(AllData(AllData(:,1)==ii,2:end));
    y(c,:) = std(AllData(AllData(:,1)==ii,2:end));
end
adm     = nan(sum(c-1:-1:0),size(AllData,2)-1);
assd    = nan(sum(c-1:-1:0),size(AllData,2)-1);
c = 0;
for ii = 1:length(unique(AllData(:,1))')
    for jj = ii+1:length(unique(AllData(:,1))')
        c = c+1;
        adm(c,:)     = x(ii,:)-x(jj,:);
        assd(c,:)    = y(ii,:)+y(jj,:);
    end
end
[~,ranked_ind,~]            = protosc_get_sortscore(sum(abs(adm./assd)),'down');
rankscores_originalorder    = sum(abs(adm./assd));

