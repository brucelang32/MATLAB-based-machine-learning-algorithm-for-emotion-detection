function usecolormap = protosc_figure_colormap
% function usecolormap = protosc_figure_colormap
%
% SS 2020


settings    = protosc_Settings;
if settings.Figures.Colormap == 1
    usecolormap                         = colormap('hot');
    usecolormap(usecolormap(:,1)<1,3)   = linspace(.35,0,length(usecolormap(usecolormap(:,1)<1,1)));
    usecolormap(usecolormap(:,1)<1,1)   = linspace(.35,1,length(usecolormap(usecolormap(:,1)<1,1)));
    usecolormap(1,:)                    = [.5 .5 .5];
    
%     figure; imagesc([0:256; 0:256; 0:256;])
    colormap(usecolormap)
    
elseif settings.Figures.Colormap == 2
    temp                = colormap('hot');
    usecolormap         = ones(256,3);
    %red
    ind                 = 1:round(find(temp(:,1)==1,1,'first')/2);
    usecolormap(ind,1)  = linspace(0,1,length(ind));
    %green
    ind                 = round(find(temp(:,2)>0,1,'first')/1)+25:round(find(temp(:,2)==1,1,'first')/1)+25;
    usecolormap(ind,2)  = linspace(0,1,length(ind));
    usecolormap(1:ind(1),2) = 0;
    %blue
    usecolormap(:,3)    = temp(:,3);
    ind                 = 1:125;
    usecolormap(ind,1)  = linspace(.3,1,length(ind));
    usecolormap(ind,3)  = protosc_im_scale(1-cos(linspace(pi,0,length(ind))))*.35;
    
    % close all
    % plot(usecolormap(:,1),'r'),hold on, plot(temp(:,1),'.k')
    % plot(usecolormap(:,2),'g'),hold on, plot(temp(:,2),'.k')
    % plot(usecolormap(:,3),'b'),hold on, plot(temp(:,3),'.k')
    % figure; imagesc([0:256; 0:256; 0:256;])
    % colormap(usecolormap)
    
    % usecolormap                         = flipud(usecolormap);
    usecolormap(1,:)                         = [.4 .4 .4];
    colormap(usecolormap)
elseif settings.Figures.Colormap == 3
    
    usecolormap         = zeros(256,3);
    %red
    ind1                = 1:121;
    usecolormap(ind1,1) = linspace(1,.4,length(ind1));
    ind                 = 121:256;
    usecolormap(ind,1)  = linspace(.4-(1/length(ind1)),.1,length(ind));
    %green
    ind                 = 175:256;
    usecolormap(ind,2)  = sqrt(linspace(0,1,length(ind)));
    ind                 = 1:50;
    usecolormap(ind,2)  = linspace(1,0,length(ind));
    
    % ind                 = ind1;
    % usecolormap(ind,3)  = linspace(0,.6,length(ind));
    % ind                 = ind1(end):150;
    % usecolormap(ind,3)  = linspace(.58,0,length(ind));
    ind1                 = 1:200;
    usecolormap(ind1,3)  = protosc_im_scale((linspace(pi,0,length(ind1))))*.7+.3;
    ind                 = 201:256;
    usecolormap(ind,3)  = linspace(.3-(1/length(ind1)),.1,length(ind));
    
%         figure; imagesc([0:256; 0:256; 0:256;])
%         colormap(usecolormap)
    
    % usecolormap                         = flipud(usecolormap);
    colormap(usecolormap)
elseif settings.Figures.Colormap == 4
    
    usecolormap         = zeros(256,3);
    
    ind                 = 1:50;
    usecolormap(ind,1)  = linspace(1,0,length(ind));
    usecolormap(ind,2)  = linspace(1,0,length(ind));
    usecolormap(ind,3)  = linspace(1,.1,length(ind));
    
    ind                 = 51:150;
    usecolormap(ind,1)  = linspace(0,.5,length(ind));
    usecolormap(ind,2)  = 0;
    usecolormap(ind,3)  = linspace(.1,.75,length(ind));
    
    ind                 = 150:256;
    usecolormap(ind,1)  = linspace(.5,0,length(ind));
    usecolormap(ind,2)  = linspace(0,1,length(ind));
    usecolormap(ind,3)  = protosc_im_scale((linspace(pi,0,length(ind))))*.75;
    
%         figure; imagesc([0:256; 0:256; 0:256;])
%         colormap(usecolormap)
    colormap(usecolormap)
end





