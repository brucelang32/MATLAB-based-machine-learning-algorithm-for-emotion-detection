function [SFcurve,range] = protosc_get_SFCruve(FourierMap,nsteps,norm)
% function [SFcurve,range] = protosc_get_SFCruve(FourierMap,nsteps)
% 
% SS 2019

if ~exist('nsteps','var')
    nsteps = 5;
end

if ~exist('norm','var')
    norm    = 1;
end
radii       = protosc_im_radimap(size(FourierMap,1));
range       = 0:(min(size(FourierMap)/2)-1)/nsteps:(min(size(FourierMap)/2)-1);%ceil(max(max(radii)))/
SFcurve     = nan(1,length(range)-1);
for ii = 1:length(range)-1
    SFcurve(ii) = nanmean(FourierMap(radii>=range(ii) & radii<range(ii+1)));%/sum(sum(FourierMap));nanmean
end
range = range(1:end-1) + ((min(size(FourierMap)/2)-1)/nsteps)/2;
if norm
    SFcurve = SFcurve/sum(SFcurve);
end