function im = protosc_im_rebuildfft(amps,pha)
% function im = protosc_im_rebuildfft(amps,pha)
%
% SS 2016

% if max(amps(:))<0 && min(amps(:))>=0
%     amps = amps*255;
% end 
if amps(1,1)<amps(round(size(amps,1)/2),round(size(amps,2)/2))
    disp('Might have forgotten to fftshift your spectrum...')
end
im = real(ifft2(amps.*exp(sqrt(-1)*pha)));%+(blur(mask))*4;
im           = im * (1/(max(im(:)) - min(im(:))));
im           = im - median(im);
im           = im+.5;


% im = (im-min(im(:)));
% im = im/max(im(:));