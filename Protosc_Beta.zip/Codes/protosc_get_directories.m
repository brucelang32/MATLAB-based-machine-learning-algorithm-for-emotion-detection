function imdirs = protosc_get_directories(nDirs)
% imdirs = protosc_get_directories(nDirs)
% 
% protosc_get_directories opens gui to select directories
% nDirs: number of directories to select
%
% SS 2020

if nDirs==1
    clear imdirs;
    for ii = 1:nDirs
        disp(['Select folder containing the images for class ' num2str(ii)])
        imdirs{ii} = uigetdir;
        disp(['Selected Folder: ' imdirs{ii}])
        disp(' ');
    end
else
    clear imdirs;
    for ii = 1:nDirs
        disp(['Select folder for images for class ' num2str(ii)])
        imdirs{ii} = uigetdir;
        disp(['Class ' num2str(ii) ' Folder: ' imdirs{ii}])
        disp(' ');
    end
end

