function set = protosc_ana_poolFeatures(setA,setB)
% function setA = protosc_ana_poolFeatures(setA,setB)
%
% example:
% StimFiles       = protosc_get_StimFiles(imdir);
% Stims           = protosc_get_Stims(StimFiles);
% FourierFeatures = protosc_get_Fourier_Mag(Stims,settings);
% HogFeatures     = protosc_get_HOG_Features(Stims,settings)
% Allfeatures     = protosc_ana_poolFeatures(FourierFeatures,HogFeatures)
% AllData         = protosc_ana_Features2AllData(Allfeatures);
% 
% SS 2020


if size(setA,2)==size(setB,2) && size(setA{1},1)==size(setB{1},1)
    for ii = 1:size(setA,2)
        set{ii} = [setA{ii} setB{ii}];
    end
else
    error('Sets do not Match')
end

