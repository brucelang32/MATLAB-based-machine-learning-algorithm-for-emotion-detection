function ReferenceMap = protosc_get_HOG_refmap(im,settings)
% function ReferenceMap = protosc_get_HOG_refmap(im,settings)
% 
% SS 2018

c                   = 1;
c2                  = 1;
imsize              = size(im);
ReferenceMap        = nan(floor(imsize(1)/settings.Features.HOG_cellsize(1)),floor(imsize(2)/settings.Features.HOG_cellsize(2)),settings.Features.HOG_nBins);
nHOGs               = length(ReferenceMap(:));
for start = 1:settings.Features.HOG_nBins:nHOGs
    ReferenceMap(c,c2,:)           = start:start+(settings.Features.HOG_nBins-1);%featurecolumnnumber;
    c = c+1;
    if c > floor(imsize(1)/settings.Features.HOG_cellsize(1))
        c2 = c2+1;
        c = 1;
    end
end

