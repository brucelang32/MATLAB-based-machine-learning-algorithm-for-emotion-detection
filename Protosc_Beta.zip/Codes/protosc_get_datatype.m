function [FeatureReferenceMap,dataType,settings] = protosc_get_datatype(nfeatures,settings)
% function [FeatureReferenceMap,dataType] = protosc_get_datatype(nfeatures,settings)
% 
% SS 2020


if isempty(settings.Features.FeatureReferenceMap)
    % figure out if this is a Fourier or HOG based analysis
    if isfield(settings.Features,'HOG_ImSize') && ~isempty(settings.Features.HOG_ImSize)
        expect_n_hog = (settings.Features.HOG_ImSize(2)/settings.Features.HOG_cellsize(1))*...
            (settings.Features.HOG_ImSize(1)/settings.Features.HOG_cellsize(2))*...
            settings.Features.HOG_nBins;
    else
        expect_n_hog = (200/settings.Features.HOG_cellsize(1))*...
            (200/settings.Features.HOG_cellsize(2))*...
            settings.Features.HOG_nBins;
        settings.Features.HOG_ImSize = [200 200];
    end
    if ~isempty(settings.Features.Fourier_nOri)
        expect_n_fourier                = settings.Features.Fourier_nOri*settings.Features.Fourier_nSF;
    else
        basesettings                    = protosc_Settings;
        expect_n_fourier                = basesettings.Features.Fourier_nOri*basesettings.Features.Fourier_nSF;
    end
    if  expect_n_hog == expect_n_fourier
        dataType                        = 'Ambiguous ';
        FeatureReferenceMap             = reshape(1:nfeatures,ceil(sqrt(nfeatures)),ceil(sqrt(nfeatures)));
    else
        if expect_n_hog == nfeatures
            dataType                    = 'HOG features ';
            FeatureReferenceMap         = protosc_get_HOG_refmap(rand(settings.Features.HOG_ImSize),settings);
        elseif expect_n_fourier == nfeatures
            dataType                    = 'Fourier features ';
            FeatureReferenceMap         = protosc_get_Fourier_RefGrid(rand(200),settings);
        elseif expect_n_fourier+expect_n_hog == nfeatures
            dataType                    = 'Fourier & HOG - dependent';
            dim                         = ceil(sqrt(nfeatures));
            FeatureReferenceMap         = reshape(1:dim^2,dim,dim);
        else
            dataType                    = 'Incompatible reference map, find our solution in: out.datainfo.FeatureReferenceMap';
            dim                         = ceil(sqrt(nfeatures));
            FeatureReferenceMap         = reshape(1:dim^2,dim,dim);
        end
    end
else
    dataType                   = 'Unknown, but map known';
    FeatureReferenceMap        = settings.Features.FeatureReferenceMap;
end
