function protosc_figure_ranking(out)
% function protosc_figure_ranking(out)
%
% SS 2020

scorename = 'Chi-Squared';
settings = protosc_Settings;
protosc_figure_big
for ii = 1%:size(out.Results.RankingScores,2)
    subplot(1,3,1),hold on,protosc_figure_Plot(out.Results.RankingScores{ii},[],'Title','A) Rank Scores','xlabel','Feature Number','ylabel',scorename)
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    subplot(1,3,2),hold on,protosc_figure_Plot(sort(out.Results.RankingScores{ii},'descend'),[],'Title','B) Sorted Rank Scores','xlabel','Feature Rank','ylabel',scorename)
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    subplot(1,3,3),hold on,protosc_figure_Plot(out.Results.FeatureRankCumSum{ii}*100)
end

for ii = 1%:size(out.Results.RankingScores,2)
    subplot(1,3,3),hold on,protosc_figure_Plot(out.Results.FeatureRankCumSum{ii}(1:out.Results.MaxModelParams(ii))*100,...
        [],'linecolor',[1 0 0],'linewidth',settings.Figures.linewidth+1,'Title','C) Cumulative Rank Scores','xlabel','Number of Features','ylabel','% total')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Align
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
s               = .05;
h               = .8;
w               = (1-.20)/3;
yoffset1        = .1;
sp1             = subplot(1,3,1);
sp2             = subplot(1,3,2);
sp3             = subplot(1,3,3);
sp1.Position    = [s    yoffset1      w    h];
sp2.Position    = [s*2+w      yoffset1      w    h];
sp3.Position    = [s*3+2*w      yoffset1      w    h];
