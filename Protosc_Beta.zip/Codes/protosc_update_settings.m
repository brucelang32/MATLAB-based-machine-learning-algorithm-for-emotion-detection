function settings = protosc_update_settings(settings,varargin)
% function settings = protosc_update_settings(settings,ins)
% 
% SS 2020

if length(varargin)>1
    ins = varargin;
else
    ins = varargin{1};
end
% adjust Settings
lvl1 = fields(settings);
lvl2 = {};
wlvl1 = [];
for ii = 1:size(lvl1,1)
    temp = fields(settings.(lvl1{ii}));
    inds = size(lvl2,2)+1:size(lvl2,2)+size(temp,1);
    c = 0;
    for iii = inds
        c = c+1;
        wlvl1{size(wlvl1,2)+1} = lvl1{ii};
        lvl2{iii} = temp{c};
    end
end
adjustproperties    = ins(1:2:length(ins));
setto               = ins(2:2:length(ins));
% adjustproperties    = varargin(1:2:length(varargin));
% setto               = varargin(2:2:length(varargin));
for ii = 1:length(adjustproperties)
    resolved = 0;
    for jj = 1:size(lvl2,2)
        if strcmpi(adjustproperties{ii},lvl2{jj})
            settings.(wlvl1{jj}).(lvl2{jj}) = setto{ii};
            resolved = 1;
        end
    end
    if resolved == 0
        disp(['[ In ' mfilename '] Unknown Property ' adjustproperties{ii} ' has been added to settings-struct, in field: UserAddedProperties'])
        settings.UserAddedProperties.(adjustproperties{ii}) = setto{ii};
    end
end
% if ~isfolder(settings.Saving.savedir)
%     mkdir(settings.Saving.savedir)
%     disp('The following project folder has been added: ')
%     disp(settings.Saving.savedir)
% end
    
