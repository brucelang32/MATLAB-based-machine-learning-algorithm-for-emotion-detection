function [FourierFeatures,settings,FileList] = protosc_get_Fourier_Mag(Stims,settings)
% [FourierFeatures,settings,FileList] = protosc_get_Fourier_Mag(Stims,settings)
% 
% FourierSums = sums of fourier spectrum magnitudes per Spatial Frequency -
% Orientation Range as a vector
% refGrid = reference Matrix in the same of the Fourier Spectrum shape 
% reflecting where the indices in FourierFeatures came from.
% 
% SS 2019

if ~exist('settings','var') || isempty(settings)
    settings = protosc_Settings;
    disp(['[In ' mfilename '] Default number of Frequency Bands: ' num2str(settings.Features.Fourier_nSF)])
    disp(['[In ' mfilename '] Default number of Orientation Bands: ' num2str(settings.Features.Fourier_nOri)])
end
Stims                                   = protosc_check_Stims(Stims);
settings.Features.Fourier_ReferenceMap  = protosc_get_Fourier_RefGrid(Stims{1}(1).im,settings);
settings.Features.Fourier_ImSize        = size(Stims{1}(1).im);
FourierFeatures                         = cell(1,size(Stims,2));
FileList_count = 0;
for l = 1:size(Stims,2)
    disp(['[In ' mfilename '] Extracting Features label ' num2str(l) ' out of ' num2str(length(Stims))])
    for ii = 1:size(Stims{l},2)
        FileList_count = FileList_count+1;
        try
            FileList{FileList_count,1} = Stims{l}(ii).fullname;
        catch
            FileList{FileList_count,1} = 'Unknow Image file';
        end
        if settings.Features.Fourier_nSF==0 && settings.Features.Fourier_nOri==0
            spec                        = fftshift(abs(fft2(Stims{l}(ii).im)));
            FourierFeatures{l}(ii,:)    = spec(:);
        else
            FourierFeatures{l}(ii,:) = protosc_get_Fourier_Sums(Stims{l}(ii).im,settings.Features.Fourier_ReferenceMap);
        end
        if settings.Features.Fourier_Rel
            FourierFeatures{l}(ii,:) = FourierFeatures{l}(ii,:)/median(FourierFeatures{l}(ii,:));
        end
    end
end
if size(Stims,1) == 1 && size(Stims,2) == 1
    FourierFeatures = FourierFeatures{1};
end
    










