function Acc = protosc_perf_AccuracyF1(y,yhat)
% function Acc = protosc_perf_AccuracyF1(y,yhat)
% 
% SS 2019

Acc = (mean(y == yhat)+protosc_perf_F1Macro(y,yhat))/2;




