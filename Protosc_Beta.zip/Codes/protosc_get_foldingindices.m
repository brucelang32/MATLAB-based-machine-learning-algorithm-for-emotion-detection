function foldind = protosc_get_foldingindices(AllData,nfolds)
% function foldind = protosc_get_foldingindices(AllData,nfolds)
%
% SS 2019

if ~exist('nfolds','var') || isempty(nfolds)
    settings    = protosc_Settings;
    nfolds      = settings.Main.nfolds;
end
len         = size(AllData,1);
t_sel       = [];
for ii = 1:ceil(len/nfolds)
    t_sel = [t_sel protosc_Shuffle(1:nfolds)];
end
foldind = t_sel(1:len);
