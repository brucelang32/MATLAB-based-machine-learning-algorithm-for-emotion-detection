function protosc_figure_save(filename,projectname)
% function protosc_figure_save(filename,projectname)
% 
% SS 2020

settings    = protosc_Settings;
ax          = gcf;
for ii = 1:10
    n(ii) = num2str(floor(rand*10));
end
if ~exist('filename','var') || isempty(filename)
    filename    = ['figure_' n];
end
if ~exist('projectname','var') || isempty(projectname)
    loci = [settings.Saving.savedir ];
else
    loci = [settings.Saving.savedir projectname];
    if ~isfolder([settings.Saving.savedir projectname])
        mkdir(loci)
    end
end
saveas(ax,[loci filesep filename],settings.Saving.autosaveFIGX)
disp(['Figure saved as: ' ])
disp(['     ' loci filesep filename])

