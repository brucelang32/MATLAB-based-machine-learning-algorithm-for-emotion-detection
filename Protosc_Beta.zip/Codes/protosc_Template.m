%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Template for Feature Selection Analysis with Protosc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
% SS 2020

projectname                             = 'MyProject';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Directories 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
imdirs{1}                               = [protosc_get_root 'ImageDrop' filesep 'Category1' filesep];
imdirs{2}                               = [protosc_get_root 'ImageDrop' filesep 'Category2' filesep];
% imdirs{n} = 'dirname';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Files 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ext                                     = {'*'};
mustinclude                             = {}; 
maynotinclude                           = {};
labelnames                              = {};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
wantsize                                = [200 200];
makegrey                                = 1;
getfaces                                = 0;
addperc                                 = [];
StimFiles                               = protosc_get_StimFiles(imdirs,ext,mustinclude,maynotinclude);
Stims                                   = protosc_get_Stims(StimFiles,labelnames,wantsize,makegrey,getfaces,addperc);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% All Feature Selection Settings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Main Settings
settings.Main.nfolds                    = 8;    % k-cross validation
settings.Main.samplingPercentage        = 70;   % percentage of data used for training per interation
settings.Main.foldingindices            = [];
settings.Main.MaxFeaturesCrit           = .25;
settings.Main.Classifier                = 'protosc_classy_linSVM';
% Available Classifiers:
% 
% protosc_classy_BaggyTree      - Bagged Decision Tree
% protosc_classy_BoostedTree    - Boosted Decision Tree
% protosc_classy_kNN_10         - k Nearest Neighbors, k set at 10
% protosc_classy_linDis         - Linear Discriminant Analysis
% protosc_classy_linSVM         - Linear Support Vector Machine
% protosc_classy_poly2SVM       - 2nd polynominal Support Vector Machine
% protosc_classy_quadSVM        - Quadratic Support Vector Machine
% protosc_classy_Tree20         - Simple Decision Tree, 20 nodes

% Feature Settings
settings.Features.force_exclude_crit    = .95; %based on progression
settings.Features.force_exclude         = [];
settings.Features.FeatureReferenceMap   = [];
settings.Features.HOG_cellsize          = [10 10];
settings.Features.HOG_nBins             = 9;
settings.Features.HOG_ImSize            = [];
settings.Features.HOG_ReferenceMap      = [];
settings.Features.HOG_Rel               = 0; %absolute(0) or relative(1) HOG
settings.Features.Fourier_nOri          = 16;
settings.Features.Fourier_nSF           = 24;
settings.Features.Fourier_SFsteps       = 'lin';%'invlog';
settings.Features.Fourier_Rel           = 0; %absolute(0) or relative(1) Fourier
settings.Features.Fourier_ImSize        = [];
settings.Features.Fourier_ReferenceMap  = [];

% Univariate Ranking Settings
settings.Ranking.iterations             = 1; % iterations when bootstrapping, does not apply to all
settings.Ranking.func                   = 'protosc_rank_FullKruskalWallis';

% Wrapper Settings
settings.Wrapper.Method                 = 'Wrapper_MLP';
settings.Wrapper.CritFunction           = 'protosc_perf_AccuracyF1'; 
% Available Crition Functions:
% 
% protosc_perf_Accuracy      - Mean fraction correct
% protosc_perf_AccuracyF1    - Mean fraction correct and F1Macro
% protosc_perf_F1Macro       - Mean F1 score
% protosc_perf_F1Min         - Min F1 score
% protosc_perf_Precision     - Mean Precision
% protosc_perf_Recall        - Mean Recall

settings.Wrapper.Classifier             = 'protosc_classy_linSVM';
settings.Wrapper.FinalModelSelection    = 'Accuracy';
settings.Wrapper.startmodelsize         = .25;
settings.Wrapper.chunksearch            = 1;
% settings.Wrapper.chunks                 = [10 7];
settings.Wrapper.SearchSpaceSize        = [];   % number of parameters tried per iteration
settings.Wrapper.SearchSpaceSizeScalar  = 2;    % x times the maxmodelparams
settings.Wrapper.maxincperit            = [];
settings.Wrapper.maxincperitf           = 1/4;
settings.Wrapper.consistency_its        = 4;    % n times you check each param in searchspace (increases consistency may also increase overfitting)
settings.Wrapper.failtolerance          = 5;    % n times add features is allowed to fail before it quits
settings.Wrapper.ReEval01               = 1;    % re evaluate model
settings.Wrapper.ReEvalf                = .5;

% Display options
settings.Display.identifier             = '~';
settings.Display.showintremfeedback     = 1;
settings.Display.showfinalfeedback      = 1;

% Figure Settings
settings.Figures.Color                  = [1 1 1];
settings.Figures.FaceColor              = [.5 .5 .5];
settings.Figures.EdgeColor              = [0 0 0];
settings.Figures.MarkerEdgeColor        = [0 0 0];
settings.Figures.MarkerFaceColor        = [0 0 0];
settings.Figures.LineColor              = [0 0 0];
settings.Figures.FontSize               = 12;
settings.Figures.Font                   = 'Times';
settings.Figures.linewidth              = 1;
settings.Figures.FigureName             = '';
settings.Figures.Title                  = '';
settings.Figures.Xlabel                 = '';
settings.Figures.Ylabel                 = '';
settings.Figures.Marker                 = 'none';
settings.Figures.chanceline             = 0;
settings.Figures.YMAX                   = [];
settings.Figures.YMIN                   = [];
settings.Figures.newfigure              = 0;
settings.Figures.xticklabels{1}         = '';
settings.Figures.showbox                = 'off';
settings.Figures.subplot                = 0;
settings.Figures.subplotcords           = [];
settings.Figures.FSPreport              = 'Accuracy'; %'F1'
settings.Figures.CMtext                 = 1;
settings.Figures.Colormap               = 1;
if  settings.Figures.Colormap ==4
    settings.Figures.CMtextColor            = [1 1 1];
else
    settings.Figures.CMtextColor            = [0 0 0];
end

% Saving Settings
settings.Saving.ProjectName             = '';
if ~isempty(settings.Saving.ProjectName) && ~strcmp(settings.Saving.ProjectName(end),'_')
    addund = '_';
else
    addund = '';
end
settings.Saving.savedir                 = [protosc_get_root 'SavedFiles' filesep settings.Saving.ProjectName addund];
settings.Saving.autosaveANA             = 0;
settings.Saving.autosaveFIG             = 0;
settings.Saving.autosaveFIGX            ='bmp';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Features & Labels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[Fourier,settings,filelist]             = protosc_get_Fourier_Mag(Stims,settings);
[HOGs,settings,~]                       = protosc_get_HOG_Features(Stims,settings);
Data_Fourier                            = protosc_ana_Features2AllData(Fourier);
Data_HOG                                = protosc_ana_Features2AllData(HOGs);
Data_HOGFourier                         = [Data_Fourier Data_HOG(:,2:end)];
% for custom labels (for example to link a behavioural response to an image or a combination of images,
% use protosc_ana_Features2AllData_custom or protosc_ana_Features2AllData_custom_duelstim 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Feature-Selection
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fourier Only
out(1)                                  = protosc_ana_FeatureSelection(Data_Fourier,settings);

% HOG Only
out(2)                                  = protosc_ana_FeatureSelection(Data_HOG,settings);

% Fourier & HOG Combined
out(3)                                  = protosc_ana_FeatureSelection(Data_HOGFourier,settings);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Visualisations & Autoreport
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii = 1:size(out,2)
    [~,filename,~] = protosc_get_datatype(out(ii).datainfo.nfeatures,settings);
    figure;protosc_figure_results_allfolds(out(ii),[],['FoldingResults_' filename],projectname);
    outFeatures                     = protosc_ana_CollectAllFeatureInfo(out(ii),showmodel,crit);
    protosc_figure_Features(outFeatures);
    protosc_figure_save(['FeatureResults_' filename],projectname)
    protosc_report_write_Methods_Results(out(ii))
end




