function IM = protosc_im_match(IM,im)

% figure
% subplot(2,2,1),imshow(IM)
% subplot(2,2,2),imshow(im)
% subplot(2,2,3),histogram(IM(:))
% subplot(2,2,4),histogram(im(:))

% [~,e]=histcounts([IM(:) im(:)]);
% 
% [hIM_N,hIM_EDGES] = histcounts(IM,e);
% [him_N,him_EDGES] = histcounts(im,e);

ormin       = (min(im(:)));
ormax       = (max(im(:)));
orrange     = ormax - ormin;
ormedian    = median(im(:));

nmin       = min(IM(:));
nmax       = max(IM(:));
nrange     = nmax - nmin;

IM           = IM * (orrange/nrange);
IM           = IM - median(IM);
IM           = IM+ormedian;

% figure
% subplot(2,2,1),imshow(IM)
% subplot(2,2,2),imshow(im)
% subplot(2,2,3),histogram(IM(:))
% subplot(2,2,4),histogram(im(:))