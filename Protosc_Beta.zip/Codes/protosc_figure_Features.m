function F = protosc_figure_Features(out,varargin)
% function out = protosc_figure_Features(Input1,Input2,crit)
%
%
% SS 2020

settings = protosc_Settings;
if exist('varargin','var') || ~isempty(varargin)
    ins = varargin;
    settings = protosc_update_settings(settings,ins);
end

c1              = 0;
c2              = 0;
F.SFMap         = [];
F.SFRebuild     = [];
F.SFCurve       = [];
F.OriCurve      = [];
F.HOGMap        = [];
F.HOGrebuild    = [];
F.HOGX          = [];
F.HOGY          = [];

for ii = 1:size(out,2)
    if ~isempty(out(ii).FourierResultsMap)
        c1 = c1+1;
        F.SFMap(:,:,c1)       = out(ii).FourierResultsMap;
        F.SFRebuild(:,:,c1)   = out(ii).FourierFrebuild;
        F.SFCurve(c1,:)       = out(ii).FourierSFcurve/sum(out(ii).FourierSFcurve)*100;
        F.OriCurve(c1,:)      = out(ii).FourierOricurve/sum(out(ii).FourierOricurve)*100;
    end
    if ~isempty(out(ii).HOGResultsMap)
        c2 = c2+1;
        F.HOGMap(:,:,c2)      = mean(out(ii).HOGResultsMap,3);
        F.HOGrebuild(:,:,c2)  = out(ii).HOGRebuildMap;
        F.HOGX(c2,:)          = out(ii).HOGXdist/sum(out(ii).HOGXdist)*100;
        F.HOGY(c2,:)          = out(ii).HOGYdist/sum(out(ii).HOGYdist)*100;
    end
end

if ~isempty(F.SFMap) && isempty(F.HOGMap)
    figure('color',[1 1 1])
    sp1 = subplot(2,2,1);imagesc(mean(F.SFMap,3)),axis square,axis off,title('A) Fourier Map'),xlabel(''),ylabel('')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp2 = subplot(2,2,2);image(repmat(protosc_im_scale(mean(F.SFRebuild,3)),1,1,3)),axis off,axis square,title('B) Fourier Rebuild'),xlabel(''),ylabel('')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp3 = subplot(2,2,3);protosc_figure_Plot(out(1).FourierSFrange,F.SFCurve),axis square,title('C) Spatial Frequency'),xlabel('Spatial Frequency (cpi)'),ylabel('Weigth')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp4 = subplot(2,2,4);protosc_figure_Plot(out(1).FourierOrirange,F.OriCurve),axis square,title('D) Orientation'),xlabel('Orientation (cw deg from vertical)'),ylabel('Weigth')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Align
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    h               = .35;
    w               = .35;
    yoffset1        = .6;
    yoffset2        = .1;
    sp1.Position    = [0.050     yoffset1      w    h];
    sp2.Position    = [0.55      yoffset1      w    h];
    sp3.Position    = [0.050     yoffset2      w    h];
    sp4.Position    = [0.55      yoffset2      w    h];
elseif isempty(F.SFMap) && ~isempty(F.HOGMap)
    figure('color',[1 1 1])
    sp1 = subplot(2,2,1);imagesc(mean(F.HOGMap,3)),axis square,axis off,title('A) HOG Space Map'),xlabel(''),ylabel('')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp2 = subplot(2,2,2);image(repmat(protosc_im_scale(mean(F.HOGrebuild,3)),1,1,3)),axis square,axis off,title('B) HOG Rebuild'),xlabel(''),ylabel('')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp3 = subplot(2,2,3);protosc_figure_Plot(1:size(F.HOGX,2),F.HOGX),axis square,title('C) X Postion'),xlabel('X cell position (left to right)'),ylabel('Weigth')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp4 = subplot(2,2,4);protosc_figure_Plot(1:size(F.HOGY,2),F.HOGY),axis square,title('D) Y Position'),xlabel('Y cell position (top to bottom)'),ylabel('Weigth')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Align
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    h               = .35;
    w               = .35;
    yoffset1        = .6;
    yoffset2        = .1;
    sp1.Position    = [0.050     yoffset1      w    h];
    sp2.Position    = [0.55      yoffset1      w    h];
    sp3.Position    = [0.050     yoffset2      w    h];
    sp4.Position    = [0.55      yoffset2      w    h];
elseif ~isempty(F.SFMap) && ~isempty(F.HOGMap)
    protosc_figure_big
    sp1 = subplot(2,4,1);imagesc(mean(F.SFMap,3)),axis square,axis off,title('A) Fourier Map'),xlabel(''),ylabel('')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp2 = subplot(2,4,2);image(repmat(protosc_im_scale(mean(F.SFRebuild,3)),1,1,3)),axis off,axis square,title('B) Fourier Rebuild'),xlabel(''),ylabel('')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp3 = subplot(2,4,3);protosc_figure_Plot(out(1).FourierSFrange,F.SFCurve),axis square,title('C) Spatial Frequency'),xlabel('Spatial Frequency (cpi)'),ylabel('Weigth')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp4 = subplot(2,4,4);protosc_figure_Plot(out(1).FourierOrirange,F.OriCurve),axis square,title('D) Orientation'),xlabel('Orientation (cw deg from vertical)'),ylabel('Weigth')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp5 = subplot(2,4,5);imagesc(mean(F.HOGMap,3)),axis square,axis off,title('E) HOG Space Map'),xlabel(''),ylabel('')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp6 = subplot(2,4,6);image(repmat(protosc_im_scale(mean(F.HOGrebuild,3)),1,1,3)),axis square,axis off,title('F) HOG Rebuild'),xlabel(''),ylabel('')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp7 = subplot(2,4,7);protosc_figure_Plot(1:size(F.HOGX,2),F.HOGX),axis square,title('G) X Postion'),xlabel('X cell position (left to right)'),ylabel('Weigth')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    sp8 = subplot(2,4,8);protosc_figure_Plot(1:size(F.HOGY,2),F.HOGY),axis square,title('H) Y Position'),xlabel('Y cell position (top to bottom)'),ylabel('Weigth')
    set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Align
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    h               = .35;
    w               = .15;
    yoffset1        = .6;
    yoffset2        = .1;
    sp1.Position    = [0.050    yoffset1      w    h];
    sp2.Position    = [0.30     yoffset1      w    h];
    sp3.Position    = [.55      yoffset1      w    h];
    sp4.Position    = [0.8      yoffset1      w    h];
    sp5.Position    = [0.050    yoffset2      w    h];
    sp6.Position    = [0.30     yoffset2      w    h];
    sp7.Position    = [0.55     yoffset2      w    h];
    sp8.Position    = [0.8      yoffset2      w    h];
end
protosc_figure_colormap;

% out = out_set3;
% Features = HogFeatures3;
% Data = out;
% info = settings;
% vec = (rand(1,10));
% Input1 = out_set3;%HogFeatures3%FourierFeatures3;%HogFeatures3;
% % 
% % %check for missing info
% % if ~exist('Input1','var') || isempty(Input1)
% %     error('At least 1 input required')
% % end
% % if ~exist('crit','var') || isempty(crit)
% %     crit = 0;
% % end
% % if ~exist('Input2','var') || isempty(Input2)
% %     w = whos('Input1');
% %     if strcmpi(w.class,'cell')
% %         Input2 = protosc_Settings;
% %     else
% %         Input2 = 'FinalModel';
% %     end
% % end
% % 
% % w = whos('Input2');
% % if strcmpi(w.class,'struct') % must be settings
% %     settings    = Input2;
% %     model       = 'FinalModel';
% % elseif strcmpi(w.class,'char') % model be a model
% %     model       = Input2;
% %     settings    = protosc_Settings;
% % elseif strcmpi(w.class,'double')
% %     crit        = Input2;
% %     model       = 'FinalModel';
% %     settings    = protosc_Settings;
% % end
% % 
% % 
% % 
% % %check existing info
% % w = whos('Input1');
% % if strcmpi(w.class,'cell') % must be feature matrix
% %     for ii = 1:size(Input1,2)
% %         nfeatures(ii) = size(Input1{1},2);
% %         if size(Input1{ii},1)>1
% %             Features{ii} = mean(Input1{ii});
% %         else
% %             Features{ii} = Input1{ii};
% %         end
% %     end
% % elseif strcmpi(w.class,'double') % must be vector of weigths
% %     nfeatures = size(Input1,2);
% %     for ii = 1:size(Input1,1)
% %         Features{1} = mean(Input1);
% %     end
% % elseif strcmpi(w.class,'struct') % must be FSoutput
% %     for jj = 1:size(Input1,2)
% %         protosc_check_modelname(Input1(jj),model)
% %         nfeatures(jj) = Input1(jj).datainfo.nfeatures;
% %         if strcmpi(model,'FullModel')
% %             Features{jj} = zeros(1,nfeatures(jj));
% %             for ii = 1:size(Input1(jj).Results.(model).Accuracy,2)
% %                 Features{jj} = Features{jj}+Input1(jj).Results.(model).Accuracy(ii);
% %             end
% %             Features{jj} = Features{jj} / size(Input1(jj).Results.(model).Accuracy,2);
% %         else
% %             Features{jj} = zeros(1,nfeatures(jj));
% %             for ii = 1:size(Input1(jj).Results.(model).FeatureIndices,2)
% %                 Features{jj}(Input1(jj).Results.(model).FeatureIndices{ii}) = ...
% %                     Features{jj}(Input1(jj).Results.(model).FeatureIndices{ii})+...
% %                     Input1(jj).Results.(model).Accuracy(...
% %                     mod(1-1,Input1(jj).settings.Main.nfolds)+1);
% %             end
% %         end
% %         Features{jj} = Features{jj}/max(Features{jj});
% % %         Features{jj} = Features{jj}/size(Input1(jj).Results.(model).FeatureIndices,2);
% %     end
% % end
% % 
% % wcl = w;
% % for ii = 1:size(Features,2)
% %     if strcmpi(wcl.class,'struct') % must be FSoutput
% %         settings = Input1(ii).settings;
% %     end
% %     [FeatureReferenceMap,dataType,settings]  = protosc_get_datatype(nfeatures(ii),settings);
% %     out(ii).dataType            = dataType;
% %     out(ii).settings            = settings;
% %     if strcmpi(dataType,'Fourier features ')
% %         if ii == 2 && size(Input1,2) == 2
% %             [~,lastdataType,~]  = protosc_get_datatype(nfeatures(1),settings);
% %             figure('name',[lastdataType '& ' dataType])
% %             set(gcf,'Position',[100 100 1000 500])
% %             set(gcf,'Position',[100 100 1000 500])
% %         else
% %             figure('name',dataType)
% %         end
% %         out(ii).FourierReferenceMap = FeatureReferenceMap;
% %         ResultsMap                  = zeros(size(FeatureReferenceMap));
% %         for jj = 1:nfeatures(ii)
% %             ResultsMap(FeatureReferenceMap==jj) = Features{ii}(jj);
% %         end
% %         if ~strcmpi(model,'FullModel')
% %             perc_crit = prctile(Features{ii}(Features{ii}~=0),crit);
% %             ResultsMap(ResultsMap<perc_crit) = 0;
% %         end
% % %         ResultsMap                  = protosc_im_scale(ResultsMap);
% %         [F.SFCurve,sfrange]           = protosc_get_SFCruve(ResultsMap,settings.Features.Fourier_nSF);
% %         [F.OriCurve,orirange]         = protosc_get_ORICruve(rot90(ResultsMap),settings.Features.Fourier_nOri);
% %         F.SFCurve(isnan(F.SFCurve))     = 0;
% %         F.OriCurve(isnan(F.OriCurve))   = 0;
% %         orilimits                   = [0 180 0 max(F.OriCurve)*110];
% %         if orilimits(4) == 0
% %             disp('Problem with criterium')
% %             orilimits(4) = 110;
% %         end
% %         ResultsMapSmooth            = conv2(ResultsMap,protosc_im_GaussPatch(size(ResultsMap,1)/20,size(ResultsMap,1)/40,1,0),'same');
% %         Frebuild                    = protosc_im_rebuildfft(fftshift(ResultsMapSmooth)./(fftshift(protosc_im_radimap(200)+.0001)),rand(200)*pi*2-pi);
% %         ResultsMap                  = rot90(ResultsMap);
% %         if strcmpi(wcl.class,'cell')
% %             ResultsMap = log(ResultsMap);
% %         end
% %         if size(Input1,2) == 2
% %             subplot(2,4,1),imagesc(ResultsMap),axis off,axis square,title('A) Fourier Results Map','FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             protosc_figure_colorbar;
% %             subplot(2,4,5),protosc_figure_Plot(sfrange,F.SFCurve*100,'title','E) Fourier SF Distribution','xlabel','CPI','ylabel','Contribution to Performance (%)'),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             subplot(2,4,6),protosc_figure_Plot(orirange,F.OriCurve*100,'title','F) Fourier Ori Distribution','xlabel','Orientation','ylabel','Contribution to Performance (%)'),axis(orilimits),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             subplot(2,4,2),image(repmat(Frebuild,1,1,3)),axis off,axis square,title('B) Fourier Translated','FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             
% %         else
% %             subplot(2,2,1),imagesc(ResultsMap),axis off,axis square,title('A) Results Map','FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             protosc_figure_colorbar;
% %             try
% %                 subplot(2,2,3),protosc_figure_Plot(sfrange,F.SFCurve*100,'title','C) SF Distribution','xlabel','CPI','ylabel','Contribution to Performance (%)'),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             end
% %             try
% %                 subplot(2,2,4),protosc_figure_Plot(orirange,F.OriCurve*100,'title','D) Ori Distribution','xlabel','Orientation','ylabel','Contribution to Performance (%)'),axis(orilimits),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             end
% %             subplot(2,2,2),image(repmat(Frebuild,1,1,3)),axis off,axis square,title('B) Fourier Translated','FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %             %%% Align
% %             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %             h               = .35;
% %             w               = .35;
% %             yoffset1        = .6;
% %             yoffset2        = .1;
% %             sp1 = subplot(2,2,1);
% %             sp2 = subplot(2,2,2);
% %             sp3 = subplot(2,2,3);
% %             sp4 = subplot(2,2,4);
% %             
% %             sp1.Position    = [0.050    yoffset1      w    h];
% %             sp2.Position    = [0.55     yoffset1      w    h];
% %             sp3.Position    = [.050     yoffset2      w    h];
% %             sp4.Position    = [0.55     yoffset2      w    h];
% %         end
% %         protosc_figure_colormap;
% %         out(ii).FourierResultsMap   = ResultsMap;
% %         out(ii).Fouriersfrange      = sfrange;
% %         out(ii).FourierF.SFCurve      = F.SFCurve;
% %         out(ii).Fourierorirange     = orirange;
% %         out(ii).FourierF.OriCurve     = F.OriCurve;
% %         out(ii).FourierFrebuild     = Frebuild;
% %     elseif strcmpi(dataType,'HOG features ') % ori is ccw degrees from vert
% %         if ii == 2 && size(Input1,2) == 2
% %             [~,lastdataType,~]  = protosc_get_datatype(nfeatures(1),settings);
% %             set(gcf,'name',[lastdataType '& ' dataType])
% %             set(gcf,'Position',[100 100 1000 500])
% %             set(gcf,'Position',[100 100 1000 500])
% %         else
% %             figure('name',dataType)
% %         end
% %         out(ii).HOGReferenceMap     = FeatureReferenceMap;
% %         ResultsMap                  = zeros(size(FeatureReferenceMap));
% %         for jj = 1:nfeatures(ii)
% %             ResultsMap(FeatureReferenceMap==jj) = Features{ii}(jj);
% %         end
% %         if ~strcmpi(model,'FullModel')
% %             perc_crit = prctile(Features{ii}(Features{ii}~=0),crit);
% %             ResultsMap(ResultsMap<perc_crit) = 0;
% %         end
% %         temp                        = Features{ii};
% %         temp(temp<perc_crit)       = 0;
% %         TransMap                    = (protosc_show_HOGfeatures(temp,settings,1));
% %         xes                         = sum(sum(ResultsMap,3),1);
% %         xes                         = xes/sum(xes)*100;
% %         yes                         = sum(sum(ResultsMap,3),2)';
% %         yes                         = yes/sum(yes)*100;
% %         orirange                    = fliplr((180/(settings.Features.HOG_nBins*2)): (180/settings.Features.HOG_nBins) :180);
% %         F.OriCurve                    = squeeze(sum(sum(ResultsMap,1),2))';
% %         F.OriCurve                    = F.OriCurve/sum(F.OriCurve)*100;
% %         F.OriCurve(isnan(F.OriCurve))   = 0;
% %         orilimits                   = [0 180 0 max(F.OriCurve)*1.1];
% %         if orilimits(4) == 0
% %             orilimits(4) = 110;
% %         end
% %         if size(Input1,2) == 2
% %             subplot(2,4,3),imagesc(TransMap),axis off,axis square,title('C) HOG Results Map','FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             protosc_figure_colorbar;
% %             subplot(2,4,4),plot(yes,(length(yes):-1:1)*settings.Features.HOG_cellsize(1),'k'),title('D) HOG Y Distribution'),xlabel('Contribution to Performance (%)'),ylabel('Y'),box off, axis square,set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             subplot(2,4,7),protosc_figure_Plot((length(xes):-1:1)*settings.Features.HOG_cellsize(2),xes,'title','G) HOG X Distribution','xlabel','X','ylabel','Contribution to Performance (%)'),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             subplot(2,4,8),protosc_figure_Plot(orirange,F.OriCurve,'title','H) Ori Distribution','xlabel','Orientation','ylabel','Contribution to Performance (%)'),axis(orilimits),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %             %%% Align
% %             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %             h               = .35;
% %             w               = .15;
% %             yoffset1        = .6;
% %             yoffset2        = .1;
% %             sp1 = subplot(2,4,1);
% %             sp2 = subplot(2,4,2);
% %             sp3 = subplot(2,4,3);
% %             sp4 = subplot(2,4,4);
% %             sp5 = subplot(2,4,5);
% %             sp6 = subplot(2,4,6);
% %             sp7 = subplot(2,4,7);
% %             sp8 = subplot(2,4,8);
% %             
% %             sp1.Position    = [0.050    yoffset1      w    h];
% %             sp2.Position    = [0.30     yoffset1      w    h];
% %             sp3.Position    = [.55      yoffset1      w    h];
% %             sp4.Position    = [0.8      yoffset1      w    h];
% %             sp5.Position    = [0.050    yoffset2      w    h];
% %             sp6.Position    = [0.30     yoffset2      w    h];
% %             sp7.Position    = [0.55     yoffset2      w    h];
% %             sp8.Position    = [0.8      yoffset2      w    h];
% %         else
% %             subplot(2,2,1),imagesc(TransMap),axis off,axis square,title('A) Results Map','FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             protosc_figure_colorbar;
% %             subplot(2,2,2),plot(yes,(length(yes):-1:1)*settings.Features.HOG_cellsize(1),'k'),title('B) Y Distribution'),xlabel('Contribution to Performance (%)'),ylabel('Y'),box off, axis square,set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             subplot(2,2,3),protosc_figure_Plot((length(xes):-1:1)*settings.Features.HOG_cellsize(2),xes,'title','C) X Distribution','xlabel','X','ylabel','Contribution to Performance (%)'),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             subplot(2,2,4),protosc_figure_Plot(orirange,F.OriCurve,'title','D) Ori Distribution','xlabel','Orientation','ylabel','Contribution to Performance (%)'),axis(orilimits),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %             %%% Align
% %             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %             h               = .35;
% %             w               = .35;
% %             yoffset1        = .6;
% %             yoffset2        = .1;
% %             sp1 = subplot(2,2,1);
% %             sp2 = subplot(2,2,2);
% %             sp3 = subplot(2,2,3);
% %             sp4 = subplot(2,2,4);
% %             
% %             sp1.Position    = [0.050    yoffset1      w    h];
% %             sp2.Position    = [0.55     yoffset1      w    h];
% %             sp3.Position    = [.050     yoffset2      w    h];
% %             sp4.Position    = [0.55     yoffset2      w    h];
% %         end
% %         protosc_figure_colormap;
% %         out(ii).HOGResultsMap       = TransMap;
% %         out(ii).F.HOGXdist            = xes;
% %         out(ii).F.HOGYdist            = yes;
% %         out(ii).HOGorirange         = fliplr(orirange);
% %         out(ii).HOGF.OriCurve         = fliplr(F.OriCurve);
% %     else
% %         figure('color',[1 1 1],'name',dataType)
% %         set(gcf,'Position',[100 100 1000 500])
% %         set(gcf,'Position',[100 100 1000 500])
% %         Fourierfeatures             = Features{ii}(1:settings.Features.Fourier_nOri*settings.Features.Fourier_nSF);
% %         [FeatureReferenceMap,~,settings]  = protosc_get_datatype(length(Fourierfeatures),settings);
% %         ResultsMap                  = zeros(size(FeatureReferenceMap));
% %         for jj = 1:length(Fourierfeatures)
% %             ResultsMap(FeatureReferenceMap==jj) = Fourierfeatures(jj);
% %         end
% %         if ~strcmpi(model,'FullModel')
% %             perc_crit = prctile(Fourierfeatures(Fourierfeatures~=0),crit);
% %             ResultsMap(ResultsMap<perc_crit) = 0;
% %         end
% % %         ResultsMap                  = protosc_im_scale(ResultsMap);
% %         [F.SFCurve,sfrange]           = protosc_get_SFCruve(ResultsMap,settings.Features.Fourier_nSF);
% %         [F.OriCurve,orirange]         = protosc_get_ORICruve(rot90(ResultsMap),settings.Features.Fourier_nOri);
% %         F.SFCurve(isnan(F.SFCurve))     = 0;
% %         F.OriCurve(isnan(F.OriCurve))   = 0;
% %         orilimits                   = [0 180 0 max(F.OriCurve)*110];
% %         if orilimits(4) == 0
% %             disp('Problem with criterium')
% %             orilimits(4) = 110;
% %         end
% %         ResultsMapSmooth            = conv2(ResultsMap,protosc_im_GaussPatch(size(ResultsMap,1)/20,size(ResultsMap,1)/40,1,0),'same');
% %         Frebuild                    = protosc_im_rebuildfft(fftshift(ResultsMapSmooth)./(fftshift(protosc_im_radimap(200)+.0001)),rand(200)*pi*2-pi);
% %         ResultsMap                  = rot90(ResultsMap);
% %         if strcmpi(wcl.class,'cell')
% %             ResultsMap = log(ResultsMap);
% %         end
% %         subplot(2,4,1),imagesc(ResultsMap),axis off,axis square,title('A) Fourier Results Map','FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %         protosc_figure_colorbar;
% %         subplot(2,4,6),protosc_figure_Plot(sfrange,F.SFCurve*100,'title','F) SF Distribution','xlabel','CPI','ylabel','Contribution to Performance (%)'),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %         subplot(2,4,8),protosc_figure_Plot(orirange,F.OriCurve*100,'title','G) Ori Distribution','xlabel','Orientation','ylabel','Contribution to Performance (%)'),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %         subplot(2,4,2),image(repmat(Frebuild,1,1,3)),axis off,axis square,title('B) Fourier Translated','FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %         protosc_figure_colormap;
% %         out(ii).FourierResultsMap   = ResultsMap;
% %         out(ii).Fouriersfrange      = sfrange;
% %         out(ii).FourierF.SFCurve      = F.SFCurve;
% %         out(ii).Fourierorirange     = orirange;
% %         out(ii).FourierF.OriCurve     = F.OriCurve;
% %         out(ii).FourierFrebuild     = Frebuild;
% %         
% %         
% %         
% %         HOGfeatures                         = Features{ii}(settings.Features.Fourier_nOri*settings.Features.Fourier_nSF+1:end);
% %         [FeatureReferenceMap,~,settings]    = protosc_get_datatype(length(HOGfeatures),settings);
% %         ResultsMap                          = zeros(size(FeatureReferenceMap));
% %         for jj = 1:length(HOGfeatures)
% %             ResultsMap(FeatureReferenceMap==jj) = HOGfeatures(jj);
% %         end
% %         if ~strcmpi(model,'FullModel')
% %             perc_crit = prctile(HOGfeatures(HOGfeatures~=0),crit);
% %             ResultsMap(ResultsMap<perc_crit) = 0;
% %         end
% %         temp                        = HOGfeatures;
% %         temp(temp<perc_crit)       = 0;
% %         TransMap                    = (protosc_show_HOGfeatures(temp,settings,1));
% %         xes                         = sum(sum(ResultsMap,3),1);
% %         xes                         = xes/sum(xes)*100;
% %         yes                         = sum(sum(ResultsMap,3),2)';
% %         yes                         = yes/sum(yes)*100;
% %         orirange                    = fliplr((180/(settings.Features.HOG_nBins*2)): (180/settings.Features.HOG_nBins) :180);
% %         F.OriCurve                    = squeeze(sum(sum(ResultsMap,1),2))';
% %         F.OriCurve                    = F.OriCurve/sum(F.OriCurve)*100;
% %         F.OriCurve(isnan(F.OriCurve))   = 0;
% %         orilimits                   = [0 180 0 max(F.OriCurve)*1.1];
% %         if orilimits(4) == 0
% %             disp('Problem with criterium')
% %             orilimits(4) = 110;
% %         end
% %         subplot(2,4,3),imagesc(TransMap),axis off,axis square,title('C) HOG Results Map','FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize);set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %         protosc_figure_colorbar;
% %         subplot(2,4,4),plot(yes,(length(yes):-1:1)*settings.Features.HOG_cellsize(1),'k'),title('D) HOG Y Distribution'),xlabel('Contribution to Performance (%)'),ylabel('Y'),box off, axis square,set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %         subplot(2,4,7),protosc_figure_Plot((length(xes):-1:1)*settings.Features.HOG_cellsize(2),xes,'title','G) HOG X Distribution','xlabel','X','ylabel','Contribution to Performance (%)'),set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %         hold on,subplot(2,4,8),protosc_figure_Plot(orirange,F.OriCurve,'title','H)Ori Distribution','xlabel','Orientation','ylabel','Contribution to Performance (%)','LineColor',[.5 .5 .5]),legend('SF','HOG');set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %         protosc_figure_colormap;
% %         out(ii).HOGResultsMap       = TransMap;
% %         out(ii).F.HOGXdist            = xes;
% %         out(ii).F.HOGYdist            = yes;
% %         out(ii).HOGorirange         = fliplr(orirange);
% %         out(ii).HOGF.OriCurve         = fliplr(F.OriCurve);
% %         
% %         maskSF                      = [ones(1,length(Fourierfeatures)) zeros(1,length(HOGfeatures))];
% %         maskHOG                     = [zeros(1,length(Fourierfeatures)) ones(1,length(HOGfeatures))];
% %         data                        = [(Features{ii}.*maskSF)/sum(maskSF); (Features{ii}.*maskHOG)/sum(maskHOG)]';
% %         data                        = data*length(maskSF);
% %         data                        = data/sum(mean(data))*100;
% %         out(ii).SFHOGRatio          = mean(Features{ii}(maskHOG==0))/mean(Features{ii}(maskHOG==1));
% %         subplot(2,4,5),protosc_figure_Bar(data,'xticklabels',{'SF' 'HOG'},'ylabel','Importance (%)','title','E) Relative Importance');
% %         set(gca,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
% %         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %         %%% Align
% %         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %         h               = .35;
% %         w               = .15;
% %         yoffset1        = .6;
% %         yoffset2        = .1;
% %         sp1 = subplot(2,4,1);
% %         sp2 = subplot(2,4,2);
% %         sp3 = subplot(2,4,3);
% %         sp4 = subplot(2,4,4);
% %         sp5 = subplot(2,4,5);
% %         sp6 = subplot(2,4,6);
% %         sp7 = subplot(2,4,7);
% %         sp8 = subplot(2,4,8);
% %         
% %         sp1.Position    = [0.050    yoffset1      w    h];
% %         sp2.Position    = [0.30     yoffset1      w    h];
% %         sp3.Position    = [.55      yoffset1      w    h];
% %         sp4.Position    = [0.8      yoffset1      w    h];
% %         sp5.Position    = [0.050    yoffset2      w    h];
% %         sp6.Position    = [0.30     yoffset2      w    h];
% %         sp7.Position    = [0.55     yoffset2      w    h];
% %         sp8.Position    = [0.8      yoffset2      w    h];
% %     end
% % end
% % 


% mean weigth in of the SFs devided by the mean weigth of the HOGs




