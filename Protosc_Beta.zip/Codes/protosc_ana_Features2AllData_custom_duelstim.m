function protosc_ana_Features2AllData_custom_duelstim(numericlabel,fileperlabel,allfiles,allfeatures,option)
% function protosc_ana_Features2AllData_custom_duelstim(numericlabel,fileperlabel,allfiles,allfeatures,option)
% 
% 
% SS 2020

% allfeatures     = FourierFeatures;
% numericlabel    = round(rand(1,15));
% fileperlabel    = filelist;
% allfiles        = filelist;

dataind = 0;
skip    = zeros(1,size(fileperlabel{1},1));
for ii = 1:size(fileperlabel{1},1)
    findme  = 1;
    c       = 0;
    while findme
        c = c+1;
        if c <= size(fileperlabel{1},1)
            if strcmp(fileperlabel{1}{ii},allfiles{c})
                findme = 0;
            end
        else
            skip(ii)= 1;
            findme  = 0;
            warning(['Could not find ' fileperlabel{1}{ii} ' in the filelist. Skipping file for now.'])
        end
    end
    if skip == 0
        dataind = dataind+1;
        AllData(dataind,:) = [numericlabel(ii) allfeatures(c,:)];
    end
end

keep = ones(1,size(AllData,1));
dataind = 0;
for ii = 1:size(fileperlabel{1},1)
    if skip(ii)==0
        findme  = 1;
        c       = 0;
        while findme
            c = c+1;
            if c <= size(fileperlabel{1},1)
                if strcmp(fileperlabel{2}{ii},allfiles{c})
                    findme = 0;
                end
            else
                keep(ii)= 0;
                findme  = 0;
                warning(['Could not find ' fileperlabel{2}{ii} ' in the filelist. Removing associated data.'])
            end
        end
        dataind = dataind+1;
        if option == 1 %difference scores
            dAllData(dataind,:) = [AllData(dataind,1) AllData(dataind,2:end)-allfeatures(c,:)];
        else % [label features1 features2]
            dAllData(dataind,:) = [AllData(dataind,:) allfeatures(c,:)];
        end
    end
end
AllData = dAllData(keep,:);



