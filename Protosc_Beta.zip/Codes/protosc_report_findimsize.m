function s = protosc_report_findimsize(out)
% function s = protosc_report_findimsize(out)
% 
% SS 2020

try
    s = [num2str(out(1).settings.Features.Fourier_ImSize(1)),'x',num2str(out(1).settings.Features.Fourier_ImSize(1))];
catch
    s = '200x200';
end