function protosc_figure_CM(CM,varargin)
% function protosc_figure_CM(CM)
%
% SS 2019


settings = protosc_Settings;
if exist('varargin','var') || ~isempty(varargin)
    ins = varargin;
    settings = protosc_update_settings(settings,ins);
end
set(gcf,'color',settings.Figures.Color)
usecolormap     = protosc_figure_colormap;
if isempty(settings.Figures.xticklabels{1})
    for ii = 1:size(CM,1)
        labelnames{ii}      = num2str(ii);
    end
else
    labelnames = settings.Figures.xticklabels;
end
imagesc(CM,[0 1]);
axis square,
box off
xlabel('Predicted class')
ylabel('Real class')
if isempty(settings.Figures.Title)
    title('Confusion Matrix')
else
    title(settings.Figures.Title)
end
protosc_figure_colormap;
protosc_figure_colorbar;
set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize,'XTick',1:size(CM,1),'YTick',1:size(CM,1),'XTickLabels',labelnames,'YTickLabels',labelnames);

CM = CM*100;
% if ~size(CM,1)
if settings.Figures.CMtext
    for ii = 1:size(CM,1)
        for jj = 1:size(CM,2)
            if isnan(CM(ii,jj))
                t = '-';
                hold on
                text(jj-.02,ii-.02,t,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize,'color',settings.Figures.CMtextColor);
            elseif CM(ii,jj)==0
                t = '-';
                hold on
                text(jj-.02,ii-.02,t,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize,'color',settings.Figures.CMtextColor);
            else
                t = num2str(CM(ii,jj));
                if length(t) == 1, t = ['  ' t ' '];end
                if length(t) == 2, t = [' ' t ' '];end
                if length(t) == 3, t = [' ' t ];end
                hold on
                if length(t)>5
                    text(jj-.25,ii-.02,t(1:4),'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize,'color',settings.Figures.CMtextColor);
                else
                    text(jj-.25,ii-.02,t,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize,'color',settings.Figures.CMtextColor);
                end
            end
        end
    end
end
% H.Ticks             = [1 129 256];
% H.TickLabels        = {'  0' ' 50' '100'};

% end

