
% protosc_ana_update_wrapper_ranking
%
% this script is a sub-part of protosc_ana_FeatureSelection and
% is not made to function in isolation
%
% SS 2020
if out.settings.Display.showintremfeedback
    disp(['[In ' mfilename '] Updating Ranking'])
end

test_f                      = find(out.Results.InclusionBolean{ifold}==1);
% [~,birankscore]             = protosc_rank_bivar(TrainValData,test_f(1:out.Results.MaxModelParams(end)*2),out);
[ranked_ind,mrankscore]     = protosc_rank_mvar(TrainValData,out);
[ranked_indw,mrankscorew]   = protosc_rank_mvar_w(TrainValData,out);
[~,~,cscore]                 = protosc_sortscore(currentrankscores);
updatedcurrentrankscores    = cscore.*mrankscorew.*mrankscore + (protosc_im_scale(currentrankscores)/2);
% updatedcurrentrankscores    = birankscore+(mrankscore*2);
[~,index]       = sort(updatedcurrentrankscores(test_f));
test_f          = test_f(index);
nf              = length(test_f);
stepsize        = ceil(out.Results.MaxModelParams(end)/2);
chunks          = ceil(nf/stepsize);
perf            = zeros(1,length(currentrankscores));




try
    parfor ii = 1:chunks
        bol_ind         = protosc_get_BalencedSample(TrainValData,50);
        try
            usepreds        = test_f(1+(stepsize*(ii-1)) : (stepsize*(ii)));
        catch
            usepreds        = test_f(1+(stepsize*(ii-1)) : end);
        end
        model           = WMLModel(TrainValData(bol_ind==1,[1 usepreds+1]));
        [~,temp1(:,ii)]       = CritFunction(TrainValData(bol_ind==0,1),model.predictFcn(TrainValData(bol_ind==0,usepreds+1)));
    end
catch
    for ii = 1:chunks
        bol_ind         = protosc_get_BalencedSample(TrainValData,50);
        try
            usepreds        = test_f(1+(stepsize*(ii-1)) : (stepsize*(ii)));
        catch
            usepreds        = test_f(1+(stepsize*(ii-1)) : end);
        end
        model           = WMLModel(TrainValData(bol_ind==1,[1 usepreds+1]));
        temp1(ii)       = CritFunction(TrainValData(bol_ind==0,1),model.predictFcn(TrainValData(bol_ind==0,usepreds+1)));
    end
end

for ii = 1:chunks
    try
        usepreds        = test_f(1+(stepsize*(ii-1)) : (stepsize*(ii)));
    catch
        usepreds        = test_f(1+(stepsize*(ii-1)) : end);
    end
    perf(usepreds)  = temp1(ii);
end

perf(perf<1/length(unique(TrainValData(:,1))) - 1/length(unique(TrainValData(:,1)))*.1) = 0;
score           = protosc_im_scale(perf)+(protosc_im_scale(currentrankscores)+.5)/2;
% score           = protosc_im_scale(perf);
% test_f          = find(score>median(score));
test_f          = find(out.Results.InclusionBolean{ifold}==1);
% test_f          = find(currentrankscores>prctile(currentrankscores(out.Results.InclusionBolean{ifold}==1),0) & currentrankscores<prctile(currentrankscores(out.Results.InclusionBolean{ifold}==1),50));
stepsize        = ceil(out.Results.MaxModelParams(end)/3);
[~,index]       = sort(score(test_f));
test_f          = test_f(index);
nf              = length(test_f);
chunks          = ceil(nf/stepsize);
try
    parfor ii = 1:chunks
        bol_ind         = protosc_get_BalencedSample(TrainValData,80);
        try
            usepreds        = test_f(1+(stepsize*(ii-1)) : (stepsize*(ii)));
        catch
            usepreds        = test_f(1+(stepsize*(ii-1)) : end);
        end
        model           = WMLModel(TrainValData(bol_ind==1,[1 usepreds+1]));
        temp2(ii)       = CritFunction(TrainValData(bol_ind==0,1),model.predictFcn(TrainValData(bol_ind==0,usepreds+1)));
    end
catch
    for ii = 1:chunks
        bol_ind         = protosc_get_BalencedSample(TrainValData,80);
        try
            usepreds        = test_f(1+(stepsize*(ii-1)) : (stepsize*(ii)));
        catch
            usepreds        = test_f(1+(stepsize*(ii-1)) : end);
        end
        model           = WMLModel(TrainValData(bol_ind==1,[1 usepreds+1]));
        temp2(ii)       = CritFunction(TrainValData(bol_ind==0,1),model.predictFcn(TrainValData(bol_ind==0,usepreds+1)));
    end
end
perf2            = zeros(1,length(currentrankscores));
for ii = 1:chunks
    try
        usepreds        = test_f(1+(stepsize*(ii-1)) : (stepsize*(ii)));
    catch
        usepreds        = test_f(1+(stepsize*(ii-1)) : end);
    end
    perf2(usepreds)  = temp2(ii);
end
perf2(perf2<1/length(unique(TrainValData(:,1))) - 1/length(unique(TrainValData(:,1)))*.1) = 0;
% [~,~,scoreC]    = protosc_get_sortscore(perf);
% [~,index2]      = sort(perf,'descend');

[~,~,s1]                 = protosc_sortscore(perf);
[~,~,s2]                 = protosc_sortscore(perf2);
% s3                       = cscore;
[~,~,s4]                 = protosc_sortscore(mrankscorew);
[~,~,s5]                 = protosc_sortscore(mrankscore);

updatedrankscores = s1.*s2.*s4.*s5.*out.Results.InclusionBolean{ifold};%protosc_im_scale(perf2)+(cscore.*mrankscorew.*mrankscore);

% updatedrankscores = protosc_im_scale(perf.*perf2).*protosc_im_scale(currentrankscores);
