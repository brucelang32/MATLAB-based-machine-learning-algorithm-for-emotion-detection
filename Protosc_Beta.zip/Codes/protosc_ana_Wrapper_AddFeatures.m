function [IncludedParams,refperf,PosibleParams]= protosc_ana_Wrapper_AddFeatures(out,AllData,PosibleParams,IncludedParams,MLmodel)
% function [IncludedParams,refperf,perf,startIndices]= protosc_ana_Wrapper_AddFeatures(out,AllData,PosibleParams,IncludedParams,MLmodel)
%
% this function is a sub-function of protosc_ana_FeatureSelection and
% is not made to function in isolation
% 
% SS 2019

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% [PosibleParams,~] = protosc_rank_bivar(AllData,IncludedParams,out);

AlltestScores   = zeros(1,size(AllData,2)-1);
t_perf          = [];
tryx            = ceil(out.settings.Wrapper.maxincperit/2);
if tryx<2
    tryx = 2;
end
try
    WMLModel           = eval(['@' out.settings.Wrapper.Classifier]);
catch
    WMLModel           = eval(['@' char(out.settings.Wrapper.Classifier)]);
end
try
    CritFunction           = eval(['@' out.settings.Wrapper.CritFunction]);
catch
    CritFunction           = eval(['@' char(out.settings.Wrapper.CritFunction)]);
end


try
    getinds         = 1:2:out.Results.SearchSpaceSizes(end)*2;
    testparams      = PosibleParams(getinds);
catch
    getinds         = 1:1:out.Results.SearchSpaceSizes(end)*1;
    testparams      = PosibleParams(getinds);
end

for i = 1:out.settings.Wrapper.consistency_its
    if i>1
        testparams = protosc_Shuffle(testparams);
    end
    startIndices    = 1:tryx:out.Results.SearchSpaceSizes(end);
    bol_ind         = protosc_get_BalencedSample(AllData,out.settings.Main.samplingPercentage);
    TestData        = AllData(bol_ind==0,:);
    bol_ind_test    = protosc_get_BalencedSample(TestData,100);
    
    model           = MLmodel(AllData(bol_ind==1,[1 IncludedParams+1]));
%     yhat            = model.predictFcn(AllData(bol_ind==0,IncludedParams+1));
%     y               = AllData(bol_ind==0,1);
    r_perf          = CritFunction(TestData(bol_ind_test==1,1),model.predictFcn(TestData(bol_ind_test==1,IncludedParams+1)));
    try
        parfor it = 1:length(startIndices)
            if startIndices(it)+tryx-1<length(testparams)
                usepreds = testparams(startIndices(it):startIndices(it)+tryx-1);
            else
                try
                    tempparams = [testparams testparams];
                    usepreds = tempparams(startIndices(it):startIndices(it)+tryx-1);
                catch
                    tempparams = [testparams testparams];
                    usepreds = tempparams(startIndices(it):end);
                end
            end
            model           = WMLModel(AllData(bol_ind==1,[1 IncludedParams+1 usepreds+1]));
            yhat            = model.predictFcn(TestData(bol_ind_test==1,[IncludedParams+1 usepreds+1]));
            s               = CritFunction(TestData(bol_ind_test==1,1),yhat)-r_perf;
            if s == 0
                s = -.001;
            end
            temp{it} = s;
            loci{it} = usepreds;
        end
    catch
        for it = 1:length(startIndices)
            if startIndices(it)+tryx-1<length(testparams)
                usepreds = testparams(startIndices(it):startIndices(it)+tryx-1);
            else
                tempparams = [testparams testparams];
                usepreds = tempparams(startIndices(it):startIndices(it)+tryx-1);
            end
            model           = WMLModel(AllData(bol_ind==1,[1 IncludedParams+1 usepreds+1]));
            yhat            = model.predictFcn(TestData(bol_ind_test==1,[IncludedParams+1 usepreds+1]));
            s               = CritFunction(TestData(bol_ind_test==1,1),yhat)-r_perf;
            if s == 0
                s = -.001;
            end
            temp{it} = s;
            loci{it} = usepreds;
        end
    end
    for it = 1:size(loci,2)
        AlltestScores(size(AlltestScores,1)+1,loci{it}) = temp{it};
    end
end

% f                           = AlltestScores(:);

testscores                      = nansum(AlltestScores(:,testparams))./nansum(AlltestScores(:,testparams)~=0);%CombineWrapItfun(AlltestScores(:,testparams));
mininc                          = median(testscores);
if isnan(mininc)
    mininc = 0;
elseif mininc<0
    mininc = 0;
end
% testscores(testscores<mininc)   = 0;
% testscores                      = (out.Results.UpdatedRankScores{end}(testparams)/mean(out.Results.UpdatedRankScores{end}(testparams)))+(testscores/testscores);
[sorted,originalindex,~]        = protosc_sortscore(testscores,'down');
ordered                         = testparams(originalindex(sorted>=mininc));
% PosibleParams(getinds)          = originalindex;
removeme                        = testparams(originalindex(sorted<mininc));
[PosibleParams,~]               = protosc_check_PosibleParams(PosibleParams,removeme);
PosibleParams                   = [PosibleParams removeme];
if length(ordered)<=out.settings.Wrapper.maxincperit
    IncludedParams                  = [IncludedParams ordered];
else
    IncludedParams                  = [IncludedParams ordered(1:out.settings.Wrapper.maxincperit)];
end
refperf                         = r_perf;

