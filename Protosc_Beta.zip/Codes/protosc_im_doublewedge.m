function M1 = protosc_im_doublewedge(diameter,ori,width)
% function M = protosc_im_doublewedge(diameter,ori,width)
%
% SS 2016

% try
%     M1  = protosc_im_wedge(diameter,ori,width);
%     M2  = protosc_im_wedge(diameter,ori+180,width);
%     M   = M1+M2;
% catch err
%     M = err;
% end
if ~exist('diameter','var') || isempty(diameter)
    diameter = 100;
end
if ~exist('ori','var') || isempty(ori)
    ori = 0;
end
if ~exist('width','var') || isempty(width)
    width = 10;
end
% diameter = diameter*3;
M1 = protosc_im_wedge(diameter,0,width);
M1 = M1+flipud(M1);
M1(M1>1)=1;
% M1(:,ceil(diameter/2)-1:ceil(diameter/2))=max(M1(:));

% M = protosc_im_anglemap(diameter);
% M(isnan(M)) = 1;
% M1 = zeros(size(M));
% if ori<0
%     ori = 360+ori;
% end
% if ori-(width/2) < 0
%     M1(M>=360+(ori-(width/2)))   = 1;
%     M1(M<=ori+(width/2))         = 1;
% else
%     M1(M>=(ori-(width/2)) & M<=(ori+(width/2))) = 1;
% end
% ori2 = ori+180;
% if ori2-(width/2) < 0
%     M1(M>=360+(ori2-(width/2)))   = 1;
%     M1(M<=ori2+(width/2))         = 1;
% else
%     M1(M>=(ori2-(width/2)) & M<=(ori2+(width/2))) = 1;
% end
M1 = imrotate(M1,180-ori,'crop');
% M1 = imresize(M1,1/3);

