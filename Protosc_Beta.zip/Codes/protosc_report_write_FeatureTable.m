function t = protosc_report_write_FeatureTable(out,t,filename,projectname)

settings = protosc_Settings;
if ~exist('t','var') || isempty(t)
    t = table;
end
if ~exist('projectname','var') || isempty(projectname)
    if isfield(out(1),settings) && ~isempty(out(1).settings.Saving.ProjectName)
        loci = [settings.Saving.savedir out.settings.Saving.ProjectName];
    else
        loci = [settings.Saving.savedir];
    end
else
    loci = [settings.Saving.savedir projectname];
    if ~isfolder([settings.Saving.savedir projectname])
        mkdir(loci)
    end
end
if ~exist('filename','var') || isempty(filename)
    filename    = [loci filesep 'Protosc_Feature_Table.XLSX'];
    savenow = 0;
else
    filename    = [loci filesep filename];
    savenow = 1;
end


clear tempvar
for ii = 1:size(out,2)
    try
        tempvar(ii,1) = str2double(v(ii).settings.Display.identifier);
    catch
        try
            tempvar{ii,1} = out(ii).settings.Display.identifier;
        catch
            tempvar{ii,1} = ' ';
        end
    end
end
t = addvars(t,tempvar,'NewVariableNames', 'identifier');
try
    clear tempvar
    for jj = 1:length(out(ii).FourierSFcurve)
        for ii = 1:size(out,2)
            tempvar(ii,1) = out(ii).FourierSFcurve(jj);
        end
        t = addvars(t,tempvar,'NewVariableNames', ['sf cpi: ' num2str(out(ii).Fouriersfrange(jj))]);
    end
catch
    disp('Missing FourierSFcurve')
end
try
    clear tempvar
    for jj = 1:length(out(ii).FourierOricurve)
        for ii = 1:size(out,2)
            tempvar(ii,1) = out(ii).FourierOricurve(jj);
        end
        t = addvars(t,tempvar,'NewVariableNames', ['sf ori: ' num2str(out(ii).Fourierorirange(jj))]);
    end
catch
    disp('Missing FourierOricurve')
end
try
    clear tempvar
    for jj = 1:length(out(ii).HOGXdist)
        for ii = 1:size(out,2)
            tempvar(ii,1) = out(ii).HOGXdist(jj);
        end
        t = addvars(t,tempvar,'NewVariableNames', ['hog X position L2R: ' num2str(jj)]);
    end
catch
    disp('Missing HOGXdist')
end
try
    clear tempvar
    for jj = 1:length(out(ii).HOGYdist)
        for ii = 1:size(out,2)
            tempvar(ii,1) = out(ii).HOGYdist(jj);
        end
        t = addvars(t,tempvar,'NewVariableNames', ['hog Y position U2D: ' num2str(jj)]);
    end
catch
    disp('Missing HOGYdist')
end
try
    clear tempvar
    for jj = 1:length(out(ii).HOGOricurve)
        for ii = 1:size(out,2)
            tempvar(ii,1) = out(ii).HOGOricurve(jj);
        end
        t = addvars(t,tempvar,'NewVariableNames', ['hog ori: ' num2str(out(ii).HOGorirange(jj))]);
    end
catch 
    disp('Missing HOGOricurve')
end
try
    clear tempvar
    for jj = 1:length(out(ii).SFHOGRatio)
        for ii = 1:size(out,2)
            tempvar(ii,1) = out(ii).SFHOGRatio(jj);
        end
        t = addvars(t,tempvar,'NewVariableNames', ['SFHOG Ratio: ' num2str(out(ii).SFHOGRatio(jj))]);
    end
catch 
    disp('Missing SFHOGRatio')
end


if savenow
    try
        writetable(t,filename,'FileType','spreadsheet')
        disp(['Table Generated and saved as: ' filename])
    catch err
        disp('Writing table to file failed.')
        err.identifier
        err.message
    end
end


