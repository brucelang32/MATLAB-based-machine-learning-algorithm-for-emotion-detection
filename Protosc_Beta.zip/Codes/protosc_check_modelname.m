function protosc_check_modelname(out,model)

wfields = fields(out.Results);
chk = 0;
for ii = 1:size(wfields,1)
    chk = chk + strcmpi(wfields{ii},model);
end
if chk == 0
    error('Model name not recognized')
end