function protosc_figure_colorbar

settings            = protosc_Settings;
H                   = colorbar;
H.Label.String      = '%';
H.Label.FontWeight  = 'bold';
% H.Position
H.Color             = settings.Figures.CMtextColor;
H.Label.FontSize    = settings.Figures.FontSize;
H.Label.FontName    = settings.Figures.Font;
H.Label.Position    = [0.5 .5+settings.Figures.FontSize/256 0];
H.Label.Rotation    = 0;
% H.Ticks             = [];
% H.TickLabels        = {};
H.Ticks             = [0.01 .5 .99];
H.TickLabels        = {'  0' ' 50' '100'};
