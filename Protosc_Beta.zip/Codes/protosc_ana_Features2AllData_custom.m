function protosc_ana_Features2AllData_custom(numericlabel,fileperlabel,allfiles,allfeatures)
% function protosc_ana_Features2AllData_custom(numericlabel,fileperlabel,allfiles,allfeatures)
% 
% 
% SS 2020

% allfeatures     = FourierFeatures;
% numericlabel    = round(rand(1,15));
% fileperlabel    = filelist;
% allfiles        = filelist;

if length(numericlabel) ~= size(fileperlabel,1)
    error('numericlabel and fileperlabel incompatible in their size.')
end
dataind = 0;
skip    = zeros(1,length(fileperlabel));
for ii = 1:length(fileperlabel)
    findme  = 1;
    c       = 0;
    while findme
        c = c+1;
        if c <= size(fileperlabel{1},1)
            if strcmp(fileperlabel{1}{ii},allfiles{c})
                findme = 0;
            end
        else
            skip(ii)= 1;
            findme  = 0;
            warning(['Could not find ' fileperlabel{1}{ii} ' in the filelist. Skipping file for now.'])
        end
    end
    if skip == 0
        dataind = dataind+1;
        AllData(dataind,:) = [numericlabel(ii) allfeatures(c,:)];
    end
end
    