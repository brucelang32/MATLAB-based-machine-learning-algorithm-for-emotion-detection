function AllData = protosc_ana_Features2AllData(AllFeatures)
% AllData = protosc_ana_Features2AllData(AllFeatures)
% 
% example:
% FourierFeatures     = protosc_get_Fourier_Mag(Stims,settings)
% AllData             = protosc_ana_Features2AllData(FourierFeatures)
% 
% SS 2019

if size(AllFeatures,2) == 1
    error('Only one field in the cell')
end

nlabels = size(AllFeatures,2);
AllData = [];
for ii = 1:nlabels
    AllData = [AllData; repmat(ii,size(AllFeatures{ii},1),1) AllFeatures{ii}];
end
    