function root = protosc_get_root
% function root = protosc_get_root
%
% SS 2019

current_path    = path;
indProtosc      = strfind(current_path,'Protosc_');
indPathsep      = strfind(current_path,pathsep);
start           = max(indPathsep(indPathsep<indProtosc(1)));
stop            = min(indPathsep(indPathsep>indProtosc(1)));
firstProtosc    = current_path(start+1:stop-1); 
indProtosc2     = strfind(firstProtosc,'Protosc_');
removefrom      = strfind(firstProtosc,filesep);
removefrom      = removefrom(removefrom>indProtosc2(1));
if isempty(removefrom)
    root            = firstProtosc;
else
    root            = firstProtosc(1:removefrom(1)-1);
end
if strcmpi(root(end),filesep)==0
    root = [root filesep];
end



% firstPpath      = current_path(indt(1):indt(2)-1);
% indt2           = strfind(firstPpath,filesep);
% start           = max(indt2(indt2<indt(1)))+length(pathsep);
% stop            = indt2(indt2>indt(1));
% root            = [current_path(start:stop(1)-length(pathsep)) filesep];






