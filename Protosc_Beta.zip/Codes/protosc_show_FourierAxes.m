function SFAxes = protosc_show_FourierAxes
% function protosc_show_FourierAxes
% 
% SS 2020

FA      = round(mean(imread([protosc_get_root filesep 'Codes' filesep 'protosc_im_SFAxes.bmp']),3)/255);
loci    = protosc_im_CenterRect([1 1 300 300],[1 1 size(FA)]);
SFAxes  = FA(loci(1):loci(3),loci(2):loci(4),1);
imagesc(SFAxes),colormap('gray'),box off, axis square, axis off;