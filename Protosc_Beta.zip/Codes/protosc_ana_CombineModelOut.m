function Comb = protosc_ana_CombineModelOut(out)
% function Comb = protosc_get_CombinedModelOut(out)
% 
% example:
% out(1)        = protosc_ana_FeatureSelection(AllData_Fourier,settings)
% out(2)        = protosc_ana_FeatureSelection(AllData_HOG,settings)
% Comb          = protosc_ana_CombineModelOut(out)
% out_Features  = protosc_figure_Features(Comb)
% 
% SS 2020

try
    Comb.datainfo                               = out(1).datainfo;
end
try
    Comb.codeinfo                               = out(1).codeinfo;
end
try
    Comb.settings                               = out(1).settings;
end
Comb.Results.FinalModel.ModelContent        = zeros(size(out(1).Results.FinalModel.ModelContent));
Comb.Results.ControlFinalModel.ModelContent = zeros(size(out(1).Results.FinalModel.ModelContent));

modelnames = {'FullModel' 'Filter' 'Wrapper' 'RandomModel' 'PseudoRandomModel'...
    'FinalModel' 'ControlFull' 'ControlFilter' 'ControlWrapper' 'ControlRandomModel' ...
    'ControlPseudoRandomModel' 'ControlFinalModel'};

for nana = 1:size(out,2)
    Comb.CombinationInfo = 'Combined Structure';
    for ii = 1:size(out(nana).Results.RankingScores,2)
        temp_RS(ii,:)   = out(nana).Results.RankingScores{ii};
        temp_RFCS(ii,:) = out(nana).Results.FeatureRankCumSum{ii};
    end
    Comb.Results.RankingScores{nana}                    = mean(temp_RS);
    Comb.Results.FeatureRankCumSum{nana}                = mean(temp_RFCS);
    for wm = 1:size(modelnames,2)
        if isempty(strfind(modelnames{wm},'Full')) && isempty(strfind(modelnames{wm},'Control'))
            if nana == 1
                Comb.Results.(modelnames{wm}).FeatureIndices = out(nana).Results.(modelnames{wm}).FeatureIndices;
                Comb.Results.MaxModelParams = out(nana).Results.MaxModelParams;
            else
                for jj = 1:size(out(nana).Results.(modelnames{wm}).FeatureIndices,2)
                    Comb.Results.(modelnames{wm}).FeatureIndices{...
                        size(Comb.Results.(modelnames{wm}).FeatureIndices,2)+1} = out(nana).Results.(modelnames{wm}).FeatureIndices{jj};
                    Comb.Results.MaxModelParams(...
                        size(Comb.Results.MaxModelParams,2)+1) = out(nana).Results.MaxModelParams(jj);
                end
            end
        end
        if nana == 1
            if wm == 1
                Comb.Results.reallabels = out(nana).Results.reallabels;
            end
            Comb.Results.(modelnames{wm}).predictedlabels = out(nana).Results.(modelnames{wm}).predictedlabels;
        else
            for jj = 1:size(out(nana).Results.(modelnames{wm}).predictedlabels,2)
                if wm == 1
                    Comb.Results.reallabels{size(Comb.Results.reallabels,2)+1} = out(nana).Results.reallabels{jj};
                end
                Comb.Results.(modelnames{wm}).predictedlabels{...
                    size(Comb.Results.(modelnames{wm}).predictedlabels,2)+1} = out(nana).Results.(modelnames{wm}).predictedlabels{jj};
            end
        end
        Comb.Results.(modelnames{wm}).F1(nana)          = mean(out(nana).Results.(modelnames{wm}).F1);
        Comb.Results.(modelnames{wm}).Accuracy(nana)    = mean(out(nana).Results.(modelnames{wm}).Accuracy);
    end
    Comb.Results.FinalModel.ModelContent                = ...
        Comb.Results.FinalModel.ModelContent + out(nana).Results.FinalModel.ModelContent;
    Comb.Results.ControlFinalModel.ModelContent         = ...
        Comb.Results.ControlFinalModel.ModelContent + out(nana).Results.ControlFinalModel.ModelContent;
end
