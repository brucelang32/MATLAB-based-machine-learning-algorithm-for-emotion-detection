function IM = protosc_im_orifilter(im,ori,width)
% M = im_orifilter(im,ori,width)
%
%  SS 2016


% M = im_rebuildfft(abs(fft2(im)).*im_doublewedge(size(im,1),ori,width),angle(fft2(im)));
% imsize          = size(im);
% rad             = imsize(1)/15;
% [x]             = meshgrid(-rad:rad);
% Gsd             = rad/3;
% Gamp            = 1;
% Goffset         = 0;
% X               = (exp(-(x).^2/(2*Gsd.^2))*Gamp)+Goffset;
% Y               = rot90(X);
% M               = X.*Y;
% Filter = protosc_im_scale(conv2(Filter, M, 'same'));
% ori = 0;
Filter = rot90(protosc_im_doublewedge([size(im,2) size(im,1)],ori,width));

if length(size(im))>2
    IM(:,:,1) = protosc_im_rebuildfft(abs(fft2(im(:,:,1))).*fftshift(Filter),angle(fft2(im(:,:,1))));
    IM(:,:,2) = protosc_im_rebuildfft(abs(fft2(im(:,:,2))).*fftshift(Filter),angle(fft2(im(:,:,2))));
    IM(:,:,3) = protosc_im_rebuildfft(abs(fft2(im(:,:,3))).*fftshift(Filter),angle(fft2(im(:,:,3))));
else
    IM = protosc_im_rebuildfft(abs(fft2(im)).*fftshift(Filter),angle(fft2(im)));
end

IM = protosc_im_match(IM,im);




