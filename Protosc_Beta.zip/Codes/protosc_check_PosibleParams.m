function [PosibleParams,IncludedParams] = protosc_check_PosibleParams(PosibleParams,IncludedParams)
% function [PosibleParams,IncludedParams] = protosc_check_PosibleParams(PosibleParams,IncludedParams)
% 
% 
% SS 2020
for jj = 1:length(IncludedParams)
    PosibleParams = PosibleParams(PosibleParams ~= IncludedParams(jj));
end