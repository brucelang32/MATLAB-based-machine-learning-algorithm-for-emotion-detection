function [] = protosc_get_Analysis_Template
% function [] = protosc_get_Analysis_Template
%
% SS 2019

t = num2str(now);
t = t(end-3:end);
copyfile([protosc_get_root filesep 'Codes' filesep 'protosc_Template.m'],[protosc_get_root filesep 'Analyses' filesep 'newAnalysis' [date t] '.m'],'f');
fileattrib([protosc_get_root filesep 'Analyses' filesep 'newAnalysis' [date t] '.m'],'+w','a')
edit([protosc_get_root filesep 'Analyses' filesep 'newAnalysis' [date t] '.m'])