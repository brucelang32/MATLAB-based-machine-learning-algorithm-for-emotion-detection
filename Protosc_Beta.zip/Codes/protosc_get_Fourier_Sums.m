function FourierSums = protosc_get_Fourier_Sums(Im,refGrid)
% function FourierSums = protosc_get_Fourier_Sums(Im,refGrid)
% 
% SS 2019



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Image input
if ~exist('Im','var') || isempty(Im)
    error('Need to have atleast an image as input')
end
if max(max(Im))>1
    Im = Im/255;
end
spec        = fftshift(abs(fft2(Im))); %normal rotation
% Preallocation
FourierSums = nan(1,length(unique(refGrid(~isnan(refGrid)))));
for ii = unique(refGrid(~isnan(refGrid)))'
    FourierSums(ii) = nansum(spec(refGrid==ii));
end












