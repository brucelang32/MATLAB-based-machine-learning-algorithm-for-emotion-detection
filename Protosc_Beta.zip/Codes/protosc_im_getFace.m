function [Face] = protosc_im_getFace(UseIm1,addperc)
%function [Face] = protosc_im_getFace(UseIm1,addperc)
%
% SS 2018
try
    faceDetector    = vision.CascadeObjectDetector();
    bbox            = step(faceDetector, UseIm1);
    width_t         = bbox(end,3);
    add             = ceil(((width_t/100)*addperc)/2);
    x               = bbox(end,1) - add;
    y               = bbox(end,2) - add;
    width           = bbox(end,3) + add*2;
    height          = bbox(end,4) + add*2;
    Face            = UseIm1(y:y+height,x:x+width,:);
catch
    Face = [];
end