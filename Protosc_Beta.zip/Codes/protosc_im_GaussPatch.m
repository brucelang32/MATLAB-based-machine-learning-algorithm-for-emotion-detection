function M = protosc_im_GaussPatch(rad,sigma,amplitude,offset)
% function M = protosc_im_GaussPatch(rad,sigma,amplitude,offset)
%
% Create Gaussian Blob
%
% SS 2016
% 


[x]     = meshgrid(-rad:rad);
Gsd     = sigma;
Gamp    = amplitude;
Goffset = offset;
X       = (exp(-(x).^2/(2*Gsd.^2))*Gamp)+Goffset;
Y       = rot90(X);
M       = X.*Y;


