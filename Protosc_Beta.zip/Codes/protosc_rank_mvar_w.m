function [ranked_ind,rankscore] = protosc_rank_mvar_w(AllData,out)
% function [ranked_ind,rankscore] = protosc_rank_mvar_w(AllData,out)
% 
% SS 2020

bol_ind_test    = protosc_get_BalencedSample(AllData,100);
AllData         = AllData(bol_ind_test==1,:);
ind             = out.Results.FeatureRanks{end};
included        = ind(1);
left            = ind(2:end);
steps           = out.Results.MaxModelParams(end)*out.settings.Wrapper.SearchSpaceSizeScalar;
labels          = unique(AllData(:,1));
w               = zeros(1,length(labels));
for iii = 1:steps
    a = zeros(steps,length(labels));
    b = zeros(steps,length(labels));
    n = AllData(:,included(1)+1);
    for ii = 2:length(included)
        n = n.*AllData(:,included(ii)+1);
    end
    for kk = 1:steps
        for ii = 1:length(labels)
            a(kk,ii) = median(n(AllData(:,1)==labels(ii)).*AllData(AllData(:,1)==labels(ii),left(kk)+1));
            b(kk,ii) = median(n(AllData(:,1)==labels(ii)));
        end
    end
    w = w + (1 - nansum(abs((a-b))./abs(a+b)) / sum(nansum(abs((a-b))./abs(a+b))));
    st = abs((a-b))./abs(a+b);
    st(isnan(st)) = 0;
    s = nansum(st.*w,2);
    included = [included left(find(s == max(s),1,'first'))];
    left = left(left~=left(find(s == max(s),1,'first')));
end

order = [included left];
x = linspace(1,0,length(ind));
rankscore = zeros(1,length(ind));
for ii = 1:length(ind)
    rankscore(order(ii)) = x(ii);
end
rankscore = rankscore.*out.Results.InclusionBolean{end};
[~,ranked_ind] = sort(rankscore,'descend');



