function protosc_show_CombinedAxes
% function protosc_show_CombinedAxes 
% 
% SS 2020

HAxes   = protosc_show_HOGAxes;
SFAxes  = protosc_show_FourierAxes;
CAxes   = [SFAxes HAxes];
imagesc(CAxes),colormap('gray'),box off, axis square, axis off;