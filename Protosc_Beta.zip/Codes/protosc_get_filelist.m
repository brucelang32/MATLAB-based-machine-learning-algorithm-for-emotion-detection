function filelist = protosc_get_filelist(Stims_or_StimFiles)
% function filelist = protosc_get_filelist(Stims_or_StimFiles)
% 
% SS 2020

c = 0;
for l = 1:size(Stims_or_StimFiles,2)
    for ii = 1:size(Stims_or_StimFiles{l},2)
        c = c+1;
        filelist{c,1} = Stims_or_StimFiles{l}(ii).name;
    end
end