function im_scaled = protosc_im_scale(im_scaled)
% function im_scaled = protosc_im_scale(im_reco)
%
% SS 2016

try
    im_scaled                 = (im_scaled-min(im_scaled(:)));
    im_scaled                 = im_scaled/max(im_scaled(:));
catch
    disp(['In ' mfilename '] Unknown Error, image NOT scaled' ])
end

