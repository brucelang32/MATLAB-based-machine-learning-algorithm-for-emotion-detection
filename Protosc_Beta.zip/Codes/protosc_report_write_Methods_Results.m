function protosc_report_write_Methods_Results(out,filename,projectname)
% function protosc_report_write_Methods_Results(out,filename,projectname)
% 
% SS 2020

if isempty(out(1).settings.Features.HOG_ImSize)
    out(1).settings.Features.HOG_ImSize = [200 200];
end
basecontent = fscanf(fopen([protosc_get_root filesep 'Codes' filesep 'protosc_report_methods_template.txt']),'%c');
rebuildtxt  = basecontent;
go          = 1;
while go
    target      = 'INSERT';
    ind         = strfind(rebuildtxt,target);
    if ~isempty(ind)
    spcs        = strfind(rebuildtxt,' ');
    ind2        = spcs(find(spcs>ind(1),1,'first'));
    getvar      = rebuildtxt(ind+6:ind2-1);
    varout      = eval(getvar);
    pretxt      = rebuildtxt(1:ind-1);
    posttxt     = rebuildtxt(ind2:end);
    rebuildtxt  = [pretxt varout posttxt];
    else
        go = 0;
    end
end

timestamp   = num2str(now);
settings = protosc_Settings;
if ~exist('filename','var') || isempty(filename)
    filename    = ['Protosc_Methods_Results_Report_' date timestamp(end-3:end)];
end
if ~exist('projectname','var') || isempty(projectname)
    loci = [ settings.Saving.savedir ];
    fileID      = fopen([loci filename '.txt'],'w');
else
    loci = [ settings.Saving.savedir projectname];
    if isfolder([settings.Saving.savedir projectname])
        fileID      = fopen([loci filename '.txt'],'w');
    else
        mkdir(loci)
        fileID      = fopen([loci filename '.txt'],'w');
    end
end
fprintf(fileID,'%c',rebuildtxt);
fclose(fileID);
disp(['Report Generated and saved as: ' loci filename '.txt'])
