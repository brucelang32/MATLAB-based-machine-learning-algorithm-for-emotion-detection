function ind = protosc_get_BalencedSample(alldata,include_perc_of_min,type)
% function ind = protosc_get_BalencedSample(alldata,include_perc_of_min)
%
% SS 2018

if ~exist('alldata','var') || isempty(alldata)
    error('protosc_get_BalencedSample requires at least one non-empty input')
end
if ~exist('include_perc_of_min','var')  || isempty(include_perc_of_min)
    include_perc_of_min = 70;
    disp(['[In ' mfilename ' ] Getting balenced sample using 70% of least represented class]'])
end
if ~exist('type','var') || isempty(type)
    type = 'absolute';
end

c = 0;
balence = nan(1,length(unique(alldata(:,1))'));
for ii = unique(alldata(:,1))'
    c = c+1;
    balence(c) = sum(alldata(:,1) == ii);
end
getind          = [];
if strcmpi(type,'absolute')
    c = 0;
    for ii = unique(alldata(:,1))'
        c = c+1;
        inds.(['class' num2str(ii)]) = find(alldata(:,1) == ii);
        getind = [getind; inds.(['class' num2str(ii)])(randsample(max(size(inds.(['class' num2str(ii)]))),floor(min(balence)*(include_perc_of_min/100))))];
    end
    bol_ind         = zeros(size(alldata,1),1);
    bol_ind(getind) = 1;
    ind             = logical(bol_ind);
else
    c = 0;
    for ii = unique(alldata(:,1))'
        c = c+1;
        inds.(['class' num2str(ii)]) = find(alldata(:,1) == ii);
        getind = [getind; inds.(['class' num2str(ii)])(randsample(max(size(inds.(['class' num2str(ii)]))),floor(balence(c)*(include_perc_of_min/100))))];
    end
    bol_ind         = zeros(size(alldata,1),1);
    bol_ind(getind) = 1;
    ind             = logical(bol_ind);
end
