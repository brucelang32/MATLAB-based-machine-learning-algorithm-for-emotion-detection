function loci = protosc_im_CenterRect(rect,fixedRect)
% function loci = protosc_im_CenterRect(rect,fixedRect)
%
% rect & fixedRect are in a [y1 x1 y2 x2] format with x1,y1 referring to
% the coordinates of the upperleft corner of the rect.
% loci provides the coordinates to place rect in the center of fixedRect
%
% Does pretty much the same thing as the CenterRect version from the
% PsychToolBox, just differently
% 
% SS 2019

if isempty(rect)
    rect = [1 1 10 10];
    warning(['[In ' mfilename '] no input, running test version'])
end
if isempty(fixedRect)
    fixedRect = [1 1 100 100];
    warning(['[In ' mfilename '] no input, running test version'])
end

starty = round(((fixedRect(3)-fixedRect(1))/2)-((rect(3)-rect(1))/2));
endy = round(((fixedRect(3)-fixedRect(1))/2)+((rect(3)-rect(1))/2));

startx = round(((fixedRect(4)-fixedRect(2))/2)-((rect(4)-rect(2))/2));
endx = round(((fixedRect(4)-fixedRect(2))/2)+((rect(4)-rect(2))/2));

loci = [starty startx endy endx]+1;

