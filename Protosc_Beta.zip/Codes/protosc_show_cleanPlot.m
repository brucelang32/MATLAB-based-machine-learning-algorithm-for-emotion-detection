function protosc_show_cleanPlot(xdata,ydata,varargin)
% function protosc_show_cleanPlot(xdata,ydata,'PropertyName',Property)
%
% Possible Params:
% See protosc_Settings
%
% SS 2019


settings = protosc_Settings;
if exist('varargin','var') || ~isempty(varargin)
    ins = varargin;
    settings = protosc_update_settings(settings,ins);
end
set(gcf,'color',settings.Figures.Color)
MarkerEdgeColor = settings.Figures.MarkerEdgeColor;
MarkerFaceColor = settings.Figures.MarkerFaceColor;
LineColor       = settings.Figures.LineColor;
FontSize        = settings.Figures.FontSize;
Font            = settings.Figures.Font;
linewidth       = settings.Figures.linewidth;
FigureName      = settings.Figures.FigureName;
Xlabel          = settings.Figures.Xlabel;
Ylabel          = settings.Figures.Ylabel;
Marker          = settings.Figures.Marker;
saveme          = settings.Saving.autosaveFIG;
filename        = [settings.Saving.savedir filesep mfilename '_figure_' date num2str(now)];
newfigure       = settings.Figures.newfigure;
showboxinput    = settings.Figures.showbox;
xticklabels     = settings.Figures.xticklabels;
linestyle       = '-';
YMAX            = max(ydata(:))+max(ydata(:))*.1;
XMAX            = size(ydata,2)+1;

if size(ydata,1) == 1
    calc = -1;
else
    calc = 1;
end

if size(xdata,1)>1
    if size(xdata,1) ~= size(ydata,1)
        error('Not sure how you want me to deal with the different sizes of your xdata and ydata')
    else
        calc = 0;
    end
end

if newfigure==1
    figure('color',[1 1 1]);
end

xmin = min(xdata);
ymin = min(ydata);
ca = gca;
if ca.YLim(2)>YMAX
    YMAX = ca.YLim(2);
end
if calc == 1
    [sorted,originalindex,~]= protosc_get_sortscore(xdata,'up');
    temp_ym  = mean(ydata);
    temp_tsem = std(ydata)/sqrt(size(ydata,1));
    errorbar(sorted,temp_ym(originalindex),temp_tsem(originalindex),'Marker',Marker,'LineStyle',linestyle,'MarkerFaceColor',MarkerFaceColor,...
        'MarkerEdgeColor',MarkerEdgeColor,'Color', LineColor,'LineWidth',linewidth)
elseif calc == 0
    for ii = 1:size(xdata,1)
        [~,originalindex,~]= protosc_get_sortscore(xdata(ii,:),'up');
        hold on, plot(xdata(ii,originalindex),ydata(ii,originalindex),'Marker',Marker,'LineStyle',linestyle,'MarkerFaceColor',MarkerFaceColor,...
            'MarkerEdgeColor',MarkerEdgeColor,'Color', LineColor,'LineWidth',linewidth)
    end
elseif calc == -1
    [~,originalindex,~]= protosc_get_sortscore(xdata,'up');
    plot(xdata(originalindex),ydata(1,originalindex),'Marker',Marker,'LineStyle',linestyle,'MarkerFaceColor',MarkerFaceColor,...
        'MarkerEdgeColor',MarkerEdgeColor,'Color', LineColor,'LineWidth',linewidth)
end
axis square
title(FigureName,'FontName',Font,'FontSize',FontSize)
xlabel(Xlabel,'FontName',Font,'FontSize',FontSize)
ylabel(Ylabel,'FontName',Font,'FontSize',FontSize)
set(gca,'linewidth',linewidth,'FontName',Font,'FontSize',FontSize)
box(showboxinput)


