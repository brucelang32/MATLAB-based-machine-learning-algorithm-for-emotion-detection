function M1 = protosc_im_wedge(diameter,ori,width)
% function M = protosc_im_wedge(diameter,ori,width)
%
% SS 2016
if ~exist('diameter','var') || isempty(diameter)
    diameter = 100;
end
if ~exist('ori','var') || isempty(ori)
    ori = 0;
end
if ~exist('width','var') || isempty(width)
    width = 10;
end
M = protosc_im_anglemap(diameter);
M(isnan(M)) = 1;
M1 = zeros(size(M));
if ori<0
    ori = 360+ori;
end
if ori-(width/2) < 0
    M1(M>=360+(ori-(width/2)))   = 1;
    M1(M<=ori+(width/2))         = 1;
else
    M1(M>=(ori-(width/2)) & M<=(ori+(width/2))) = 1;
end

M1 = ceil(imrotate(M1,180-ori,'crop'));




