function protosc_help
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% help file will show all function and some info on getting started
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SS 2020

disp(' ')
disp(['Protosc ' protosc_get_versioninfo ' Functions and Scripts:'])
dir([protosc_get_root filesep 'Codes' filesep '*.m'])
disp(' ')
disp('Auto Complete:')
disp('In the commandwindow, type protosc_ and the press the tab')
disp('key to look through, and autocomplete, all protosc functions.')
disp(' ')
disp('Demo and Help:')
disp('Run protosc to get help setting up an analysis')
disp('Run protosc_ana_Template to create a template analysis mfile')
disp('See and/or run protosc_demo for a demonstration analysis')
disp('See https://osf.io/f6nbu/?view_only=1f5d8656a2bb44c38017d33b68a7d7ea for more info and help with this Protosc')

