function im = protosc_show_translate_features(out,model,crit)
% function im = protosc_show_translate_features(AllData,out,model,crit)
% 
% SS 2020

if size(out,2)>1
    error('can only do this with one dataset at a time. Try out(1) instead of out as input.')
end
if ~exist('model','var') || isempty(model)
    model = 'FinalModel';
else
    protosc_check_modelname(out,model)
end
settings                            = protosc_Settings;
[ind,~,FeatureTotalScore]           = protosc_ana_MainFeatures(out,model,crit);
x                                   = zeros(size(FeatureTotalScore));
if crit==0
    x                               = FeatureTotalScore;
else
    x(:,ind)                        = FeatureTotalScore(:,ind);
end
if strcmp(out.datainfo.dataType,'HOG features ')
    im                  = protosc_show_HOGfeatures(x,out.settings,1);
    imshow(protosc_im_scale(im));    
%     xdist = protosc_im_scale(sum(sum(out.settings.Features.HOG_ReferenceMap,3),1));
%     ydist = protosc_im_scale(sum(sum(out.settings.Features.HOG_ReferenceMap,3),2));
%     zdist = squeeze(protosc_im_scale(sum(sum(out.settings.Features.HOG_ReferenceMap,1),2)));
%     protosc_show_cleanPlot(1:length(xdist),xdist)
elseif strcmp(out.datainfo.dataType,'Fourier features ')
    AvSpec              = protosc_show_Fourierfeatures(x,out.settings,1);
    AvSpec(AvSpec<0)    = 0;
    Imsize              = out.settings.Features.Fourier_ImSize;
    ResultsMap          = conv2(protosc_ana_FeatureMap(out, model),protosc_im_GaussPatch(Imsize(1)/20,Imsize(1)/40,1,0),'same');
    im                  = protosc_im_rebuildfft(fftshift(rot90(rot90(rot90(ResultsMap))).*rot90(rot90(rot90(AvSpec)))),rand(Imsize(1))*pi*2-pi);
    imshow(im)
else 
    error(['[ In ' mfilename '] Translation not available.' ])
end
set(gcf,'color',settings.Figures.Color),axis square,axis off,colormap('gray'),title('Features 2 Image')
set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize);


