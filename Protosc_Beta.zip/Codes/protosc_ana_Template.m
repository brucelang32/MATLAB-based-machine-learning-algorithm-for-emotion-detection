function [] = protosc_ana_Template
% function [] = protosc_ana_Template
%
% Note that the created file has a fixed filename (newAnalysis.m), make sure to change it after editing the file, otherwise you might overwrite it later)
%
% SS 2019

% t = num2str(now);
% t = t(end-3:end);
copyfile([protosc_get_root filesep 'Codes' filesep 'protosc_Template.m'],[protosc_get_root filesep 'Analyses' filesep 'newAnalysis.m'],'f');
fileattrib([protosc_get_root filesep 'Analyses' filesep 'newAnalysis.m'],'+w','a')
edit([protosc_get_root filesep 'Analyses' filesep 'newAnalysis.m'])