function protosc_figure_big
% function protosc_figure_big
% 
% SS 2020

figure('color',[1 1 1])
set(gcf,'Position',[100 100 1000 500])
% set(gcf,'Position',[100 100 1000 500])