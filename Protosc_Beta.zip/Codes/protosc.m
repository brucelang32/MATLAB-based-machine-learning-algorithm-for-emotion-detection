%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Protosc getting started via prompt
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SS 2019

clc
commandwindow;

disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
disp('%%%             Welcome to Protosc, I will be your guide                %%%')
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
disp(' ')
disp('No response to a question is always treated as option 0 or default ')
disp(' ')
disp('Would you like to: ')
disp(' 0) get help to set up your analysis ')
disp(' 1) edit a template script ');
openscript      = input('Response: ' );
settings        = protosc_Settings;
settings2       = protosc_Settings;
wantsize        = [200 200];
getfaces        = 0;
ext             = [];
mustinclude     = [];
maynotinclude   = [];
labelnames      = [];
getfeatures     = [];

if openscript
    disp('A template analysis will now be open in your editor.')
    pause(1)
    protosc_ana_Template
else
    settings = protosc_Settings;
    disp('Would you like to name your project? If a name is given, it will be turned into a folder for saving files.')
    projectname = input('Project name: ','s');
    checkme = 0;
    while checkme == 0
        disp('How many image directories would you like to read out? ')
        nDirs = input('(0 to use the ImageDrop directories) ' );
        if nDirs==1
            clear imdirs;
            for ii = 1:nDirs
                disp(['Select folder containing the images for category ' num2str(ii)])
                imdirs{ii} = uigetdir(pwd, ['Select folder containing the images for category ' num2str(ii)]);
                disp(['Selected Folder: ' imdirs{ii}])
                disp(' ');
%                 ext{ii} = input('What extention do the files have in this folder? ','s' );
%                 while isempty(ext{ii})
%                     disp('Input required ')
%                     ext{ii} = input('What extention do the files have? ','s' );
%                 end
            end
            checkme = input('You have chosen 1 directory, continue to specify filename criteria(1) or go back(0) ');
        elseif nDirs>1
            nClasses = nDirs;
            clear imdirs;
            for ii = 1:nDirs
                disp(['Select folder for images for category ' num2str(ii)])
                imdirs{ii} = uigetdir(pwd,['Select folder for images for category ' num2str(ii)]);
                disp(['Class ' num2str(ii) ' Folder: ' imdirs{ii}])
                disp(' ');
            end
            checkme = 1;
        else
            if ~exist('imdirs','var') || isempty(imdirs)
                disp(['Using all folders in ' [protosc_get_root filesep 'ImageDrop'] ])
                lfidir = [protosc_get_root filesep 'ImageDrop'];
                filesindir = dir(lfidir);
                c = 0;
                for ii = 3:size(filesindir,1)
                    if filesindir(ii).isdir
                        c = c+1;
                        imdirs{c} = [protosc_get_root filesep 'ImageDrop' filesep filesindir(ii).name];
                    end
                end
                nClasses = c;
                disp(['Found ' num2str(nClasses) '  catagories.'])
            end
            checkme = 1;
        end
    end
    if nDirs==1
        nClasses = input('How many catagories? ' );
        while isempty(nClasses)
            disp('Input required ')
            nClasses = input('How many catagories? ' );
        end
    end
    for ii = 1:nClasses
        disp(['For category ' num2str(ii)])
        mustinclude{ii} = input('What should be in the filenames? (please separate multiple terms with * (e.g. term1*term2): ','s');
        maynotinclude{ii} = input('What should NOT be in the filenames? (please separate multiple terms with * (e.g. term1*term2): ','s');
    end
        
    disp(' ')
    disp('Would you like to: ')
    disp(' 0) Start Feature Selection using the default settings ')
    disp(' 1) Set the main settings yourself ');
    settingsoption = input('Response: ' );
    disp(' ')
    if settingsoption==1
        try
            wantsize    = input('To what size should the images be set? (default = [200 200]): ');
        catch
            disp('an error occurred, most likely you did not put the values between square brackets.')
            wantsize    = input('To what size should the images be set? (default = [200 200]): ');
        end
        if size(wantsize,2)==1
            wantsize = [wantsize wantsize];
        end
        if size(wantsize,2)>2
            disp('Too many entries, max 2')
        end
        while size(wantsize,2)>2
            try
                wantsize    = input('To what size should the images be set? (default = [200 200]): ');
            catch
                disp('an error occurred, most likely you did not put the values between square brackets.')
                wantsize    = input('To what size should the images be set? (default = [200 200]): ');
            end
        end
        getfaces        = input('Extract Faces from Images? (0/1) ' );
        disp('Form which attributes would you like to extract the features?')
        disp(' 0) both HOG and Fourier independently')
        disp(' 1) both HOG and Fourier as a combined set of features')
        disp(' 2) HOG only')
        disp(' 3) Fourier only')
        getfeatures     = input('Response: ' );
        if isempty(getfeatures)
            getfeatures = 0;
        end
        if getfeatures == 0 || getfeatures == 1
            try
                settings.Features.HOG_cellsize    = input('HOG CellSize in pixels (default = [10 10]): ');
            catch
                disp('an error occurred, most likely you did not put the values between square brackets.')
                settings.Features.HOG_cellsize    = input('HOG CellSize in pixels (default = [10 10]): ');
            end
            if size(settings.Features.HOG_cellsize,2)>2
                disp('Too many entries, max 2')
            end
            while size(settings.Features.HOG_cellsize,2)>2
                try
                    settings.Features.HOG_cellsize    = input('HOG CellSize in pixels (default = [10 10]): ');
                catch
                    disp('an error occurred, most likely you did not put the values between square brackets.')
                    settings.Features.HOG_cellsize    = input('HOG CellSize in pixels (default = [10 10]): ');
                end
            end
            try
                settings.Features.Fourier_nSF         = input('Number of Spatial Frequency bands (default = 24): ');
            catch
                disp('an error occurred, please try again and fill in only 1 value.')
                settings.Features.Fourier_nSF         = input('Number of Spatial Frequency bands (default = 24): ');
            end
            while length(settings.Features.Fourier_nSF)>2
                disp('please try again and fill in only 1 value.')
                settings.Features.Fourier_nSF         = input('Number of Spatial Frequency bands (default = 24): ');
            end
            try
                settings.Features.Fourier_settings.Features.Fourier_nOri        = input('Number of Orientation bands (default = 16): ');
            catch
                disp('an error occurred, please try again and fill in only 1 value.')
                settings.Features.Fourier_settings.Features.Fourier_nOri        = input('Number of Orientation bands (default = 16): ');
            end
            while length(settings.Features.Fourier_settings.Features.Fourier_nOri)>2
                disp('please try again and fill in only 1 value.')
                settings.Features.Fourier_settings.Features.Fourier_nOri        = input('Number of Orientation bands (default = 16): ');
            end
        elseif getfeatures == 2
            try
                settings.Features.HOG_cellsize    = input('HOG CellSize in pixels (default = [10 10]): ');
            catch
                disp('an error occurred, most likely you did not put the values between square brackets.')
                settings.Features.HOG_cellsize    = input('HOG CellSize in pixels (default = [10 10]): ');
            end
            while size(settings.Features.HOG_cellsize,2)>2
                try
                    settings.Features.HOG_cellsize    = input('HOG CellSize in pixels (default = [10 10]): ');
                catch
                    disp('an error occurred, most likely you did not put the values between square brackets.')
                    settings.Features.HOG_cellsize    = input('HOG CellSize in pixels (default = [10 10]): ');
                end
            end
        elseif getfeatures == 3
            try
                settings.Features.Fourier_nSF         = input('Number of Spatial Frequency bands (default = 24): ');
            catch
                disp('an error occurred, please try again and fill in only 1 value.')
                settings.Features.Fourier_nSF         = input('Number of Spatial Frequency bands (default = 24): ');
            end
            while length(settings.Features.Fourier_nSF)>2
                disp('please try again and fill in only 1 value.')
                settings.Features.Fourier_nSF         = input('Number of Spatial Frequency bands (default = 24): ');
            end
            try
                settings.Features.Fourier_settings.Features.Fourier_nOri        = input('Number of Orientation bands (default = 16): ');
            catch
                disp('an error occurred, please try again and fill in only 1 value.')
                settings.Features.Fourier_nOri        = input('Number of Orientation bands (default = 16): ');
            end
            while length(settings.Features.Fourier_nOri)>2
                disp('please try again and fill in only 1 value.')
                settings.Features.Fourier_nOri        = input('Number of Orientation bands (default = 16): ');
            end
        end
        try
            settings.Main.nfolds              = input('How many folds for cross-validation? (Default = 8) ' );
        catch
            disp('an error occurred, please try again and fill in only 1 value.')
            settings.Main.nfolds              = input('How many folds for cross-validation? (Default = 8) ' );
        end
        while length(settings.Main.nfolds)>2
            disp('please try again and fill in only 1 value.')
            settings.Main.nfolds              = input('How many folds for cross-validation? (Default = 8) ' );
        end
        try
            settings.Main.MaxFeaturesCrit     = input('What % of the total rankscore will be your maximum amount of features criterium? (Default = .25) ' );
        catch
            disp('an error occurred, please try again and fill in only 1 value.')
            settings.Main.MaxFeaturesCrit     = input('What % of the total rankscore will be your maximum amount of features criterium? (Default = .25) ' );
        end
        while length(settings.Main.MaxFeaturesCrit)>2
            disp('please try again and fill in only 1 value.')
            settings.Main.MaxFeaturesCrit     = input('What % of the total rankscore will be your maximum amount of features criterium? (Default = .25) ' );
        end
        if input('Choose directory for saving files (1) or use default? (0): ')
            disp('Please select a folder for saving files')
            settings.Saving.savedir      = uigetdir(pwd,'Select folder for saving files');
            settings.Saving.savedir = [settings.Saving.savedir filesep];
        end
        if isempty(settings.Features.Fourier_nSF)
            settings.Features.Fourier_nSF = settings2.Features.Fourier_nSF;
        end
        if isempty(settings.Features.Fourier_nOri)
            settings.Features.Fourier_nOri = settings2.Features.Fourier_nOri;
        end
        if isempty(settings.Features.HOG_cellsize)
            settings.Features.HOG_cellsize = settings2.Features.HOG_cellsize;
        end
        if isempty(settings.Main.nfolds)
            settings.Main.nfolds = settings2.Main.nfolds;
        end
        if isempty(settings.Main.MaxFeaturesCrit)
            settings.Main.MaxFeaturesCrit = settings2.Main.MaxFeaturesCrit;
        end
    end
    StimFiles = protosc_get_StimFiles(imdirs,ext,mustinclude,maynotinclude);
    disp(' ')
    disp(' ')
    disp('Please check the given settings: ')
    disp(' ')
    disp(' ')
    disp('Image Directories: ')
    try
        for ii = 1:size(imdirs,2)
            disp(['          - Category ' num2str(ii) ': ' imdirs{ii}])
            disp(['             - ' num2str(size(StimFiles{ii},2)) ' Files Matching Criteria'])
        end
    catch Err
        disp('          - Error')
    end
    disp('Inclusion Criteria: ')
    try
        for ii = 1:size(mustinclude,2)
            if ~isempty(mustinclude{ii})
                disp(['          - Category ' num2str(ii) ': ' mustinclude{ii}])
            else
                disp(['          - Category ' num2str(ii) ': ' 'none'])
            end
        end
    catch Err
        disp('          - Error ')
    end
    disp('Exclusion Criteria: ')
    try
        for ii = 1:size(maynotinclude,2)
            if ~isempty(maynotinclude{ii})
                disp(['          - Category ' num2str(ii) ': ' maynotinclude{ii}])
            else
                disp(['          - Category ' num2str(ii) ': ' 'none'])
            end
        end
    catch Err
        disp('          - Error ')
    end
    %     for ii = 1:nClasses
    %         try
    %             disp(['Category ' num2str(ii) ' is labelled as:                       ' labelnames{ii}])
    %         end
    %     end
    if isempty(wantsize)
        wantsize = [200 200];
    end
    disp(['Images will be scaled to:                        ' num2str(wantsize)])
    if getfaces
        disp(['Faces will be extracted from the images:         ' 'yes'])
    else
        disp(['Faces will be extracted from the images:         ' 'no'])
    end
    if getfeatures == 0
        disp(['Feature Selection will be done on:               ' 'both HOG and Fourier independently'])
    elseif getfeatures == 0
        disp(['Feature Selection will be done on:               ' 'both HOG and Fourier as a combined set of features'])
    elseif getfeatures == 0
        disp(['Feature Selection will be done on:               ' 'HOG only'])
    elseif getfeatures == 0
        disp(['Feature Selection will be done on:               ' 'Fourier only'])
    end
    
    disp(['n Orientation bands (if used) is set to:         ' num2str(settings.Features.Fourier_nOri)])
    disp(['n Spatial Frequency bands (if used) is set to:   ' num2str(settings.Features.Fourier_nSF)])
    disp(['HOG resolution (if used) is set to:              [' num2str(settings.Features.HOG_cellsize) ']'])
    disp(['k-fold Cross-validation set to:                  ' num2str(settings.Main.nfolds)])
    disp(['Max Feature Citerium set to:                     ' num2str(settings.Main.MaxFeaturesCrit)])
    disp(['Saving Data in:                                  ' settings.Saving.savedir])
    disp(' ')
    finalcheck = input('Press enter to run analysis, press 1 to quit: ');
    if isempty(finalcheck) || finalcheck==0
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Get Stims
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Stims       = protosc_get_Stims(StimFiles,labelnames,wantsize,1,getfaces);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Extract Features
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if isempty(getfeatures) || getfeatures == 0 || getfeatures == 1 || getfeatures == 3
            [Fourier,settings,FileList] = protosc_get_Fourier_Mag(Stims,settings); 
        end
        if isempty(getfeatures) || getfeatures == 0 || getfeatures == 1 || getfeatures == 2
            [HOGs,settings,~] = protosc_get_HOG_Features(Stims,settings);
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Combine with labels Features and start analysis
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        d = 0;
        if isempty(getfeatures) || getfeatures == 0
            AllData{1}  = protosc_ana_Features2AllData(Fourier);
            AllData{2}  = protosc_ana_Features2AllData(HOGs);
            FSout(1)    = protosc_ana_FeatureSelection(AllData{1},settings);
            FSout(2)    = protosc_ana_FeatureSelection(AllData{2},settings);
            d=1;
        elseif getfeatures == 1
            Data_Fourier                = protosc_ana_Features2AllData(Fourier);
            Data_HOG                    = protosc_ana_Features2AllData(HOGs);
            AllData                     = [Data_Fourier Data_HOG(:,2:end)];
            FSout                       = protosc_ana_FeatureSelection(AllData,settings);
        elseif getfeatures == 2
            AllData                     = protosc_ana_Features2AllData(HOGs);
            FSout                       = protosc_ana_FeatureSelection(AllData,settings);
        elseif getfeatures == 3
            AllData                     = protosc_ana_Features2AllData(Fourier);
            FSout                       = protosc_ana_FeatureSelection(AllData,settings);
        end
        crit                            = 50;
        showmodel                       = 'FinalModel';
        outFeatures                     = protosc_ana_CollectAllFeatureInfo(FSout,showmodel,crit);
        protosc_figure_Features(outFeatures);
        protosc_report_write_Methods_Results(FSout,[],projectname);
        if d==1
            covariateTableSF    = protosc_report_write_covariateTable(FileList,AllData{1},FSout(1),showmodel,crit,'Fourier_CoVar',projectname);
            covariateTableHOG   = protosc_report_write_covariateTable(FileList,AllData{2},FSout(2),showmodel,crit,'HOG_CoVar',projectname);
        else
            covariateTable      = protosc_report_write_covariateTable(FileList,AllData,FSout,showmodel,crit,'FourierHOG_CoVar',projectname);
        end
    end
end


