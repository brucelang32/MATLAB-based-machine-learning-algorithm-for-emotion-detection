function M = protosc_im_radimap(imsize)
% function M = protosc_im_radimap(imsize)
%
% SS 2016

if ~exist('imsize','var') || isempty(imsize)
    imsize = 100;
end
if length(imsize) == 1
    size_1val   = imsize;
    radius      = (size_1val-1)/2;
    [X, Y]      = meshgrid(-radius:radius,-radius:radius);
    M           = sqrt(X.^2+Y.^2);
else
    size_1val   = max([imsize(1) imsize(2)]);
    radius      = (size_1val-1)/2;
    [X, Y]      = meshgrid(-radius:radius,-radius:radius);
    M1          = sqrt(X.^2+Y.^2);
    cent        = protosc_im_CenterRect([1 1 imsize(1) imsize(2)],[1 1 size(M1)]);
    M           = M1(cent(1):cent(3),cent(2):cent(4));
end