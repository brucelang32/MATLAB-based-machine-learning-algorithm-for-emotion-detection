function M = protosc_im_anglemap(diameter)
% function M = protosc_im_anglemap(diameter)
%
% SS 2016

if ~exist('diameter','var') || isempty(diameter)
    diameter = 100;
end
if length(diameter) == 1
    nX = diameter(1);
    nY = diameter(1);
else
    nX = diameter(2);
    nY = diameter(1);
end
[X,Y]                   = meshgrid(1:nX,1:nY);
X                       = X - (nX/2); Y = Y - (nY/2);
M                       = protosc_im_scale(atan(Y./X))*180;
M(:,1:size(M,2)/2-1)    = M(:,1:size(M,2)/2-1)+180;
