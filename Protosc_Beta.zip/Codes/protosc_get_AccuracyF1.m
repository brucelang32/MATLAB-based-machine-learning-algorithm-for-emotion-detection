function Acc = protosc_get_AccuracyF1(y,yhat)
% function Acc = protosc_get_Accuracy(y,yhat)
% 
% SS 2019

Acc = (mean(y == yhat)+protosc_get_F1Macro(y,yhat))/2;




