function out = protosc_im_circle(radius)
% function out = protosc_im_circle(radius)
%
% SS 2016

if ~exist('radius','var') || isempty(radius)
    radius = 100;
end
[X, Y]  = meshgrid(-radius:radius,-radius:radius);
radimap = sqrt(X.^2+Y.^2);
out     = radimap<radius;