function refGrid = protosc_get_Fourier_RefGrid(Im,settings)
% function refGrid = protosc_get_Fourier_RefGrid(Im,nSF,nORI)
% 
% SS 2019

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Image input
if ~exist('Im','var') || isempty(Im)
    error('Need to have atleast one image as input')
end
if ~exist('settings','var') || isempty(settings)
    settings = protosc_Settings;
    disp(['[In ' mfilename '] Default number of Frequency Bands: ' num2str(settings.Features.Fourier_nSF)])
    disp(['[In ' mfilename '] Default number of Orientation Bands: ' num2str(settings.Features.Fourier_nOri)])
end

% get image info and adjust if needed
Imsize = size(Im);
if length(Imsize)==3
    disp(['[In ' mfilename '] Converted image to greyscale'])
    Im = mean(double(Im),3);
end
Imsize = size(Im);
if max(max(Im))>1
    Im = Im/255;
end
% Set orientation params
OriWidth    = 180/settings.Features.Fourier_nOri;
OriCenters  = linspace(0,180-(OriWidth),settings.Features.Fourier_nOri);
OriCenters2 = OriCenters+180;
% Set spatial frequency params
if strcmpi(settings.Features.Fourier_SFsteps,'invlog')
    sfbands = [0 abs(diff(log((max(Imsize)/2):-(max(Imsize)/2)/settings.Features.Fourier_nSF:0)))];
    sfbands(end) = 1;
    sfbands = sfbands*(max(Imsize)/2);
else
    sfbands     = 0:(max(Imsize)/2)/settings.Features.Fourier_nSF:(max(Imsize)/2);
end
sfstart     = sfbands(1:end-1);
sfend       = sfbands(2:end);

% calc
radii       = protosc_im_radimap(max(Imsize));
angles      = protosc_im_anglemap(max(Imsize));
rect_t      = protosc_im_CenterRect([1 1 Imsize],[1 1 size(radii)]);
refGrid     = nan(size(Im));


c = 0;
for sfsel = 1:length(sfstart)
    for orisel = 1:settings.Features.Fourier_nOri
        c                   = c+1;
        
        if (OriCenters(orisel)-OriWidth/2)<0
            Selection_t = (angles>=360+OriCenters(orisel)-OriWidth/2 | angles<OriCenters(orisel)+OriWidth/2 | ...
                angles>=OriCenters(orisel)-OriWidth/2+180 & angles<OriCenters(orisel)-OriWidth/2+180)==1 & ...
                (radii>=sfstart(sfsel) & radii<sfend(sfsel))==1;
            Selection_t = Selection_t+(angles>=OriCenters2(orisel)-OriWidth/2 & angles<OriCenters2(orisel)+OriWidth/2 | ...
                angles>=OriCenters2(orisel)-OriWidth/2+180 & angles<OriCenters2(orisel)-OriWidth/2+180)==1 & ...
                (radii>=sfstart(sfsel) & radii<sfend(sfsel))==1;
        else
            Selection_t = (angles>=OriCenters(orisel)-OriWidth/2 & angles<OriCenters(orisel)+OriWidth/2 | ...
                angles>=OriCenters(orisel)-OriWidth/2+180 & angles<OriCenters(orisel)-OriWidth/2+180)==1 & ...
                (radii>=sfstart(sfsel) & radii<sfend(sfsel))==1;
            Selection_t = Selection_t+(angles>=OriCenters2(orisel)-OriWidth/2 & angles<OriCenters2(orisel)+OriWidth/2 | ...
                angles>=OriCenters2(orisel)-OriWidth/2+180 & angles<OriCenters2(orisel)-OriWidth/2+180)==1 & ...
                (radii>=sfstart(sfsel) & radii<sfend(sfsel))==1;
        end
        Selection           = Selection_t(rect_t(1):rect_t(3),rect_t(2):rect_t(4))>0;
        refGrid(Selection==1) = c;
    end
end












