%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demo on Test Images
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
% SS 2020

clear all
close all
clc
commandwindow;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up image paramters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Imsize                      = [200 200];
barwidth                    = 20;
barheigth                   = 60;
imsperclass                 = 100;
posx                        = barwidth: Imsize(2) - barwidth;
posy                        = barheigth: Imsize(1) - barheigth;
angle                       = 10; % counterclockwise from vertical, not that protosc_ works with clockwise from vertical
angle                       = 180-angle; % converted to clockwise from vertical
circ                        = protosc_im_circle((Imsize(1)/2)-.5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up Feature Selection Related paramters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
settings                    = protosc_Settings('autosaveANA',0);
nSF                         = 16;
nORI                        = 24;
CellSize                    = [10 10];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create test images
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii = 1:imsperclass
    wn                                                              = protosc_im_rebuildfft(rand(Imsize(1))./(fftshift(protosc_im_radimap(Imsize(1))+.0001)),rand(Imsize(1))*pi*2-pi);
    imfixed                                                         = protosc_im_rebuildfft(rand(Imsize(1))./(fftshift(protosc_im_radimap(Imsize(1))+.0001)),rand(Imsize(1))*pi*2-pi);
    imvar                                                           = protosc_im_rebuildfft(rand(Imsize(1))./(fftshift(protosc_im_radimap(Imsize(1))+.0001)),rand(Imsize(1))*pi*2-pi);
    imfixed(posy(ceil(length(posy)/2))-round(barheigth/2):posy...
        (ceil(length(posy)/2))+round(barheigth/2),posx(ceil(length...
        (posx)/2))-round(barwidth/2):posx(ceil(length(posx)/2))...
        +round(barwidth/2))                                         = 0;
    gety                                                            = ceil(rand*(size(posy,2)));
    getx                                                            = ceil(rand*(size(posx,2)));
    imvar(posy(gety)-round(barheigth/2):posy(gety)+round(barheigth...
        /2),posx(getx)-round(barwidth/2):posx(getx)+round(barwidth...
        /2))                                                        = 0;
    Stims{1}(ii).im                                                 = imrotate(wn,angle,'crop');
    Stims{1}(ii).size                                               = size(wn);
    Stims{1}(ii).im(circ==0)                                        = 1;
    Stims{2}(ii).im                                                 = imrotate(imfixed,angle,'crop');
    Stims{2}(ii).size                                               = size(wn);
    Stims{2}(ii).im(circ==0)                                        = 1;
    Stims{3}(ii).im                                                 = imrotate(imvar,angle,'crop');
    Stims{3}(ii).size                                               = size(wn);
    Stims{3}(ii).im(circ==0)                                        = 1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Extract Features and combine with labels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[FourierFeatures,settings,filelist] = protosc_get_Fourier_Mag(Stims,settings);
[HogFeatures,settings]              = protosc_get_HOG_Features(Stims,settings);
AllDataSF                           = protosc_ana_Features2AllData(FourierFeatures);
AllDataHOG                          = protosc_ana_Features2AllData(HogFeatures);
fouriermaps                         = protosc_get_FourierMap(FourierFeatures,settings,1);
hogmaps                             = protosc_get_HOGMap(HogFeatures,settings,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Examples of each class
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
protosc_figure_big
subplot(3,3,1), imshow(Stims{1}(1).im), title('Category 1: Empty')
subplot(3,3,2), imshow(Stims{2}(1).im), title('Category 2: Fixed')
subplot(3,3,3), imshow(Stims{3}(1).im), title('Category 3: Variable')

subplot(3,3,1+3), imagesc(log(fouriermaps{1})), axis off, axis square, title('Category 1: Average Fourier')
subplot(3,3,2+3), imagesc(log(fouriermaps{2})), axis off, axis square, title('Category 2: Average Fourier')
subplot(3,3,3+3), imagesc(log(fouriermaps{3})), axis off, axis square, title('Category 3: Average Fourier')

subplot(3,3,1+6), imagesc(hogmaps{1}),axis off, axis square, title('Category 1: Average HOG')
subplot(3,3,2+6), imagesc(hogmaps{2}),axis off, axis square, title('Category 2: Average HOG')
subplot(3,3,3+6), imagesc(hogmaps{3}),axis off, axis square, title('Category 3: Average HOG')
colormap('gray')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Run Feature Selection
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
settings.Display.identifier         = 'Fourier';
out(1)                              = protosc_ana_FeatureSelection(AllDataSF,settings);
settings.Display.identifier         = 'HOG';
out(2)                              = protosc_ana_FeatureSelection(AllDataHOG,settings);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Show feature Maps and Confusion Matrices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
crit                                = 50;
showmodel                           = 'FinalModel';
outFeatures                         = protosc_ana_CollectAllFeatureInfo(out,showmodel,crit);
protosc_figure_Features(outFeatures);
average_over_realclass              = 1;
CMSF                                = protosc_ana_CM(out(1),showmodel,average_over_realclass);
CMHOG                               = protosc_ana_CM(out(2),showmodel,average_over_realclass);

protosc_figure_big
subplot(1,2,1),protosc_figure_CM(CMSF,'title','Fourier Confusion Matrix');
subplot(1,2,2),protosc_figure_CM(CMHOG,'title','HOG Confusion Matrix');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Write Analyses output to files
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%write excel file with main covariates
protosc_report_write_covariateTable(filelist,AllDataSF,out(1),showmodel,crit,'SF');
protosc_report_write_covariateTable(filelist,AllDataHOG,out(2),showmodel,crit,'HOG');
% write methods and results section
protosc_report_write_Methods_Results(out,'DemoOutput')

