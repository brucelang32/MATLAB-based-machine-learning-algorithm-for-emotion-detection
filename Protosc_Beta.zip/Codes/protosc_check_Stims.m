function useStims = protosc_check_Stims(Stims)
% function useStims = protosc_check_Stims(Stims)
% 
% SS 2019

s = whos('Stims');
if strcmpi(s.class,'struct')
    useStims{1} = Stims;
elseif strcmpi(s.class,'double')
    useStims{1}(1).im = Stims;
else
    useStims = Stims;
end