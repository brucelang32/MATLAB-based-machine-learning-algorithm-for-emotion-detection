function iminim = protosc_center_im_in_im(im,inim)
% function iminim = protosc_center_im_in_im(im,inim)
% 
% SS 2020

sizeim      = size(im);
sizeinim    = size(inim);
loci        = protosc_im_CenterRect([1 1 sizeim(1) sizeim(2)],[1 1 sizeinim(1) sizeinim(2)]);
iminim        = inim;

iminim(loci(1):loci(3),loci(2):loci(4)) = im;
