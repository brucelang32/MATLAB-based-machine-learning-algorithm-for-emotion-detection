function CM = protosc_ana_CM(out,model,average_over_realclass)
% function CM = protosc_ana_CM(out,model,average_over_realclass)
% 
% example:
% out = protosc_ana_FeatureSelection(AllData,settings)
% CM  = protosc_ana_CM(out,'FinalModel')
% protosc_figure_CM(CM)
% 
% SS 2020

if ~exist('model','var') || isempty(model)
    model = 'FinalModel';
end
if ~exist('average_over_realclass','var') || isempty(average_over_realclass)
    average_over_realclass = 0;
end
y       = [];
yhat    = [];
for ii = 1:length(out.Results.(model).predictedlabels)
    y       = [y; out.Results.reallabels{ii}];
    yhat    = [yhat; out.Results.(model).predictedlabels{ii}];
end

CM = confusionmat(y,yhat);
if average_over_realclass
    CM = CM./repmat(sum(CM,2),1,size(CM,1));
%     CM = CM./repmat(sum(CM,1),size(CM,1),1);
end
    
    
