function report = protosc_report_results(out)
% function report = protosc_report_results(out)
% 
% SS 2020


if size(out,2)==1
    report = [];
elseif size(out,2)==2
    report =['The ' out(1).datainfo.dataType ' analysis and the ' out(2).datainfo.dataType ' analysis were run independently. '];
else
    report ='The following feature selection analyses were run independently. ';
end
for ii = 1:size(out,2)
    report = [report 'To test if the ' out(ii).datainfo.dataType 'resulted in above chance decoding'...
        ', we first compared the full model and final model performances to empirically estimated chance level. ' ];
    report = [report protosc_report_ttest(out(ii).Results.FullModel.Accuracy,out(ii).Results.ControlFull.Accuracy,{'the full model' 'chance'},'both',.01,'accuracy')];
    t_report = protosc_report_ttest(out(ii).Results.FinalModel.Accuracy,out(ii).Results.ControlFinalModel.Accuracy,{'the final model' 'chance'},'both',.01,'accuracy');
    report = [report ' Furthermore, r' t_report(2:end)];
    t_report = protosc_report_finalmodelselection(out(ii));
    report = [report ' Here, t' t_report(2:end) ' The final model used an average of ' num2str(mean(out(ii).Results.MaxModelParams)) ' out of ' ...
        num2str(out(ii).datainfo.nfeatures) ' features, thus using only ' num2str(mean(out(ii).Results.MaxModelParams)/out(ii).datainfo.nfeatures*100) '% of the available features.'];
    t_report = protosc_report_ttest2(out(ii).Results.FinalModel.F1,out(ii).Results.FullModel.F1,{'final model' 'full model'},'both',.01,'accuracy');
    report = [report ' Note that, compared to the full model, that uses 100% of the available features, r' t_report(2:end)];
end

% 
% t_report = protosc_report_ttest(out(1).Results.FinalModel.Accuracy,out(1).Results.ControlFinalModel.Accuracy,{'the final model' 'the control model'},'both',.01,'accuracy');
% 
% if size(out,2)==1
%     checkme = [];
%     try
%         checkme = out.CombinationInfo;
%     catch
%         checkme = [];
%     end
%     if isempty(checkme)
%         report = t_report;
%         t_report = protosc_report_finalmodelselection(out(1));
%         report = [report ' Here, t' t_report(2:end) ' The final model used an average of ' num2str(mean(out(1).Results.MaxModelParams)) ' out of ' ...
%             num2str(out(1).datainfo.nfeatures) ' features, thus using only ' num2str(mean(out(1).Results.MaxModelParams)/out(1).datainfo.nfeatures*100) '% of the available features.'];
%         
%         t_report = protosc_report_ttest2(out(1).Results.FinalModel.F1,out(1).Results.FullModel.F1,{'final model' 'full model'},'both',.01,'accuracy');
%         report = [report ' Compared to the full model, that uses 100% of the available features, r' t_report(2:end)];
%     else
%         report =['The ' out(1).datainfo.dataType '-based analysis was done separately for each of ' num2str(length(out(1).Results.FinalModel.Accuracy)) ' participants. '...
%             'All analyses used the averages over each of the ' ...
%             num2str(out(1).settings.Main.nfolds) ' folds from each participant, resulting in one average per participant. '];
%         report = [report t_report];
%         t_report = protosc_report_finalmodelselection(out(1));
%         report = [report ' Here, t' t_report(2:end) ' The final model used an average of ' num2str(mean(out(1).Results.MaxModelParams)) ' out of ' ...
%             num2str(out(1).datainfo.nfeatures) ' features, thus using only ' num2str(mean(out(1).Results.MaxModelParams)/out(1).datainfo.nfeatures*100) '% of the available features.'];
%         
%         t_report = protosc_report_ttest2(out(1).Results.FinalModel.F1,out(1).Results.FullModel.F1,{'final model' 'full model'},'both',.01,'accuracy');
%         report = [report ' Compared to the full model, that uses 100% of the features, r' t_report(2:end)];
%     end
% else
%     report =['The ' out(1).datainfo.dataType '-based analysis and the ' out(2).datainfo.dataType '-based analysis were run independently. '];
%     for ii = 1:2
%         t_report = protosc_report_ttest(out(ii).Results.FinalModel.Accuracy,out(ii).Results.ControlFinalModel.Accuracy,{'the final model' 'the control model'},'both',.01,'accuracy');
%         report = [report 'For the ' out(ii).datainfo.dataType '-based analysis, r' t_report(2:end)];
%         t_report = protosc_report_finalmodelselection(out(ii));
%         report = [report ' Here, t' t_report(2:end) ' The final model used an average of ' num2str(mean(out(ii).Results.MaxModelParams)) ' out of ' ...
%             num2str(out(ii).datainfo.nfeatures) ' features, thus using only ' num2str(mean(out(ii).Results.MaxModelParams)/out(ii).datainfo.nfeatures*100) '% of the available information.'];
%         
%         t_report = protosc_report_ttest2(out(ii).Results.FinalModel.F1,out(ii).Results.FullModel.F1,{'final model' 'full model'},'both',.01,'accuracy');
%         if ii == 1
%             report = [report ' Compared to the full model, that uses 100% of the available features, r' t_report(2:end) ' '];
%         else
%             report = [report ' Compared to the full model, that uses 100% of the available features, r' t_report(2:end)];
%         end
%     end
% end


