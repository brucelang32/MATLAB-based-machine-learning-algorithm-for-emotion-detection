function version = protosc_get_versioninfo
% function version = protosc_get_versioninfo
% 
%  SS 2019

r       = protosc_get_root; 
version = r(strfind(protosc_get_root,'Protosc_')+length('Protosc_'):end);
version(strfind(version,filesep))='';


