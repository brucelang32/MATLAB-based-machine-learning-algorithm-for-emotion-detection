%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Wrapper approach based on Machine Learning Performance
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% this script is a sub-part of protosc_ana_FeatureSelection and
% is not made to function in isolation
% 
%
% SS 2019

try
    WMLModel           = eval(['@' out.settings.Wrapper.Classifier]);
catch
    WMLModel           = eval(['@' char(out.settings.Wrapper.Classifier)]);
end
try
    CritFunction           = eval(['@' out.settings.Wrapper.CritFunction]);
catch
    CritFunction           = eval(['@' char(out.settings.Wrapper.CritFunction)]);
end


if out.settings.Wrapper.chunksearch
    protosc_ana_Wrapper_update_ranking_ordered
    updatedrankscores(out.Results.InclusionBolean{ifold}==0) = 0;
else
    updatedrankscores = currentrankscores;
end
out.Results.UpdatedRankScores{ifold}        = updatedrankscores;

% get ranking order
[~,PosibleParams] = sort(out.Results.UpdatedRankScores{ifold},'descend');
%remove
[PosibleParams,~] = protosc_check_PosibleParams(PosibleParams,find(out.Results.InclusionBolean{ifold}==0));


disp(['[In ' mfilename '] Going though search space'])

if isempty(out.settings.Wrapper.startmodelsize) || out.settings.Wrapper.startmodelsize<=0
    getx = 1;
else
    getx = floor(out.Results.MaxModelParams(ifold)*out.settings.Wrapper.startmodelsize);
end
IncludedParams                  = PosibleParams(1:getx);
keepgoing                       = 1;
rep                             = 0;
re_eval                         = out.settings.Wrapper.ReEval01;
re_eval_perc                    = out.settings.Wrapper.ReEvalf;
failed_to_add                   = 0;
while keepgoing
    rep = rep +1;
    if re_eval && length(IncludedParams) >= round(out.Results.MaxModelParams(ifold)*re_eval_perc) && length(IncludedParams)>4
        disp(['[In ' mfilename '] Re-Evaluating Feature order'])
        [IncludedParams,PosibleParams] = protosc_ana_Wrapper_evalFeatureOrder(out,TrainValData,PosibleParams,IncludedParams);
        [PosibleParams,IncludedParams] = protosc_check_PosibleParams(PosibleParams,IncludedParams);
        re_eval = 0;
    end
    PosibleParams                                       = protosc_check_PosibleParams(PosibleParams,IncludedParams);
    [out.Results.SearchSpaceSizes(ifold),keepgoing]     = protosc_check_SearchSpace(PosibleParams,out);
    IncludedParams                                      = unique(IncludedParams,'stable');
    startingwithxfeatures                               = length(IncludedParams);
%     for ii = 1:length(PosibleParams)
%         if sum(find(out.Results.InclusionBolean{ifold}==0) == PosibleParams(ii))>0
%             disp('FOUND ERROR IN INC PAR')
%             error('FUK PRE')
%         end
%     end
    [IncludedParams,refperf,PosibleParams]              = protosc_ana_Wrapper_AddFeatures(out,TrainValData,PosibleParams,IncludedParams,MLmodel);
%     IncBolT = ones(1,length(IncludedParams));
%     for ii = 1:length(IncludedParams)
%         if sum(find(out.Results.InclusionBolean{ifold}==0) == IncludedParams(ii))>0
%             disp('FOUND ERROR IN INC PAR')
%             IncBolT(ii) = 0;
%             error('FUK post')
%         end
%     end
%     IncludedParams =
    
    IncludedParams                                      = unique(IncludedParams,'stable');
    PosibleParams                                       = protosc_check_PosibleParams(PosibleParams,IncludedParams);
    if length(IncludedParams) == startingwithxfeatures
        failed_to_add = failed_to_add+1;
    end
    if out.settings.Display.showintremfeedback
        disp(['[In ' mfilename '] Fold ' num2str(ifold) ' out of ' num2str(out.settings.Main.nfolds) ', Pass: ' num2str(rep) ', ' num2str(length(IncludedParams)) ' Features selected ' ])
    end
    if length(IncludedParams)>=out.Results.MaxModelParams(ifold)
        if out.settings.Display.showintremfeedback
            disp(['[In ' mfilename '] Reached maximum number of features'])
        end
        keepgoing = 0;
    end
    if failed_to_add >= out.settings.Wrapper.failtolerance
        if out.settings.Display.showintremfeedback
            disp(['[In ' mfilename '] Failed to add more features'])
        end
        keepgoing = 0;
    end
end


