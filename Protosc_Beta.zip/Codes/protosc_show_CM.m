function protosc_show_CM(CM,varargin)
% function protosc_show_CM(CM)
% 
% SS 2019


settings = protosc_Settings;
if exist('varargin','var') || ~isempty(varargin)
    ins = varargin;
    settings = protosc_update_settings(settings,ins);
end
set(gcf,'color',settings.Figures.Color)
FontSize        = settings.Figures.FontSize;
Font            = settings.Figures.Font;
linewidth       = settings.Figures.linewidth;
usecolormap     = protosc_figure_colormap;
for ii = 1:size(CM,1)
    labelnames{ii}      = num2str(ii);
end
imagesc(CM), 
axis square, 
xlabel('Predicted class')
ylabel('Real class')
title('Confusion Matrix')
colorbar
set(gca,'colormap',colormap(usecolormap),'linewidth',linewidth,'FontName',Font,'FontSize',FontSize,'XTick',1:size(CM,1),'YTick',1:size(CM,1),'XTickLabels',labelnames,'YTickLabels',labelnames);

CM = CM*100;
if settings.Figures.CMtext
    for ii = 1:size(CM,1)
        for jj = 1:size(CM,2)
            if isnan(CM(ii,jj))
                t = '-';
                hold on
                text(jj-.02,ii-.02,t,'FontName',Font,'FontSize',FontSize);
            elseif CM(ii,jj)==0
                t = '-';
                hold on
                text(jj-.02,ii-.02,t,'FontName',Font,'FontSize',FontSize);
            else
                t = num2str(CM(ii,jj));
                hold on
                if length(t)>5
                    text(jj-.25,ii-.02,t(1:4),'FontName',Font,'FontSize',FontSize);
                else
                    text(jj-.25,ii-.02,t,'FontName',Font,'FontSize',FontSize);
                end
            end
        end
    end
end

