function protosc_figure_Plot(xdata,ydata,varargin)
% function protosc_figure_Plot(xdata,ydata,'PropertyName',Property)
%
% Possible Params:
% See protosc_Settings
%
% SS 2019


settings = protosc_Settings;
if exist('varargin','var') || ~isempty(varargin)
    ins = varargin;
    settings = protosc_update_settings(settings,ins);
end
settings.Figures.linestyle = '-';
if ~exist('ydata','var') || isempty(ydata)
    ydata = xdata;
    xdata = 1:size(xdata,2);
end
if size(ydata,1) == 1
    calc = -1;
else
    calc = 1;
end
if size(xdata,1)>1
    if size(xdata,1) ~= size(ydata,1)
        error('Not sure how you want me to deal with the different sizes of your xdata and ydata')
    else
        calc = 0;
    end
end
if settings.Figures.newfigure==1
    figure('color',settings.Figures.Color);
else
    set(gcf,'color',settings.Figures.Color)
end
ca = gca;
if ca.YLim(2)>settings.Figures.YMAX
    settings.Figures.YMAX = ca.YLim(2);
end
if calc == 1
    [sorted,originalindex,~]= protosc_get_sortscore(xdata,'up');
    temp_ym  = mean(ydata);
    temp_tsem = std(ydata)/sqrt(size(ydata,1));
    hold on,errorbar(sorted,temp_ym(originalindex),temp_tsem(originalindex),'Marker',settings.Figures.Marker,'LineStyle',settings.Figures.linestyle,'MarkerFaceColor',settings.Figures.MarkerFaceColor,...
        'MarkerEdgeColor',settings.Figures.MarkerEdgeColor,'Color', settings.Figures.LineColor,'LineWidth',settings.Figures.linewidth)
elseif calc == 0
    for ii = 1:size(xdata,1)
        [~,originalindex,~]= protosc_get_sortscore(xdata(ii,:),'up');
        hold on, plot(xdata(ii,originalindex),ydata(ii,originalindex),'Marker',settings.Figures.Marker,'LineStyle',settings.Figures.linestyle,'MarkerFaceColor',settings.Figures.MarkerFaceColor,...
            'MarkerEdgeColor',settings.Figures.MarkerEdgeColor,'Color', settings.Figures.LineColor,'LineWidth',settings.Figures.linewidth)
    end
elseif calc == -1
    [~,originalindex,~]= protosc_get_sortscore(xdata,'up');
    hold on,plot(xdata(originalindex),ydata(1,originalindex),'Marker',settings.Figures.Marker,'LineStyle',settings.Figures.linestyle,'MarkerFaceColor',settings.Figures.MarkerFaceColor,...
        'MarkerEdgeColor',settings.Figures.MarkerEdgeColor,'Color',settings.Figures.LineColor,'LineWidth',settings.Figures.linewidth)
end
axis square
title(settings.Figures.Title,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
xlabel(settings.Figures.Xlabel,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
ylabel(settings.Figures.Ylabel,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
set(gca,'linewidth',settings.Figures.linewidth,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
box(settings.Figures.showbox)


