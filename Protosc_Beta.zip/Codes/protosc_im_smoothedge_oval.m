function out = protosc_im_smoothedge_oval(width,height,edgesize,type)
% function out = im_smoothedge_oval(width,height,edgesize,type)
% 
% SS 2019

if ~exist('width','var') || isempty(width)
    width = 100;
end
if ~exist('height','var') || isempty(height)
    height = 100;
end
radius = min([height,width])/2-.5;
if ~exist('edgesize','var') || isempty(edgesize)
    edgesize = round(radius/5);
end
b               = protosc_im_smoothedge_circle(radius,edgesize);
out             = imresize(b,[height,width],'nearest');
out             = protosc_im_2Center(out,zeros(max([height,width])));
if ~exist('type','var') || isempty(type)
    type = 'lin';
end
if strcmpi(type,'cos')
    out = 1-protosc_im_scale(cos(out*pi));
end

