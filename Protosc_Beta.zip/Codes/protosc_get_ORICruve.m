function [Oricurve,range] = protosc_get_ORICruve(FourierMap,nsteps,norm)
% function [Oricurve,range] = protosc_get_ORICruve(FourierMap,nsteps)
%
% SS 2019

if ~exist('nsteps','var')
    nsteps = 5;
end
if ~exist('norm','var')
    norm = 0;
end

ang         = protosc_im_anglemap(size(FourierMap,1));
range       = 0:(ceil(max(max(ang)))/2)/nsteps:ceil(max(max(ang)))/2;
Oricurve    = nan(1,length(range)-1);
for ii = 1:length(range)-1
    Oricurve(ii) = nanmean(FourierMap(ang>=range(ii) & ang<range(ii+1)));%/sum(sum(FourierMap));
end
if norm
    Oricurve    = Oricurve/sum(Oricurve);
end
range       = range(1:end-1);
