function b = protosc_im_smoothedge_circle(radius,edgesize,type)
% function out = protosc_im_smoothedge_circle(radius,edgesize,type)
%
% SS 2019

if ~exist('radius','var') || isempty(radius)
    radius = 100;
end
if ~exist('edgesize','var') || isempty(edgesize)
    edgesize = round(radius/5);
end
[X, Y]              = meshgrid(-radius:radius,-radius:radius);
radimap             = sqrt(X.^2+Y.^2);
out1                = radimap<radius;
out2                = radimap<(radius-edgesize);
a                   = max(radimap(:))-radimap;
a(out1-out2 == 0)   = min(a(out1-out2==1));
b                   = protosc_im_scale(a);
b(out2==1)          = 1;
if ~exist('type','var') || isempty(type)
    type = 'lin';
end
if strcmpi(type,'cos')
    b = 1-protosc_im_scale(cos(b*pi));
end
