function protosc_figure_Bar(data,varargin)
% function protosc_figure_Bar(data,'propertyname',property input) or show_cleanBar(data,'Param',[Param input])
%
% Possible Params:
% FaceColor,EdgeColor,MarkerEdgeColor,MarkerFaceColor,LineColor,FontSize,Font,linewidth,FigureName,Xlabel,Ylabel,Marker,YMAX
%
% SS 2019


settings = protosc_Settings;
if exist('varargin','var') || ~isempty(varargin)
    ins = varargin;
    settings = protosc_update_settings(settings,ins);
end
if settings.Figures.newfigure==1
    figure('color',settings.Figures.Color);
else
    set(gcf,'color',settings.Figures.Color)
end
if isempty(settings.Figures.YMAX)
    settings.Figures.YMAX        = max(nanmean(data)+nanstd(data)/sqrt(size(data,1)))+(max(nanmean(data)+nanstd(data)/sqrt(size(data,1)))*.1);
end
if isempty(settings.Figures.YMIN)
    settings.Figures.YMIN        = min(nanmean(data)-nanstd(data)/sqrt(size(data,1)))+(min(nanmean(data)-nanstd(data)/sqrt(size(data,1)))*.1);
end
if settings.Figures.YMIN>0
    settings.Figures.YMIN = 0;
end
if size(data,1) == 1
    calc = -1;
else
    calc = 1;
end
if size(data,2)>size(settings.Figures.xticklabels,2)
    xticklabels_t = settings.Figures.xticklabels;
    for ii = size(settings.Figures.xticklabels,2)+1:size(data,2)
        settings.Figures.xticklabels_t{ii}     = ' ' ;
    end
    settings.Figures.xticklabels = xticklabels_t;
end
if calc == 1
    bar(nanmean(data),'FaceColor',settings.Figures.FaceColor,'EdgeColor',settings.Figures.EdgeColor,'linewidth',settings.Figures.linewidth); hold on
    errorbar(1:size(data,2),nanmean(data),nanstd(data)/sqrt(size(data,1)),'Marker',settings.Figures.Marker,'LineStyle','none','MarkerFaceColor',settings.Figures.MarkerFaceColor,...
        'MarkerEdgeColor',settings.Figures.MarkerEdgeColor,'Color',settings.Figures.LineColor,'LineWidth',settings.Figures.linewidth)
elseif calc == 0
    bar(data(1,:),'FaceColor',settings.Figures.FaceColor,'EdgeColor',settings.Figures.EdgeColor,'linewidth',settings.Figures.linewidth); hold on
    errorbar(1:size(data,2),data(1,:),data(2,:),'Marker',settings.Figures.Marker,'LineStyle','none','MarkerFaceColor',settings.Figures.MarkerFaceColor,...
        'MarkerEdgeColor',settings.Figures.MarkerEdgeColor,'Color', settings.Figures.LineColor,'LineWidth',settings.Figures.linewidth)
elseif calc == -1
    bar(data(1,:),'FaceColor',settings.Figures.FaceColor,'EdgeColor',settings.Figures.EdgeColor,'linewidth',settings.Figures.linewidth); hold on
end
title(settings.Figures.Title,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
xlabel(settings.Figures.Xlabel,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
ylabel(settings.Figures.Ylabel,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
if settings.Figures.chanceline
    lineY = settings.Figures.chanceline;
    if length(lineY)==1
        lineY = [lineY lineY];
    end
    hold on
    plot([0 size(data,2)+1],lineY,'--k')
end
title(settings.Figures.Title,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
set(gca,'linewidth',settings.Figures.linewidth,'Xtick',1:size(data,2),'Xticklabels',settings.Figures.xticklabels,'FontName',settings.Figures.Font,'FontSize',settings.Figures.FontSize)
axis([0 size(data,2)+1 settings.Figures.YMIN settings.Figures.YMAX]),box(settings.Figures.showbox)
axis square


